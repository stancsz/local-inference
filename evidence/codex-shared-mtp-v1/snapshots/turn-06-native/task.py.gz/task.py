import json
import math


def audit_file(path):
    with open(path, 'r', encoding='utf-8') as handle:
        return audit_events(handle.read())


def audit_events(jsonl_text):
    if not isinstance(jsonl_text, str):
        raise ValueError('audit_events expects JSONL text')
    count = 0
    ok = 0
    errors = 0
    total_duration_ms = 0
    services = {}
    for line in jsonl_text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError('invalid JSONL row') from exc
        if not isinstance(event, dict):
            raise ValueError('JSONL row must be an object')
        for field in ('service', 'status', 'duration_ms'):
            if field not in event:
                raise ValueError('missing required field: ' + field)
        service = event['service']
        status = event['status']
        duration_ms = event['duration_ms']
        if not isinstance(service, str):
            raise ValueError('service must be a string')
        if not isinstance(status, str):
            raise ValueError('status must be a string')
        if not isinstance(duration_ms, (int, float)) or isinstance(duration_ms, bool):
            raise ValueError('duration_ms must be a number')
        service = service.strip()
        if not service:
            raise ValueError('service must be nonempty after stripping')
        if status not in ('ok', 'error'):
            raise ValueError('status must be exactly ok or error')
        if duration_ms < 0 or not math.isfinite(duration_ms):
            raise ValueError('duration_ms must be a finite nonnegative number')
        count += 1
        total_duration_ms += duration_ms
        if status == 'ok':
            ok += 1
        elif status == 'error':
            errors += 1
        if service not in services:
            services[service] = {'count': 0, 'errors': 0, 'duration_ms': 0}
        entry = services[service]
        entry['count'] += 1
        entry['errors'] += 1 if status == 'error' else 0
        entry['duration_ms'] += duration_ms
    return {'count': count, 'ok': ok, 'errors': errors, 'total_duration_ms': total_duration_ms, 'services': services}

