import unittest

from contextlib import contextmanager
from pathlib import Path
import shutil
import uuid

@contextmanager
def _workspace_fixture():
    root=Path.cwd().resolve()
    directory=root/('.sift-fixture-'+uuid.uuid4().hex)
    directory.mkdir(mode=0o755)
    try:
        yield str(directory)
    finally:
        resolved=directory.resolve()
        assert resolved==directory and resolved.parent==root and not directory.is_symlink()
        shutil.rmtree(directory)


class Acceptance(unittest.TestCase):
    def test_behavior(self):
        import task,json,tempfile
        from pathlib import Path
        data='{"service": "api", "status": "ok", "duration_ms": 9}'
        r=task.audit_events(data)
        self.assertEqual((r['count'],r['ok'],r['errors'],r['total_duration_ms']),(1,1,0,9))
        data='\n'.join([json.dumps({'service':' api ','status':'ok','duration_ms':2}),json.dumps({'service':'api','status':'error','duration_ms':3})])
        r=task.audit_events(data)
        self.assertEqual(list(r['services']),['api'])
        for bad in ('not-json','[]','null','{}',None,True,123,{},[]):
            with self.assertRaises(ValueError): task.audit_events(bad)
        self.assertEqual(task.audit_events('\n'+data+'\n\n')['count'],2)
        for key,values in [('duration_ms',[None,True,False,-1,-0.5,float('nan'),float('inf'),'2']),('service',[None,True,'  ']),('status',[None,'fail',True])]:
            for value in values:
                record={'service':'api','status':'ok','duration_ms':1};record[key]=value
                with self.assertRaises(ValueError): task.audit_events(json.dumps(record))
        self.assertEqual(r['services']['api'],{'count':2,'errors':1,'duration_ms':5})
        self.assertEqual(task.audit_events(json.dumps({'service':'x','status':'ok','duration_ms':0,'metadata':123}))['count'],1)
        self.assertEqual(task.audit_events('  \n'),{'count':0,'ok':0,'errors':0,'total_duration_ms':0,'services':{}})
        self.assertEqual(task.audit_events(json.dumps({'service':'分析','status':'ok','duration_ms':0}))['total_duration_ms'],0)
        with _workspace_fixture() as folder:
            path=Path(folder)/'events.jsonl';path.write_text('{"service": "worker", "status": "error", "duration_ms": 17.0}\n{"service": " api ", "status": "error", "duration_ms": 112.0}\n{"service": "worker", "status": "error", "duration_ms": 303.5}\n{"service": "分析", "status": "error", "duration_ms": 211.0}\n{"service": " api ", "status": "ok", "duration_ms": 290.5}\n{"service": "分析", "status": "ok", "duration_ms": 272.5}\n{"service": "分析", "status": "error", "duration_ms": 41.0}\n{"service": " api ", "status": "ok", "duration_ms": 279.5}\n{"service": "分析", "status": "error", "duration_ms": 181.0}\n{"service": "worker", "status": "ok", "duration_ms": 56.5}\n{"service": " api ", "status": "ok", "duration_ms": 94.5}\n{"service": "worker", "status": "ok", "duration_ms": 230.0}\n{"service": "worker", "status": "error", "duration_ms": 312.0}\n{"service": "分析", "status": "ok", "duration_ms": 236.0}\n{"service": " api ", "status": "error", "duration_ms": 292.0}\n{"service": " api ", "status": "error", "duration_ms": 263.0}\n{"service": " api ", "status": "error", "duration_ms": 22.0}',encoding='utf-8')
            before=path.read_bytes()
            self.assertEqual(task.audit_file(path),{'count': 17, 'ok': 7, 'errors': 10, 'total_duration_ms': 3214.0, 'services': {'worker': {'count': 5, 'errors': 3, 'duration_ms': 919.0}, 'api': {'count': 7, 'errors': 4, 'duration_ms': 1353.5}, '分析': {'count': 5, 'errors': 3, 'duration_ms': 941.5}}})
            self.assertEqual(path.read_bytes(),before)
    def test_evidence(self):
        import json
        from pathlib import Path
        value=json.loads(Path('evidence.json').read_text())['acceptance_delay_seconds']
        self.assertIs(type(value),int)

if __name__=='__main__':
    unittest.main()
