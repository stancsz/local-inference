import json

def audit_events(jsonl_text):
    count = 0
    ok = 0
    errors = 0
    total_duration_ms = 0
    services = {}
    for line in jsonl_text.splitlines():
        line = line.strip()
        if not line:
            continue
        event = json.loads(line)
        count += 1
        service = event['service'].strip()
        status = event['status']
        duration_ms = event['duration_ms']
        total_duration_ms += duration_ms
        if status == 'ok':
            ok += 1
        elif status == 'error':
            errors += 1
        services[service] = services.get(service, 0) + 1
    return {'count': count, 'ok': ok, 'errors': errors, 'total_duration_ms': total_duration_ms, 'services': services}

