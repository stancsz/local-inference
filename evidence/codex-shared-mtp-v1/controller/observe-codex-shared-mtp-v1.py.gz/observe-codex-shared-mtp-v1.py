"""Bounded process and receipt observation for the existing sealed Codex case."""
import ctypes,json,urllib.request
from ctypes import wintypes
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parents[2]
state=json.loads((root/'evidence/codex-shared-mtp-v1-state.json').read_text())
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
def live(pid):
 handle=kernel.OpenProcess(0x1000,False,pid)
 if not handle:return False
 try:
  code=wintypes.DWORD();return bool(kernel.GetExitCodeProcess(handle,ctypes.byref(code)))and code.value==259
 finally:kernel.CloseHandle(handle)
row={'at':datetime.now(timezone.utc).isoformat(),'status':state['status'],'controller_pid':state['controller_pid'],'controller_live':live(state['controller_pid']),'runner_pid':state.get('runner_pid'),'runner_live':live(state['runner_pid'])if state.get('runner_pid')else False}
folder=root/'tmp/codex-shared-mtp-v1';receipt=folder/'result.json'
if receipt.exists():
 result=json.loads(receipt.read_text());row.update(turns=len(result.get('turns',[])),active_seconds=result.get('active_client_seconds'),accepted=result.get('accepted'),failure=result.get('failure'),sandbox_readiness=result.get('sandbox_readiness',{}).get('passed'),fixture_readiness=result.get('fixture_readiness',{}).get('passed'))
captures=sorted((folder/'requests').glob('*.gz'))
if captures:row.update(captures=len(captures),latest_capture=captures[-1].name,latest_capture_modified=datetime.fromtimestamp(captures[-1].stat().st_mtime,timezone.utc).isoformat())
try:
 with urllib.request.urlopen('http://127.0.0.1:8091/slots',timeout=5)as response:slots=json.load(response)
 row['slots']=[{k:s[k]for k in ('is_processing','n_prompt_tokens','next_token')}for s in slots]
except Exception as error:row['backend_observation_error']=str(error)
with (root/'evidence/codex-shared-mtp-v1-observations.jsonl').open('a',encoding='utf-8')as stream:stream.write(json.dumps(row)+'\n')
print(json.dumps(row),flush=True)
