"""Run exactly the sealed case without changing limits or permission settings."""
import json,os,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT.parent/'sift/src'),str(ROOT/'app'),str(ROOT/'scripts')]
from stress.campaign_v3 import source_hashes
from setup_env import gateway_key
plan=json.loads((ROOT/'evidence/codex-shared-mtp-v1-plan.json').read_text())
assert source_hashes()==plan['source_sha256']
assert not(ROOT/plan['output_dir']).exists()
state_path=ROOT/'evidence/codex-shared-mtp-v1-state.json'
assert not state_path.exists()
env=dict(os.environ);env['SIFT_ACCEPTANCE_API_KEY']=gateway_key();env['PYTHONPATH']=';'.join(sys.path[:4])
args=[sys.executable,'-u','-m','stress.campaign_v3','--client','codex','--task','incident_log','--seed',str(plan['case']['seed']),'--output-dir',plan['output_dir'],'--model',plan['model'],'--minimum-turns','9','--max-turns','9','--minimum-seconds','185','--turn-timeout','240']
state={'controller_pid':os.getpid(),'status':'starting','started':datetime.now(timezone.utc).isoformat(),'qualification_increment':0,'full_goal':'NOT_READY','plan':'evidence/codex-shared-mtp-v1-plan.json'}
def save():
 temp=state_path.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2));temp.replace(state_path)
save()
with (ROOT/'tmp/stress/codex-shared-mtp-v1.stdout.log').open('x',encoding='utf-8')as out,(ROOT/'tmp/stress/codex-shared-mtp-v1.stderr.log').open('x',encoding='utf-8')as err:
 process=subprocess.Popen(args,env=env,cwd=ROOT,stdout=out,stderr=err)
 state.update(status='running',runner_pid=process.pid);save()
 try:code=process.wait(timeout=2400)
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
  code=process.wait(timeout=20);state['controller_timeout']=True
 state.update(status='terminal',exit_code=code,ended=datetime.now(timezone.utc).isoformat());save()
print(json.dumps(state),flush=True)
