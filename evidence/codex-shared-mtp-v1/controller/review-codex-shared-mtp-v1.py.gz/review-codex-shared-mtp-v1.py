"""Parent replay of sealed Codex snapshots; never edits campaign artifacts."""
import gzip,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT.parent/'sift/src'),str(ROOT/'app'),str(ROOT/'scripts')]
from stress.campaign_v3 import parse_events,session_id,source_hashes
from stress.native_v3 import native_evidence
from stress.portable_tasks_v2 import stage
from stress.balanced_review_v2 import inspect_capture,solution_reference_access
state=json.loads((ROOT/'evidence/codex-shared-mtp-v1-state.json').read_text())
assert state['status']=='terminal','Do not certify a live case'
plan=json.loads((ROOT/'evidence/codex-shared-mtp-v1-plan.json').read_text())
assert source_hashes()==plan['source_sha256']
folder=ROOT/plan['output_dir'];receipt=json.loads((folder/'result.json').read_text())
assert receipt['source_sha256']==plan['source_sha256']
rows=[];failures=[];captured=[]
for index,turn in enumerate(receipt['turns']):
 events=parse_events((folder/f'turn-{index:02}.jsonl').read_text(encoding='utf-8'))
 native=native_evidence('codex',events,folder/'workspace')
 assert native==turn['native']
 assert session_id('codex',events)==receipt['session_id']
 if any(solution_reference_access(e)for e in events):failures.append(f'turn{index+1}:solution-reference access')
 stages=[]
 for label in ('native','hidden'):
  snapshot=folder/'snapshots'/f'turn-{index:02}-{label}'
  manifest=json.loads((snapshot/'hashes.json').read_text())
  for name,digest in manifest['sha256'].items():
   if digest is not None:assert hashlib.sha256((snapshot/name).read_bytes()).hexdigest()==digest
  expected=stage('incident_log',index,plan['case']['seed']+index)['tests'].encode().replace(b'\n',os.linesep.encode())
  assert hashlib.sha256(expected).hexdigest()==turn['public_tests_sha256']==manifest['sha256']['test_task.py']
  behavior=[]
  with tempfile.TemporaryDirectory(prefix='codex-parent-',dir=ROOT/'tmp')as work:
   work=Path(work)
   for name in ('task.py','evidence.json'):
    if(snapshot/name).exists():(work/name).write_bytes((snapshot/name).read_bytes())
   for seed_label,offset in (('public',0),('hidden',100003),('parent',200003)):
    tests=stage('incident_log',index,plan['case']['seed']+index+offset)['tests']
    prefix="import sys;sys.path.insert(0,sys.argv[1]);sys.argv=['parent-replay'];"
    run=subprocess.run([sys.executable,'-I','-B','-c',prefix+tests,str(work)],cwd=work,capture_output=True,timeout=20)
    behavior.append({'seed_class':seed_label,'exit':run.returncode,'output':(run.stdout+run.stderr).decode('utf-8',errors='replace')})
    if run.returncode:failures.append(f'turn{index+1}:{label}:{seed_label} behavior failure')
  stages.append({'snapshot':label,'behavior':behavior})
 rows.append({'turn':index+1,'native_exact_replay':True,'native':native,'snapshots':stages})
for index,audit in enumerate(receipt['audits']):
 path=folder/'requests'/audit['excerpt_capture']
 errors,row=inspect_capture(gzip.decompress(path.read_bytes()),index,audit)
 failures.extend(errors);captured.append(row)
 if audit.get('upstream_status')!=200:failures.append(f'request{index}:upstream status')
for index,audit in enumerate(receipt.get('native_gateway_audits',[])):
 if audit['native_input_tokens']+audit['output_reserve']+audit['decoder_headroom']>audit['context_window']:failures.append(f'native audit{index}:context overflow')
qualifying=bool(receipt['accepted']and len(rows)>=9 and receipt['active_client_seconds']>185 and not failures)
report={'plan':'evidence/codex-shared-mtp-v1-plan.json','raw_accepted':receipt['accepted'],'parent_qualified':qualifying,'turns':rows,'captures':captured,'active_seconds':receipt['active_client_seconds'],'failures':failures,'prior_candidate_total':23,'candidate_total_after_parent':23+int(qualifying),'per_client_after_parent':{'claude':8,'opencode':9,'codex':6+int(qualifying)},'full_goal':'NOT_READY','scope':'Per-turn immutable snapshots, native continuity, archived source facts, additional parent seeds and downstream context; final nonauthor verdict remains required.'}
path=ROOT/'evidence/codex-shared-mtp-v1-parent-review.json'
with path.open('x',encoding='utf-8')as target:json.dump(report,target,indent=2)
print(json.dumps({k:v for k,v in report.items()if k not in ('turns','captures')}))
