import json,runpy,time
from pathlib import Path
root=Path(__file__).resolve().parent
for _ in range(82):
 runpy.run_path(str(root/'observe-codex-shared-mtp-v1.py'))
 if json.loads((root.parents[1]/'evidence/codex-shared-mtp-v1-state.json').read_text())['status']=='terminal':break
 time.sleep(30)
