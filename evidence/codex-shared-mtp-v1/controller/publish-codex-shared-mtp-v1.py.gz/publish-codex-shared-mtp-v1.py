"""Publish the terminal Codex case without modifying original receipts or counts."""
import gzip,hashlib,importlib,json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT.parent/'sift/src'),str(ROOT/'app'),str(ROOT/'scripts')]
from setup_env import gateway_key
state=json.loads((ROOT/'evidence/codex-shared-mtp-v1-state.json').read_text());assert state['status']=='terminal'
plan=json.loads((ROOT/'evidence/codex-shared-mtp-v1-plan.json').read_text())
parent=json.loads((ROOT/'evidence/codex-shared-mtp-v1-parent-review.json').read_text());assert parent['parent_qualified']
folder=ROOT/plan['output_dir'];out=ROOT/'evidence/codex-shared-mtp-v1';out.mkdir(exist_ok=True)
assert not(ROOT/'evidence/codex-shared-mtp-v1-publication.json').exists(),'Publication already sealed'
secrets=[gateway_key()]+[value for name,value in os.environ.items()if any(s in name.upper()for s in ('KEY','TOKEN','SECRET','PASSWORD'))and len(value)>12]
artifacts=[]
def publish(source,relative,already_gzip=False):
 raw=source.read_bytes();decoded=raw
 while decoded.startswith(b'\x1f\x8b'):decoded=gzip.decompress(decoded)
 assert all(s.encode()not in decoded for s in secrets),str(source)
 data=raw if already_gzip else gzip.compress(raw,mtime=0)
 target=out/relative;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==data,('Refuse to overwrite differing partial archive',str(target))
 else:target.write_bytes(data)
 artifacts.append({'path':target.relative_to(ROOT).as_posix(),'compressed_sha256':hashlib.sha256(data).hexdigest(),'raw_sha256':hashlib.sha256(gzip.decompress(data)).hexdigest()})
for source in sorted(folder.rglob('*')):
 if not source.is_file():continue
 relative=source.relative_to(folder)
 if relative.parts[0]not in ('workspace','snapshots','requests')and source.name!='result.json'and not source.name.startswith('turn-'):continue
 if relative.parts[0]=='workspace'and relative.name not in ('task.py','test_task.py','evidence.json'):continue
 publish(source,relative if source.suffix=='.gz'else relative.with_name(relative.name+'.gz'),source.suffix=='.gz')
for name,digest in plan['source_sha256'].items():
 path=ROOT/name if (ROOT/name).is_file() else Path(importlib.import_module(name).__file__)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,name
 relative=Path('producer')/(name.replace('/','__')+'.gz')
 publish(path,relative)
for name in ('run-codex-shared-mtp-v1.py','observe-codex-shared-mtp-v1.py','watch-codex-shared-mtp-v1.py','review-codex-shared-mtp-v1.py','publish-codex-shared-mtp-v1.py','codex-shared-mtp-v1.stdout.log','codex-shared-mtp-v1.stderr.log'):
 publish(ROOT/'tmp/stress'/name,Path('controller')/(name+'.gz'))
for name in ('codex-shared-mtp-v1-plan.json','codex-shared-mtp-v1-state.json','codex-shared-mtp-v1-observations.jsonl','codex-shared-mtp-v1-parent-review.json','codex-shared-mtp-v1-publication-attempt-1.json'):
 publish(ROOT/'evidence'/name,Path('receipts')/(name+'.gz'))
report={'scope':'Terminal repaired-source shared-MTP Codex acceptance; raw and parent replay artifacts','source_plan':'evidence/codex-shared-mtp-v1-plan.json','parent_review':'evidence/codex-shared-mtp-v1-parent-review.json','parent_qualified':True,'turns':9,'active_seconds':parent['active_seconds'],'captures':len(parent['captures']),'new_parent_qualified':1,'candidate_total':24,'per_client':parent['per_client_after_parent'],'original_campaign_and_failed_outcomes_unchanged':True,'full_goal':'NOT_READY','artifacts':artifacts}
with (ROOT/'evidence/codex-shared-mtp-v1-publication.json').open('x',encoding='utf-8')as stream:json.dump(report,stream,indent=2)
print(json.dumps({k:v for k,v in report.items()if k!='artifacts'}))
