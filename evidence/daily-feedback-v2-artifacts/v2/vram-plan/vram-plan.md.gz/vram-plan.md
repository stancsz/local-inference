# VRAM Plan

## Disk size (model-manifest.json) — raw bytes, not runtime VRAM
- Raw model `Qwen3.8-27B-UD-IQ3_XXS.gguf`: 10934860704 bytes
- MTP `MTP/mtp-Qwen3.8-27B-Q4_0.gguf`: 1369590656 bytes
- Combined: 12304451360 bytes

These are on-disk GGUF sizes. They are not measured runtime VRAM.

## Measured runtime delta (runtime-vram.json)
- observed_inference_delta_mib = 13743
- observed_inference_delta_bytes = 14410579968
- baseline_host_used_mib = 1509; loaded_host_used_mib = 15252
- under_14_decimal_GB_by_delta = false

The measured delta exceeds the raw model disk bytes because it includes
runtime caches/buffers and possible unrelated desktop drift; it is not
per-allocation accounting. The disk size is therefore distinct from and
smaller than the measured runtime delta.

## Host snapshot (host-vram.json) — older capture (2026-10-26T19:00:03Z), predates runtime-vram.json (2026-10-26T23:32:04Z)
GPU CSV order name,total,used,free:
`NVIDIA GeForce RTX 5070 Ti, 16303 MiB, 2005 MiB, 13991 MiB`

host_total_mib=16303
host_used_mib=2005
host_free_mib=13991

Three largest measured process consumers (exact source values):

| Process | PID | Dedicated MiB |
|---|---|---|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

## Safe VRAM reclamation after saving work
- Close unused browser tabs or disable browser GPU acceleration.
- Use a lower resolution or fewer active displays to reduce compositor surfaces.
- Offload weights or KV cache to RAM, at a measurable throughput cost.
- Never terminate DWM.

## PowerShell verification
```powershell
nvidia-smi --query-gpu=name,memory.total,memory.used,memory.free --format=csv,noheader
```

Unknown: exact per-model/per-allocation VRAM breakdown is not measured here.
