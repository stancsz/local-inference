"""Bounded, isolated Claude worker via the owner's local LiteLLM route."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import urllib.request
import uuid

ROOT = Path("C:/Users/stanc/github/local-inference")
BASE = 'http://127.0.0.1:4000'

def request(path, body, key):
    req = urllib.request.Request(BASE + path, data=json.dumps(body).encode(), headers={'Authorization': 'Bearer ' + key, 'x-api-key': key, 'Content-Type': 'application/json', 'anthropic-version': '2023-06-01'})
    return json.load(urllib.request.urlopen(req, timeout=100))

def main():
    master = os.environ['GATEWAY_MASTER_KEY']
    alias = 'local-inference-worker-' + uuid.uuid4().hex[:12]
    key = request('/key/generate', {'key_alias': alias, 'models': ['default'], 'duration': '20m', 'max_budget': 2.0, 'budget_duration': '20m', 'max_parallel_requests': 2}, master)['key']
    try:
        with tempfile.TemporaryDirectory(prefix='local-inference-claude-') as config:
            env = {name:value for name,value in os.environ.items() if not name.endswith(('_KEY','_TOKEN','_KEY_ID'))}
            env['PYTHONPATH']=str(ROOT.parent/'sift/src')+';'+str(ROOT)+';'+str(ROOT/'app')+';'+str(ROOT/'scripts')
            for name in ['GATEWAY_MASTER_KEY', 'EXPERTS_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDECODE']:
                env.pop(name, None)
            env.update(ANTHROPIC_API_KEY=key, ANTHROPIC_BASE_URL=BASE, ANTHROPIC_MODEL='default', ANTHROPIC_DEFAULT_OPUS_MODEL='default', ANTHROPIC_DEFAULT_SONNET_MODEL='default', ANTHROPIC_DEFAULT_HAIKU_MODEL='default', CLAUDE_CONFIG_DIR=config, CLAUDE_CODE_DISABLE_1M_CONTEXT='1', CLAUDE_CODE_MAX_CONTEXT_TOKENS='256000', API_TIMEOUT_MS='100000', CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC='1')
            args = ['claude.cmd', '--bare', '-p', '--model', 'default', '--output-format', 'json', '--max-turns', '2']
            smoke = subprocess.run(args + ['Return exactly LOCAL_INFERENCE_ROUTE_OK'], env=env, capture_output=True, text=True, timeout=150)
            (ROOT/'tmp/stress/repair-v3-focused-worker-smoke.json').write_text(json.dumps({'exit_code':smoke.returncode,'stdout':smoke.stdout,'stderr':smoke.stderr}))
            if smoke.returncode or 'LOCAL_INFERENCE_ROUTE_OK' not in smoke.stdout:
                raise RuntimeError('CLI route smoke failed; see sanitized receipt')
            body = {'model':'default','max_tokens':2048,'messages':[{'role':'user','content':'Call route_marker with marker LOCAL_INFERENCE_TOOL_OK'}], 'tools':[{'name':'route_marker','description':'Return marker','input_schema':{'type':'object','properties':{'marker':{'type':'string'}},'required':['marker']}}], 'tool_choice':{'type':'tool','name':'route_marker'}}
            first = request('/v1/messages', body, key)
            (ROOT/'tmp/stress/repair-v3-focused-worker-tool-first.json').write_text(json.dumps(first,indent=2))
            call = next(x for x in first['content'] if x['type']=='tool_use')
            body['messages'] += [{'role':'assistant','content':first['content']},{'role':'user','content':[{'type':'tool_result','tool_use_id':call['id'],'content':'LOCAL_INFERENCE_TOOL_OK'}]}]
            body.pop('tool_choice')
            second = request('/v1/messages', body, key)
            if 'LOCAL_INFERENCE_TOOL_OK' not in json.dumps(second['content']):
                raise RuntimeError('Native tool continuation failed')
            (ROOT/'tmp/stress/repair-v3-focused-worker-tool-smoke.json').write_text(json.dumps({'first':first,'continuation':second},indent=2))
            prompt = (ROOT/"tmp/stress/repair-v3-focused-brief.txt").read_text()
            args = ['claude.cmd','--bare','-p','--model','default','--output-format','stream-json','--verbose','--max-turns','16','--permission-mode','default','--tools','Read,Glob,Grep,Bash','--disallowedTools','Write,Edit','--allowedTools','Read,Glob,Grep,Bash(python *)']
            with (ROOT/'tmp/stress/repair-v3-focused-worker.jsonl').open('w') as out, (ROOT/'tmp/stress/repair-v3-focused-worker.stderr.log').open('w') as err:
                done = subprocess.run(args, input=prompt, text=True, cwd=ROOT, env=env, stdout=out, stderr=err, timeout=600)
            (ROOT/'tmp/stress/repair-v3-focused-worker-exit.json').write_text(json.dumps({'exit_code':done.returncode,'alias':alias,'route':BASE,'model':'default'}))
    finally:
        request('/key/delete', {'key_aliases':[alias]}, master)
        info = json.load(urllib.request.urlopen(urllib.request.Request(BASE + '/key/list?key_alias=' + alias, headers={'Authorization': 'Bearer ' + master}), timeout=30))
        assert alias not in json.dumps(info), 'Revoked alias still listed'
        (ROOT/'tmp/stress/repair-v3-focused-worker-revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
        print('Task-scoped key revoked', flush=True)

if __name__ == '__main__':
    main()

