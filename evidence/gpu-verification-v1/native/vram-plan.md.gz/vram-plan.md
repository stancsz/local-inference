# VRAM Plan

## Disk Sizes (model-manifest.json)
- Raw model (Qwen3.8-27B-UD-IQ3_XXS.gguf): 10934860704 bytes
- MTP (mtp-Qwen3.27B-Q4_0.gguf): 1369590656 bytes
- Combined: 12304451360 bytes

These are on-disk GGUF sizes, not runtime GPU memory.

## Measured Runtime Delta (runtime-vram.json)
- Observed inference delta: 13743 MiB (14410579968 bytes)
- Baseline host used: 1509 MiB; loaded host used: 15252 MiB
- The delta includes runtime caches, KV buffers, and possible desktop drift; it is not per-allocation accounting and differs from the 12304451360-byte disk total.

## Host Snapshot (host-vram.json, older snapshot)
GPU CSV order: name,total,used,free.
- NVIDIA GeForce RTX 5070 Ti: 16303 MiB total, 2005 MiB used, 13991 MiB free

host_total_mib=16303
host_used_mib=2005
host_free_mib=13991

## Three Largest Measured Process Consumers (host-vram.json)
| Process | PID | Dedicated MiB |
|---|---|---|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

WDDM process counters may overlap; they are not physical GPU usage totals.

## Safe VRAM Reclamation (after saving work)
- Close unused browser tabs or disable browser hardware acceleration.
- Lower display resolution or reduce active displays to shrink compositor surfaces.
- Let inference offload weights or KV cache to RAM, accepting a measurable throughput cost.
- Never terminate DWM.

## Read-Only Verification
```powershell
nvidia-smi --query-gpu=memory.total,memory.used,memory.free --format=csv
```
Note: Get-Process does not expose a DedicatedMemory GPU property.

## Unknown
- Per-allocation GPU accounting: unknown
- Exact KV-cache bytes: unknown
- Shared-memory contribution at load: unknown
