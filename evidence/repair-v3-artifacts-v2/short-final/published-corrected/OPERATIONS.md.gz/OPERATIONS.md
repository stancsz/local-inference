# Local LiteLLM Stack — Daily Runbook

## Start the stack

```powershell
docker compose up -d --build
```

## Check both ports

```powershell
curl.exe http://127.0.0.1:8090/health/readiness
curl.exe http://127.0.0.1:8091/health
```

## Run acceptance

```powershell
python scripts/claude_acceptance.py
```

## Inspect gateway Sift logs

```powershell
docker compose logs --no-color gateway > tmp/sift-runtime.log
```

## Stop only this compose project

```powershell
docker compose down
```

## Configured compaction limit

```
context_window=40960
sift_target=32768
output_reserve=4096
draft_tokens=4
```

The adaptive policy is request-dependent. `sift_target=32768` is the anchor, not a fixed forwarded budget. Short requests pass unchanged. Larger histories use `ceil(native_raw_tokens / 8)`, bounded to 24,576–36,608 when reserving all 4,096 output tokens. 36,608 is a ceiling, not a required request size. The Sift target is part of the input budget, never added to it; a further 256 tokens are held for decoder headroom.

## Why health is insufficient

A readiness response alone proves process readiness, not productive work.
