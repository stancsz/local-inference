# VRAM Plan

## Disk sizes (model-manifest.json) — raw bytes
- Raw model `Qwen3.8-27B-UD-IQ3_XXS.gguf`: 10934860704 bytes
- MTP `MTP/mtp-Qwen3.8-27B-Q4_0.gguf`: 1369590656 bytes
- Combined: 12304451360 bytes

These are on-disk GGUF file sizes only.

## Measured runtime delta (not disk size)
- host-vram.json: observed_inference_delta_mib = 13743 (14410579968 bytes)
- runtime-vram.json: no inference delta recorded (unknown).

The runtime delta is a live host measurement and is NOT the disk size.

## Host totals (host-vram.json, older snapshot)
host_total_mib=16303
host_used_mib=15252
host_free_mib=13991

## Runtime snapshot (runtime-vram.json)
gpu CSV order is name,total,used,free:
"NVIDIA GeForce RTX 5070 Ti, 16303 MiB, 2005 MiB, 13991 MiB"

## Three largest measured process consumers (runtime-vram.json)
| Process | PID | Dedicated MiB |
|---------|-----|---------------|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

WDDM process counters may overlap; do not sum as physical GPU usage.

## Safe VRAM reclamation (after saving work)
- Close unused browser tabs or disable browser acceleration after saving work.
- Use a lower resolution or fewer active displays to reduce compositor surfaces.
- Inference can offload weights or KV cache to RAM, at a measurable throughput cost.
- Never terminate DWM.

## Verification (PowerShell)
```powershell
Get-Process | Sort-Object @{e="GPU";e={(Get-Counter -Counter '\GPU Process(*)\Dedicated Usage(*)' -ErrorAction SilentlyContinue).CounterSet[0].CookedValue}} | Select-Object -First 3 Name, Id
```

Unmeasured facts are marked unknown; no model sizes are guessed.
