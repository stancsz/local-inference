def audit_manifest(records):
    files = 0
    total_bytes = 0
    components = {}
    paths = set()
    for record in records:
        path = record["path"]
        size = record["size_bytes"]
        record["sha256"]
        component = record.get("component", "app")
        files += 1
        total_bytes += size
        components[component] = components.get(component, 0) + size
        paths.add(path)
    return {
        "files": files,
        "bytes": total_bytes,
        "components": components,
        "paths": sorted(paths),
    }

