import json,sys,urllib.request
from pathlib import Path
root=Path.cwd();sys.path[:0]=[str(root/'app'),str(root/'scripts')]
import budget
from setup_env import gateway_key
rows=[]
for scenario in ('compressible_history','protected_current_task'):
    repeats=5000
    for _ in range(5):
        history='Completed ordinary service record with no changes. '*repeats
        messages=([{'role':'user','content':history},{'role':'assistant','content':'recorded'},{'role':'user','content':'Reply exactly BUDGET_REPAIR_OK'}]
            if scenario=='compressible_history' else [{'role':'user','content':history+'\nReply exactly BUDGET_REPAIR_OK'}])
        payload={'model':'qwen3.8-27b','messages':messages,'max_tokens':32,'temperature':0}
        raw=budget.count(payload)
        if 34500<=raw<=35500:break
        repeats=max(1,int(repeats*35000/raw))
    assert 32768<raw<=36608
    _,audit=budget.compact(payload)
    if scenario=='compressible_history':
        assert audit['target_tokens']==24576 and not audit['protected_fit_fallback']
    else:
        assert audit['protected_fit_fallback'] and audit['native_input_tokens']==raw
    request=urllib.request.Request('http://127.0.0.1:8090/v1/messages',data=json.dumps(payload).encode(),headers={'Authorization':'Bearer '+gateway_key(),'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=300) as response:result=json.load(response)
    assert 'BUDGET_REPAIR_OK' in json.dumps(result.get('content'))
    actual=next(json.loads(line)for line in reversed((root/'evidence/gateway-audit.jsonl').read_text().splitlines())
        if json.loads(line).get('compaction_input_sha256')==budget.compaction_digest(payload))
    assert actual['native_input_tokens']==audit['native_input_tokens']
    assert actual['protected_fit_fallback']==audit['protected_fit_fallback']
    rows.append({'scenario':scenario,'raw_native_tokens':raw,'audit':actual,'answer':result['content'],'passed':True})
print(json.dumps({'requests':rows,'scope':'Actual native-window policy regression, not long-session qualification'},indent=2))
