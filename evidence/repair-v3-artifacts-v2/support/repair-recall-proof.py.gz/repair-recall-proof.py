import importlib.util,io,json,sys,types,unittest,hashlib
from pathlib import Path
root=Path.cwd()
path=root.parent/'sift/tests/test_issue59_history_recall.py'
spec=importlib.util.spec_from_file_location('recall_cases',path)
cases=importlib.util.module_from_spec(spec);spec.loader.exec_module(cases)
source=root/'tmp/stress/sift-candidate/src/sift/core.py'
baseline=types.ModuleType('frozen_recall_core');sys.modules[baseline.__name__]=baseline
exec(compile(source.read_text(encoding='utf-8'),str(source),'exec'),baseline.__dict__)
current=cases.compact_messages
rows={}
for name,implementation in [('frozen_campaign',baseline.compact_messages),('sift_0_11_1',current)]:
    cases.compact_messages=implementation
    output=io.StringIO()
    result=unittest.TextTestRunner(stream=output).run(unittest.defaultTestLoader.loadTestsFromTestCase(cases.HistoryRecallTests))
    rows[name]={'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'output':output.getvalue()}
assert rows['frozen_campaign']['failures']>0 and rows['frozen_campaign']['errors']==0
assert rows['sift_0_11_1']['failures']==rows['sift_0_11_1']['errors']==0
print(json.dumps({'verified':True,'scope':'Generic source/diagnostic competition regression, not exact replay of missing original request payloads',
    'baseline_core_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'results':rows},indent=2))
