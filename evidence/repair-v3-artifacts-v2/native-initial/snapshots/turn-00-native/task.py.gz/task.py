def audit_manifest(records):
    files = 0
    bytes_total = 0
    components = {}
    paths = []
    for record in records:
        path = record['path']
        size = record['size_bytes']
        record['sha256']
        component = record.get('component', 'app')
        files += 1
        bytes_total += size
        components[component] = components.get(component, 0) + size
        paths.append(path)
    return {
        'files': files,
        'bytes': bytes_total,
        'components': components,
        'paths': sorted(paths),
    }
