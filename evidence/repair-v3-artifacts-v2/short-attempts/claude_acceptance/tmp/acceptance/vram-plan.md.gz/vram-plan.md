# VRAM Plan

## Manifest disk sizes (model-manifest.json, unsloth/Qwen3.8-27B-GGUF @ 4ca720788d1e01f1bff70c033e0d0028fd02e502)

- Raw model `Qwen3.8-27B-UD-IQ3_XXS.gguf`: 10934860704 bytes
- MTP `MTP/mtp-Qwen3.8-27B-Q4_0.gguf`: 1369590656 bytes
- Combined: 12304451360 bytes

These are on-disk file sizes. They are not the measured runtime VRAM delta.

## Measured runtime delta (runtime-vram.json)

- `observed_inference_delta_mib`: 13743 MiB
- `observed_inference_delta_bytes`: 14410579968 bytes
- `baseline_host_used_mib`: 1509, `loaded_host_used_mib`: 15252
- `under_14_decimal_GB_by_delta`: false

The runtime delta exceeds the combined manifest disk bytes (14410579968 > 12304451360) because the host delta includes runtime caches/buffers and possible unrelated desktop drift; it is not per-allocation accounting. vmwp dedicated counters (13803126784 + 24059904 bytes) can overlap and are not physical GPU totals.

## Host snapshot (host-vram.json, older snapshot: 2026-10-26T19:00:03Z)

host_total_mib=16303
host_used_mib=2005
host_free_mib=13991

GPU: NVIDIA GeForce RTX 5070 Ti (host-vram.json).

## Three largest measured process consumers (host-vram.json)

| Process | PID | Dedicated MiB |
|---------|-----|---------------|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

WDDM process counters may overlap; do not sum as physical GPU usage.

## Safe VRAM reclamation after saving work

- Close unused browser tabs or disable browser acceleration after saving work.
- Use a lower resolution or fewer active displays to reduce compositor surfaces.
- Inference can offload weights or KV cache to RAM, at a measurable throughput cost.
- Never terminate DWM.

## Verification

```powershell
Get-Process | Where-Object { $_.Id -in 195736, 57080, 311156 } | Select-Object Id, ProcessName
```

Unknown: no other runtime measurement is available for post-reclamation host VRAM.
