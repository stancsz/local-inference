# VRAM Plan — repair-v3-claude-fresh

## Disk sizes (raw bytes, from evidence/model-manifest.json)
- Raw model (Qwen3.8-27B-UD-IQ3_XXS.gguf): 10934860704 bytes
- MTP (mtp-Qwen3.8-27B-Q4_0.gguf): 1369590656 bytes
- Combined disk: 12304451360 bytes

Disk size is the on-disk GGUF file size. It is NOT the measured runtime delta:
- Measured runtime delta (evidence/runtime-vram.json): observed_inference_delta_mib = 13743 MiB = 14410579968 bytes.
- The runtime delta is larger than the raw model disk size because it includes KV cache, runtime buffers, and possible unrelated desktop drift (per the runtime caveat). It is not per-allocation accounting.

## Host snapshot (older) — evidence/host-vram.json (captured 2026-10-26T19:00:03Z)
- GPU: NVIDIA GeForce RTX 5070 Ti
- host_total_mib=16303
- host_used_mib=2005
- host_free_mib=13991

## Runtime snapshot (newer) — evidence/runtime-vram.json (captured 2026-10-26T23:32:04Z)
- baseline_host_used_mib=1509
- loaded_host_used_mib=15252
- observed_inference_delta_mib=13743

## Measured host process consumers (evidence/host-vram.json)
Only the three largest measured consumers are listed:

| Process | PID | Dedicated MiB |
| --- | --- | --- |
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

WDDM process counters may overlap; do not sum them as physical GPU usage.

## Safe VRAM reclamation after saving work
- Close unused browser tabs or disable browser hardware acceleration after saving work.
- Use a lower resolution or fewer active displays to reduce compositor surfaces.
- Inference can offload weights or KV cache to RAM, at a measurable throughput cost.
- Never terminate DWM.

## Verification (PowerShell)
```powershell
nvidia-smi --query-gpu=memory.total,memory.used,memory.free --format=csv,noheader
```
