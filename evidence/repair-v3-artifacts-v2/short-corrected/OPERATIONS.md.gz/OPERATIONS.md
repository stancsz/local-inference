# Local LiteLLM Stack Operations

## Start

```powershell
docker compose up -d --build
```

## Check both ports

```powershell
curl.exe http://127.0.0.1:8090/health/readiness
curl.exe http://127.0.0.1:8091/health
```

## Run acceptance

```powershell
python scripts/claude_acceptance.py
```

## Inspect gateway Sift logs

```powershell
docker compose logs --no-color gateway > tmp/sift-runtime.log
```

## Stop only this compose project

```powershell
docker compose down
```

## Daily configuration

The current daily default is a request-adaptive policy. Configuration lines:

```text
context_window=40960
sift_target=32768
output_reserve=4096
draft_tokens=4
```

`SIFT_TARGET=32768` is the adaptive policy anchor, not a fixed forwarded budget. The Sift target is part of the input budget and is never added to it. The adaptive policy selects a budget per request: short requests within the anchor pass unchanged, while larger histories use a size-based ratio bounded to 24576..36608 when reserving all 4096 output tokens. 36608 is a ceiling, not a required request size. A further 256 tokens are held for decoder headroom.

## Why health is not productivity evidence

A readiness response alone proves process readiness, not productive work.
