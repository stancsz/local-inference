"""Publish immutable final review provenance and commander's full-scope audit."""
import datetime,gzip,hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path.cwd();DEST=ROOT/'evidence/final-daily-driver-acceptance-v1';DEST.mkdir(exist_ok=False)
artifacts=[]
secrets=[v.encode()for k,v in os.environ.items()if len(v)>12 and any(x in k.upper()for x in ('KEY','TOKEN','SECRET','PASSWORD'))]
for line in (ROOT/'.env').read_text().splitlines():
 if line.startswith('LOCAL_GATEWAY_KEY='):secrets.append(line.split('=',1)[1].strip().encode())
def archive(path):
 raw=path.read_bytes();assert not any(s and s in raw for s in secrets),path
 target=DEST/(path.relative_to(ROOT/'tmp/stress').as_posix()+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 data=gzip.compress(raw,mtime=0);target.write_bytes(data)
 artifacts.append({'path':target.relative_to(ROOT).as_posix(),'raw_sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':hashlib.sha256(data).hexdigest()})
for prefix in ('codex-goal-disposition-v1','codex-publication-followup-v1','publication-observation-v2'):
 for path in sorted((ROOT/'tmp/stress').glob(prefix+'.*')):archive(path)
for name in ('reconcile-goal-pages-v1.py','publication-handoff-v1.py','publish-final-daily-driver-v1.py','disposition-final-local.json','disposition-final-openai.json','final-daily-driver-suite-v1.log'):archive(ROOT/'tmp/stress'/name)
def messages(prefix):
 events=[json.loads(line)for line in (ROOT/'tmp/stress'/f'{prefix}.jsonl').read_text().splitlines()]
 text=[e['item']['text']for e in events if e.get('type')=='item.completed'and e.get('item',{}).get('type')=='agent_message'][-1]
 return events,json.loads(text)
events,review=messages('codex-publication-followup-v1');_,previous=messages('codex-goal-disposition-v1')
assert review['verdict']=='READY' and not review['remaining_work'] and previous['verdict']=='NOT_READY'
calls=[e['item']for e in events if e.get('type')=='item.completed'and e.get('item',{}).get('type')=='command_execution']
assert len(calls)==1 and calls[0]['exit_code']==0
assert '432 passed'in (ROOT/'tmp/stress/final-daily-driver-suite-v1.log').read_text()
for name in ('local','openai'):assert json.loads((ROOT/f'tmp/stress/disposition-final-{name}.json').read_text())['passed']
publication=json.loads((ROOT/'tmp/stress/publication-observation-v2.json').read_text());assert publication['all_checks_passed']
parent=json.loads((ROOT/'evidence/codex-shared-mtp-v1-parent-review.json').read_text());assert parent['parent_qualified'] and parent['candidate_total_after_parent']==24
runtime=[]
for service in ('inference','gateway'):
 row=json.loads(subprocess.check_output(['docker','inspect',f'local-inference-{service}-1'],text=True))[0]
 assert row['State']['Running'];runtime.append({'service':service,'image':row['Image'],'running':True})
parity=json.loads((ROOT/'evidence/final-acceptance-runtime.json').read_text())
for name,digest in parity['app'].items():
 path=ROOT/name if name=='gateway.yaml'else ROOT/'app'/name
 assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
mounted=subprocess.check_output(['docker','exec','local-inference-inference-1','cat','/start-inference.sh'])
assert mounted==(ROOT/'docker/start-inference.sh').read_bytes()
requirements=[
 ('Standalone Docker local gateway, local Qwen27B3/4bit and MTP; no cloud fallback','evidence/final-goal-review-v1.json'),
 ('Preserve caller approvals, tools, sandbox, config and mandatory content; fail closed','evidence/repair-v3-independent-review.json'),
 ('Request-adaptive Sift budgeting;256k/1M raw histories within native context limits','evidence/vm-residency-v1/parent-review.json'),
 ('Exact65536 input+4096 output; productive daily and optional long settings','evidence/vm-residency-v1/parent-review.json'),
 ('Model/MTP under14decimalGB during sampled workload, containing-VM upper bound','evidence/review-protocol-recovery-v1.json'),
 ('Reproducible MTP on/off speed and restored original daily runtime','evidence/shared-mtp-pair-v1-parent-review.json'),
 ('Three real native Claude productivity tasks with actual artifact replay','evidence/vm-residency-v1/parent-review.json'),
 ('At least21 qualifying sessions, seven per client;9turns,>180seconds, history/tools/tests','evidence/codex-shared-mtp-v1-parent-review.json'),
 ('Fix Sift source/diagnostic competition with causal regressions and new native captures','evidence/repair-v3-recall-regressions.json'),
 ('Fix native CLI grading and archive per-turn code; preserve historical failures','evidence/codex-shared-mtp-v1-publication.json'),
 ('Validate actual model-generated contract repairs with unchanged checks and feedback','evidence/expense-feedback-v3-parent-review.json'),
 ('Improve both repositories and commit/push scoped work; verify publication','evidence/repair-disposition-publication-v1.json'),
 ('Reproducible setup and practical daily workflow; explicit limits','docs/SETUP.md'),
 ('Nonauthor full-goal review after parent audit','evidence/final-daily-driver-acceptance-v1.json')]
report={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifact_commit':publication['artifact_commit'],'full_goal':'READY','commander_acceptance':'READY for documented local daily-driver goal; no universal model correctness/retention/hardware claim','nonauthor_verdict':review,'previous_nonauthor_verdict':previous,'reviewer_session_id':'01a18012-20b9-7ad1-a1e8-45e31830e6a0','review_route':'http://127.0.0.1:4000/v1','review_model':'default','review_sandbox':'read-only; unchanged; remote denial preserved, no escalation','qualification_increment':0,'qualified_sessions':24,'per_client':parent['per_client_after_parent'],'requirements':[{'criterion':name,'status':'MET_WITH_DOCUMENTED_BOUNDS','primary_evidence':path}for name,path in requirements],'parent_current_runtime':runtime,'parent_fresh_checks':{'project_tests':432,'local_smoke':True,'openai_smoke':True,'startup_mount_byte_identity':True,'app_source_hashes_unchanged':True},'publication_observation':publication,'credential_status':'Both same-session follow-ups used distinct scoped keys; finally blocks record successful revocation. No credential values published.','remaining_required_work':[],'remaining_limits':review['evidence_limitations']+['Provider-hosted MCP approval/opaque encrypted reasoning states are unsupported and return422, rather than silently altering caller permissions.','Normal interactive approvals were inspected in source/regressions; no universal live interactive prompt compatibility claim.','Windows launcher/platform and measured hardware only; optional equivalent-cloud savings target remains unmeasured.'],'artifacts':artifacts}
for _,path in requirements:
 if path!='evidence/final-daily-driver-acceptance-v1.json':assert (ROOT/path).is_file(),path
(ROOT/'evidence/final-daily-driver-acceptance-v1.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'full_goal':'READY','archived_files':len(artifacts),'requirements_audited':len(requirements),'qualified_sessions':24,'project_tests':432}))
