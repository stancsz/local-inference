"""Read-only current dispositions, actual sources and live remote publication."""
import gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts'),str(ROOT.parent/'sift/src'),str(ROOT/'app')]
def command(args,cwd=ROOT):
 result=subprocess.run(args,cwd=cwd,capture_output=True,text=True,encoding='utf-8',timeout=90)
 assert result.returncode==0,(args,result.stdout,result.stderr)
 return result.stdout.strip()
section=sys.argv[1]
if section=='disposition':
 print((ROOT/'docs/REPAIR_V3.md').read_text().split('The standalone gateway now runs')[0])
 text=(ROOT/'GOAL.md').read_text();start=text.index('Ask: stress the recent Sift');print(text[start:text.index('Candidate:',start)])
 old=json.loads((ROOT/'evidence/balanced-v2-independent-review.json').read_text());print('Prior independent requested action:',old['smallest_next_action'])
 for name in ('stress-independent-review.json','balanced-v2-independent-review.json'):
  data=json.loads((ROOT/'evidence'/name).read_text());print(name,json.dumps({k:v for k,v in data.items()if k in ('verdict','full_goal','smallest_next_action','limits')}))
 regression=json.loads((ROOT/'evidence/repair-v3-recall-regressions.json').read_text())
 print('Source recall reproduction scope:',regression['scope'])
 print({k:{field:row[field]for field in ('tests','failures','errors')}for k,row in regression['results'].items()})
 print(command([sys.executable,'-m','unittest','discover','-s',str(ROOT.parent/'sift/tests'),'-p','test_issue59_history_recall.py']))
 print(command([sys.executable,'-m','pytest','-q','-p','no:cacheprovider','tests/test_native_v3.py','tests/test_claude_settings_compat.py']))
 from sift.core import _stable_anchors,_bounded_anchors
 import inspect
 print(inspect.getsource(_stable_anchors));print(inspect.getsource(_bounded_anchors))
 print((ROOT/'stress/native_v3.py').read_text())
elif section=='codex':
 parent=json.loads((ROOT/'evidence/codex-shared-mtp-v1-parent-review.json').read_text())
 print(json.dumps({k:v for k,v in parent.items()if k not in ('turns','captures')}))
 folder=ROOT/'evidence/codex-shared-mtp-v1'
 receipt=json.loads(gzip.decompress((folder/'result.json.gz').read_bytes()))
 assert receipt['accepted'] and len(receipt['turns'])==9
 from stress.campaign_v3 import parse_events,session_id
 from stress.native_v3 import native_evidence
 from stress.balanced_review_v2 import inspect_capture
 plan=json.loads((ROOT/'evidence/codex-shared-mtp-v1-plan.json').read_text());workspace=ROOT/plan['output_dir']/'workspace'
 for index,turn in enumerate(receipt['turns']):
  events=parse_events(gzip.decompress((folder/f'turn-{index:02}.jsonl.gz').read_bytes()).decode())
  assert native_evidence('codex',events,workspace)==turn['native']
  assert session_id('codex',events)==receipt['session_id'] and turn['accepted'] and not turn['timed_out'] and turn['duration_seconds']<240
  for label in ('native','hidden'):
   snap=folder/'snapshots'/f'turn-{index:02}-{label}'
   manifest=json.loads(gzip.decompress((snap/'hashes.json.gz').read_bytes()))
   for name,digest in manifest['sha256'].items():
    if digest is not None:assert hashlib.sha256(gzip.decompress((snap/(name+'.gz')).read_bytes())).hexdigest()==digest
 for index,audit in enumerate(receipt['audits']):
  errors,row=inspect_capture(gzip.decompress((folder/'requests'/audit['excerpt_capture']).read_bytes()),index,audit)
  assert not errors and row['original_fact_observed_in_source0'] and audit['upstream_status']==200
 assert all(a['native_input_tokens']+a['output_reserve']+a['decoder_headroom']<=a['context_window']for a in receipt['native_gateway_audits'])
 assert parent['parent_qualified'] and parent['candidate_total_after_parent']==24
 assert len(parent['turns'])==9 and all(test['exit']==0 for turn in parent['turns']for snapshot in turn['snapshots']for test in snapshot['behavior'])
 print({'native_continuity_replayed':9,'snapshot_hashes_rechecked':18,'source_captures_rechecked':len(receipt['audits']),'prior_independent_full_behavior_replay':'54 checks executed in final-goal-review-v1; current inspection verifies those unchanged snapshots/results without writing files','counts':parent['per_client_after_parent']})
 print(gzip.decompress((folder/'workspace/task.py.gz').read_bytes()).decode())
elif section=='publication':
 head=command(['git','rev-parse','HEAD']);remote=command(['git','ls-remote','origin','refs/heads/main']).split()[0];assert head==remote
 print({'head':head,'origin_main':remote})
 for number in (61,62):
  pr=json.loads(command(['gh','pr','view',str(number),'--repo','stancsz/sift','--json','state,mergeCommit,mergedAt,url,title']));assert pr['state']=='MERGED';print(pr)
 print(command([sys.executable,'evidence/profile-publication-tools/check-profile-publication.py','--commit','HEAD']))
 assert not command(['git','diff','c5415ad','HEAD','--name-only','--','evidence/balanced-v2-sessions','evidence/balanced-v2-parent-review.json','evidence/stress-sessions','evidence/stress-summary.json'])
 print('Named frozen campaign paths unchanged since c5415ad; no rejected result promoted.')
 print((ROOT/'scripts/claude_local.py').read_text())
elif section=='verifier':
 print(Path(__file__).read_text());print((ROOT/'tmp/stress/final-goal-review-pages-v1.py').read_text())
else:raise ValueError(section)
