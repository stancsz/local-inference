import hashlib,json,os,subprocess,sys,urllib.request,uuid
from pathlib import Path
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT.parent/'sift/src')]
from stress.cli_acceptance import child_command,executable
BASE='http://127.0.0.1:4000';PREFIX=ROOT/'tmp/stress/codex-goal-disposition-v1'
def request(path,body,key):
 req=urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=60)as response:return json.load(response)
master=os.environ['GATEWAY_MASTER_KEY'];alias='codex-vm-review-'+uuid.uuid4().hex[:10]
key=request('/key/generate',{'key_alias':alias,'models':['default'],'duration':'10m','max_budget':5},master)['key']
commands=['python tmp/stress/reconcile-goal-pages-v1.py '+name for name in ('verifier','disposition','codex','publication')]+['python tmp/stress/final-goal-review-pages-v1.py --section '+name for name in ('engineering','migration','expenses')]
prompt='Bounded follow-up to YOUR same read-only full-goal review session. You previously accepted memory MET_WITH_BOUNDS and other criteria but left prior campaign findings and publication unresolved. New evidence now explicitly maps every prior finding to later repair or an honest residual limitation; remote equality and merged Sift PRs can be freshly inspected. You remain a NONAUTHOR reviewer. Read all SEVEN exact command pages below using native exec_command max_output_tokens6000; finish yielded commands with write_stdin. No other commands, writes, provider requests, changes, delegation or credential access. The publication page may perform read-only git ls-remote and gh PR inspection, expressly authorized. Reuse your prior memory and product checks unchanged. Review actual generated engineering/migration/expense artifacts and rerun their unchanged regression/original-behavior checks. Assess original adopted acceptance language:21 qualifying persisted sessions,7/client,nine substantive turns,over180active seconds,native tools,hidden/public tests,history/source identity; never promote frozen rejections. Old reviewer requested one new Codex seed with per-turn snapshots after source/parser repair; examine whether the completed new case satisfies it. Exact original missing full payload replay is unavailable: generic causal regression plus new nine-turn original-source capture is the bounded replacement proof, explicitly disclosed. Historical failures remain facts, not claims of universal future correctness. Judge whether current bounded daily-driver goal is READY/NOT_READY/UNVERIFIED. Do not approve because parent asks; conversely do not treat an old NOT_READY label alone as an unresolvable gate. If not ready name the exact original unmet criterion, observed current defect or missing evidence, and smallest useful action. Return JSON full-goal verdict, findings with dispositions, criterion statuses, remaining work and limitations.\n'+'\n'.join(json.dumps({'cmd':c,'max_output_tokens':6000})for c in commands)

try:
 home=ROOT/'tmp/stress/codex-vm-review-client-v2';assert home.exists()
 command,env=child_command('codex',executable('codex'),home,BASE+'/v1','default',prompt,persist=True,session_id='01a18012-20b9-7ad1-a1e8-45e31830e6a0')
 command=[a.replace('workspace-write','read-only')if a=='workspace-write'or a.startswith('sandbox_mode=')else a for a in command]
 env['SIFT_LOCAL_KEY']=key
 env['PYTHONDONTWRITEBYTECODE']='1'
 env['PYTHONPATH']=';'.join([str(ROOT),str(ROOT/'scripts'),str(ROOT.parent/'sift/src'),str(ROOT/'app')])
 plan={'route':BASE+'/v1','model':'default','sandbox':'read-only','artifact_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'helper_sha256':hashlib.sha256((ROOT/'tmp/stress/reconcile-goal-pages-v1.py').read_bytes()).hexdigest(),'commands':commands,'argv':command[:-1]+['[PROMPT IN SEPARATE CAPTURE]'],'timeout_seconds':300,'scope':'fresh nonauthor full-goal follow-up of current finding disposition/publication; same eligible reviewer; previous accepted scope reused'}
 PREFIX.with_suffix('.plan.json').write_text(json.dumps(plan,indent=2));PREFIX.with_suffix('.prompt.txt').write_text(prompt,encoding='utf-8')
 with PREFIX.with_suffix('.jsonl').open('x',encoding='utf-8')as out,PREFIX.with_suffix('.stderr.log').open('x',encoding='utf-8')as err:
  process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=out,stderr=err)
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:
   subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);process.wait(timeout=20);raise
 PREFIX.with_suffix('.exit.json').write_text(json.dumps({'exit_code':code,'alias':alias}))
finally:
 request('/key/delete',{'key_aliases':[alias]},master);PREFIX.with_suffix('.revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
print('Codex full-goal review terminal; scoped key revoked',flush=True)
