"""Capture parent-permitted read-only remote and immutable publication checks."""
import datetime,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();records=[]
def execute(args):
 run=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=90)
 row={'argv':args,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
 records.append(row);assert run.returncode==0,row
 return run.stdout.strip()
head=execute(['git','rev-parse','HEAD']);remote=execute(['git','ls-remote','origin','refs/heads/main']).split()[0];assert head==remote
for number in (61,62):
 pr=json.loads(execute(['gh','pr','view',str(number),'--repo','stancsz/sift','--json','state,mergeCommit,mergedAt,url,title']));assert pr['state']=='MERGED'
assert not execute(['git','diff','c5415ad','HEAD','--name-only','--','evidence/balanced-v2-sessions','evidence/balanced-v2-parent-review.json','evidence/stress-sessions','evidence/stress-summary.json'])
proof=json.loads(execute([sys.executable,'evidence/profile-publication-tools/check-profile-publication.py','--commit','HEAD']));assert proof['mismatches']==0
report={'scope':'Parent-permitted read-only publication observation. Nonauthor sandbox network denial is retained, not bypassed. Reviewer may inspect this evidence but must not represent it as its own fresh network query.','artifact_commit':head,'origin_main':remote,'all_checks_passed':True,'commands':records,'collector_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'qualification_increment':0}
output=ROOT/'tmp/stress/publication-observation-v2.json'
with output.open('x',encoding='utf-8')as f:json.dump(report,f,indent=2)
print(json.dumps({'artifact_commit':head,'origin_main':remote,'files_verified':proof['files_verified'],'mismatches':0}))
