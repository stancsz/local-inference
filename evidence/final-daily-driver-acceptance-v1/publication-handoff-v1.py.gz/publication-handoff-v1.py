"""Inspect parent publication observation without bypassing reviewer networking."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path.cwd()
source=ROOT/'tmp/stress/publication-observation-v2.py'
receipt=json.loads((ROOT/'tmp/stress/publication-observation-v2.json').read_text())
assert hashlib.sha256(source.read_bytes()).hexdigest()==receipt['collector_sha256']
print(source.read_text());print(json.dumps(receipt,indent=2))
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head==receipt['artifact_commit']==receipt['origin_main']
proof=json.loads(subprocess.check_output(['python','evidence/profile-publication-tools/check-profile-publication.py','--commit','HEAD'],text=True));assert proof['mismatches']==0;print(proof)
changes=subprocess.check_output(['git','diff','7a6e1df','HEAD','--','README.md','VERIFICATION.md','docs/SETUP.md','docs/PROFILE_RESULTS.md'],text=True,encoding='utf-8');print(changes)
assert not subprocess.check_output(['git','diff','7a6e1df','HEAD','--name-only','--','app','scripts','stress','recovery','docker','compose.yaml','compose.long.yaml'],text=True).strip()
for name in ('local','openai'):
 data=json.loads((ROOT/f'tmp/stress/disposition-final-{name}.json').read_text());print({'fresh_parent_product_smoke':name,'passed':data.get('passed')});assert data['passed']
print('Current source unchanged; parent freshly observed publication through permitted network. Reviewer remote denial remains recorded. No sandbox or approval setting was changed.')
