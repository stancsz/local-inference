import hashlib,json,os,subprocess,sys,urllib.request,uuid
from pathlib import Path
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT.parent/'sift/src')]
from stress.cli_acceptance import child_command,executable
BASE='http://127.0.0.1:4000';PREFIX=ROOT/'tmp/stress/codex-publication-followup-v1'
def request(path,body,key):
 req=urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=60)as response:return json.load(response)
master=os.environ['GATEWAY_MASTER_KEY'];alias='codex-vm-review-'+uuid.uuid4().hex[:10]
key=request('/key/generate',{'key_alias':alias,'models':['default'],'duration':'10m','max_budget':5},master)['key']
commands=['python tmp/stress/publication-handoff-v1.py']
prompt='Final bounded follow-up to YOUR same nonauthor review. Your last verdict resolved campaign/artifact findings and said no remaining evidence-based blocker if publication checks pass. The read-only sandbox GitHub network denial is preserved and must not be bypassed. Parent has now run the exact git/gh/publication commands successfully through its already-permitted network, capturing argv, observed times, stdout/stderr, exact HEAD/origin equality, merged PR61/62 and712 immutable hashes. This is parent-observed evidence, not your own remote query. Execute only the one exact command below with native exec_command max_output_tokens6000; finish a yielded handle. It reads collector and raw observation, independently checks current Git HEAD, repeats immutable publication locally, shows the docs-only correction since your review, confirms product source unchanged and reads fresh parent local/OpenAI smoke results. Do not modify files, relax settings, request elevation, delegate, access credentials or attempt network again. Judge whether the actual original commit/push requirement is supported by this inspectable evidence; it does not require you personally bypass a network boundary. Reuse your prior accepted criteria, retaining all bounds, historical rejections and generic-versus-exact source replay limitation. Return one JSON FULL-GOAL verdict READY/NOT_READY/UNVERIFIED, actual checks, criterion dispositions, remaining work and evidence limitations. Do not approve merely because requested; name any actual missing criterion if not ready.\n'+json.dumps({'cmd':commands[0],'max_output_tokens':6000})

try:
 home=ROOT/'tmp/stress/codex-vm-review-client-v2';assert home.exists()
 command,env=child_command('codex',executable('codex'),home,BASE+'/v1','default',prompt,persist=True,session_id='01a18012-20b9-7ad1-a1e8-45e31830e6a0')
 command=[a.replace('workspace-write','read-only')if a=='workspace-write'or a.startswith('sandbox_mode=')else a for a in command]
 env['SIFT_LOCAL_KEY']=key
 env['PYTHONDONTWRITEBYTECODE']='1'
 env['PYTHONPATH']=';'.join([str(ROOT),str(ROOT/'scripts'),str(ROOT.parent/'sift/src'),str(ROOT/'app')])
 plan={'route':BASE+'/v1','model':'default','sandbox':'read-only','artifact_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'helper_sha256':hashlib.sha256((ROOT/'tmp/stress/publication-handoff-v1.py').read_bytes()).hexdigest(),'commands':commands,'argv':command[:-1]+['[PROMPT IN SEPARATE CAPTURE]'],'timeout_seconds':300,'scope':'fresh nonauthor full-goal follow-up of current finding disposition/publication; same eligible reviewer; previous accepted scope reused'}
 PREFIX.with_suffix('.plan.json').write_text(json.dumps(plan,indent=2));PREFIX.with_suffix('.prompt.txt').write_text(prompt,encoding='utf-8')
 with PREFIX.with_suffix('.jsonl').open('x',encoding='utf-8')as out,PREFIX.with_suffix('.stderr.log').open('x',encoding='utf-8')as err:
  process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=out,stderr=err)
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:
   subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);process.wait(timeout=20);raise
 PREFIX.with_suffix('.exit.json').write_text(json.dumps({'exit_code':code,'alias':alias}))
finally:
 request('/key/delete',{'key_aliases':[alias]},master);PREFIX.with_suffix('.revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
print('Codex full-goal review terminal; scoped key revoked',flush=True)
