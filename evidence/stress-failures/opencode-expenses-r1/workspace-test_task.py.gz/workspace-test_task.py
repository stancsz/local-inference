import unittest

class Acceptance(unittest.TestCase):
    def test_behavior(self):
        import task
        from decimal import Decimal
        data = 'category,amount\nFood,1.005\nfood,2.00\nTransit,3.00\n'
        self.assertEqual(task.expense_totals(data), {'Food': Decimal('3.00'), 'Transit': Decimal('3.00')})
    def test_evidence(self):
        import json
        from pathlib import Path
        value = json.loads(Path('evidence.json').read_text())['acceptance_delay_seconds']
        self.assertIs(type(value), int)

if __name__ == '__main__':
    unittest.main()
