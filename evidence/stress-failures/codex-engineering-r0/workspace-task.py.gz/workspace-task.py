def clamp(value, lower=0, upper=100):
    return value
