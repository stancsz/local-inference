def clamp(value, lower=0, upper=100):
    return max(lower, min(upper, value))

