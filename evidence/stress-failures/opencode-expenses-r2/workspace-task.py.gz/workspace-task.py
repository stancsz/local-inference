import csv
import io
from decimal import Decimal, ROUND_HALF_EVEN

ZERO = Decimal('0.00')
TWO_PLACES = Decimal('0.01')

def _quantize(value):
    return value.quantize(TWO_PLACES, rounding=ROUND_HALF_EVEN)

def expense_totals(csv_text):
    reader = csv.reader(io.StringIO(csv_text))
    rows = list(reader)
    if not rows:
        return {}
    header = [h.strip().lower() for h in rows[0]]
    if header[:2] != ['category', 'amount']:
        return {}
    cat_idx = header.index('category')
    amt_idx = header.index('amount')
    totals = {}
    display = {}
    for row in rows[1:]:
        if not row or all(not cell.strip() for cell in row):
            continue
        if len(row) <= max(cat_idx, amt_idx):
            continue
        raw = row[cat_idx].strip()
        amt = row[amt_idx].strip()
        if not raw or not amt:
            continue
        key = raw.lower()
        totals[key] = totals.get(key, ZERO) + Decimal(amt)
        display.setdefault(key, raw)
    return {display[k]: _quantize(v) for k, v in totals.items()}
