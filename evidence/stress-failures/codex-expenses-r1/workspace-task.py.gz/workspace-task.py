import csv
import io
from decimal import Decimal, ROUND_HALF_EVEN


def expense_totals(csv_text):
    totals = {}
    reader = csv.DictReader(io.StringIO(csv_text))
    for row in reader:
        category = row['category'].strip()
        amount = Decimal(row['amount'])
        totals[category] = totals.get(category, Decimal('0')) + amount
    quantum = Decimal('0.01')
    return {c: t.quantize(quantum, rounding=ROUND_HALF_EVEN) for c, t in totals.items()}
