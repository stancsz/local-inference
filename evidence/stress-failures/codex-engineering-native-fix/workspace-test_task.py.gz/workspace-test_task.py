import unittest

class Acceptance(unittest.TestCase):
    def test_behavior(self):
        import task
        self.assertEqual(task.clamp(-3), 0)
        self.assertEqual(task.clamp(120), 100)
        self.assertEqual(task.clamp(7, 5, 9), 7)
    def test_evidence(self):
        import json
        from pathlib import Path
        value = json.loads(Path('evidence.json').read_text())['acceptance_delay_seconds']
        self.assertIs(type(value), int)

if __name__ == '__main__':
    unittest.main()
