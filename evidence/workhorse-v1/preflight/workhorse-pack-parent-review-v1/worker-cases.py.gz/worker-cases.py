"""Fresh, deterministic representative workhorse tasks; not real outcomes."""
from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile


def _case(i, category, difficulty, prompt, files, artifact, kind, expected, negative):
    return dict(id=f"wh{i:02}", category=category, difficulty=difficulty,
                prompt=prompt, files=files, artifact=artifact, kind=kind,
                _expected=expected), negative


_raw = [
_case(1,"development","routine","Implement merge_pages(pages): flatten pages of records in order, deduplicate by integer id keeping the first occurrence, and return a list. Input records may have extra fields. Empty pages return [].","", "solution.py","python",[1,2],"def merge_pages(pages): return [x for p in pages for x in p]"),
_case(2,"development","moderate","Implement summarize(lines) for JSONL strings. Ignore blank lines; reject malformed JSON lines by counting them. Return exactly {'valid':int,'malformed':int,'by_level':dict,'messages':list}. Count levels (missing => 'unknown') and return message strings with email addresses and IPv4 addresses replaced by [REDACTED], preserving order. Use only stdlib.","", "solution.py","python",{"valid":3,"malformed":1,"by_level":{"warn":1,"unknown":1,"info":1},"messages":["retry [REDACTED]","host [REDACTED]","ok"]},"def summarize(lines): return {'valid':len(lines),'malformed':0,'by_level':{},'messages':list(lines)}"),
_case(3,"development","moderate","Implement normalize_timestamp(value). Accept ISO-8601 timestamps with Z or numeric offset, including fractional seconds. Return UTC ISO string ending Z, seconds precision (truncate fractions), or None for invalid values; naive timestamps are invalid.","", "solution.py","python",["2024-02-29T19:04:05Z",None],"def normalize_timestamp(value): return value"),
_case(4,"development","routine","Implement parse_bool(value, default=False). Accept bool values and case-insensitive trimmed strings true/yes/1/on and false/no/0/off. For all other inputs return default. Do not treat nonempty arbitrary strings as true.","", "solution.py","python",[True,False,False],"def parse_bool(value, default=False): return bool(value)"),
_case(5,"development","moderate","Implement join_rows(left,right). Each row is a dict with key 'sku'. Return left rows enriched by matching right rows, preserving left order, ignoring right-only rows, and preserving left fields on name collision. Duplicate right keys use the last row. Missing/unhashable keys do not match. Return new dicts without mutating inputs.","", "solution.py","python",[{"sku":"a","qty":2,"label":"L","price":8},{"sku":"b","qty":1,"price":5}],"def join_rows(left,right): return left"),
_case(6,"development","judgement","Implement classify_response(status, body). Return exactly {'retry':bool,'reason':str}. Retry only status 429 or 5xx; do not retry other statuses even if body mentions temporary failure. Reason is 'rate_limited' for 429, 'server_error' for 500-599, else 'permanent'. Treat non-integer/unparseable statuses as permanent.","", "solution.py","python",[{"retry":True,"reason":"rate_limited"},{"retry":False,"reason":"permanent"},{"retry":True,"reason":"server_error"}],"def classify_response(status, body): return {'retry':True,'reason':'temporary'}"),
_case(7,"data","routine","Read source.csv and labels.csv. Produce answer.json exactly with keys rows and unmatched. Stable left join on normalized key (trim, Unicode casefold). Preserve source row order and original key spelling. Duplicate label keys: first label row wins. Null/empty keys do not match. Each rows item has source_id, key, label (null if no match); unmatched is source_id list. Do not infer missing labels.",{"source.csv":"source_id,key\n1, Alpha \n2,BETA\n3,ghost\n4,ß\n5,\n","labels.csv":"key,label\nalpha,First\nALPHA,Second\nbeta,Blue\nSS,Sharp S\n,Blank\n"}, "answer.json","json",{"rows":[{"source_id":"1","key":" Alpha ","label":"First"},{"source_id":"2","key":"BETA","label":"Blue"},{"source_id":"3","key":"ghost","label":None},{"source_id":"4","key":"ß","label":"Sharp S"},{"source_id":"5","key":"","label":None}],"unmatched":["3","5"]},"{\"rows\":[],\"unmatched\":[]}"),
_case(8,"data","moderate","Extract only stated facts from memo.txt. answer.json must be exactly {'owner':string|null,'due_date':string|null,'budget_usd':integer|null,'risks':list[string]}. Do not infer owner/date/amount; preserve explicit risk statements as concise exact phrases, in document order.",{"memo.txt":"Pilot note: coordinator is Mei Lin. Due date is 2026-04-12. Budget ceiling: USD 18,400. Risks: vendor feed may arrive late; duplicate records could inflate counts. No other commitments are stated."},"answer.json","json",{"owner":"Mei Lin","due_date":"2026-04-12","budget_usd":18400,"risks":["vendor feed may arrive late","duplicate records could inflate counts"]},"{\"owner\":\"the project team\",\"due_date\":\"2026-04-12\",\"budget_usd\":18400,\"risks\":[]}"),
_case(9,"operations","judgement","Triage incident.txt into answer.json exactly: {'severity':one of low/medium/high,'confirmed':list[string],'hypotheses':list[string],'next_steps':list[string]}. Separate observed facts from possible causes. Do not claim root cause; choose safe, reversible diagnostic actions and preserve data. Include escalation if impact is ongoing.",{"incident.txt":"09:10 dashboard shows 14% fewer completed jobs than baseline. Queue depth rose from 22 to 410 after deploy 7.4.2. Worker error logs are unavailable. A partner reports delayed acknowledgements; no confirmed data loss. At 09:18 queue is still growing. Rollback is possible but schema compatibility has not been checked."},"answer.json","json",{"severity":"high","confirmed":["completed jobs are 14% below baseline","queue depth rose from 22 to 410 after deploy 7.4.2","worker error logs are unavailable","partner reports delayed acknowledgements","queue is still growing at 09:18","no confirmed data loss"],"hypotheses":["deploy 7.4.2 may be related to the queue growth","delayed partner acknowledgements may be contributing"],"next_steps":["page the on-call owner and communicate ongoing impact","preserve queue and deployment evidence; inspect worker health and acknowledgement latency","check rollback schema compatibility before any rollback","avoid destructive queue clearing and verify recovery with completion and queue metrics"]},"{\"severity\":\"high\",\"confirmed\":[],\"hypotheses\":[],\"next_steps\":[]}"),
_case(10,"documents","judgement","Resolve requirements.txt into answer.json exactly {'decision':string,'requirements':list[string],'unresolved':list[string]}. Apply explicit precedence: security prohibition overrides convenience; conflicting retention limits remain unresolved unless a stated precedence resolves them. Do not silently choose between equal-authority conflicts.",{"requirements.txt":"Policy A (security): never log full account identifiers. Policy B (support): include account identifier in diagnostic logs. Retention request: keep raw events 30 days. Records policy: retain raw events 90 days. All statements approved by same role; no precedence supplied."},"answer.json","json",{"decision":"Do not log full account identifiers. Retention duration cannot be determined from the conflicting equal-authority statements; request an owner decision before implementation.","requirements":["never log full account identifiers"],"unresolved":["whether raw events should be retained for 30 or 90 days"]},"{\"decision\":\"Log identifiers and retain for 90 days\",\"requirements\":[\"include account identifier in diagnostic logs\"],\"unresolved\":[]}"),
_case(11,"operations","moderate","Based only on window.txt, answer.json exactly {'action':'proceed'|'hold','checks':list[string],'stop_conditions':list[string]}. Give a safe operational plan. Do not execute, delete, or assume approval. Proceed only if every stated prerequisite is confirmed; otherwise hold.",{"window.txt":"Maintenance window 02:00-02:30 UTC. Restart of two stateless workers requested. Snapshot completed at 01:40. Change approval is pending. One worker is currently draining. No rollback owner is named."},"answer.json","json",{"action":"hold","checks":["confirm change approval","confirm both workers are stateless and drained before restart","name a rollback owner and verify rollback procedure","confirm snapshot remains available"],"stop_conditions":["approval remains pending","either worker is not safely drained","rollback owner or procedure is unavailable","snapshot is unavailable"]},"{\"action\":\"proceed\",\"checks\":[],\"stop_conditions\":[]}"),
_case(12,"data","moderate","Reconcile ledger.csv and report.txt. answer.json exactly {'total_usd_cents':integer,'row_count':integer,'discrepancy':integer|null,'conclusion':string}. Parse CSV amounts as USD decimals, sum cents exactly. Compare stated report total; discrepancy is computed minus stated. Explain difference without inventing cause.",{"ledger.csv":"ref,amount_usd\nA,12.35\nB,-2.10\nC,0.05\nD,100.00\n","report.txt":"Monthly report states 110.29 USD across 4 rows."},"answer.json","json",{"total_usd_cents":11030,"row_count":4,"discrepancy":1,"conclusion":"Ledger total is USD 110.30 across 4 rows, USD 0.01 above the stated USD 110.29; the source does not explain the difference."},"{\"total_usd_cents\":11029,\"row_count\":4,\"discrepancy\":0,\"conclusion\":\"matches\"}"),
]

CASES = []
NEGATIVE_ARTIFACTS = {}
_EXPECTED = {}
for _entry, _negative in _raw:
    _entry["files"] = {**(_entry["files"] if isinstance(_entry["files"], dict) else {})}
    # Python cases receive a deliberately incomplete, executable starting module.
    if _entry["kind"] == "python":
        _entry["files"]["solution.py"] = _negative
        _public = {
          "wh01":"from solution import merge_pages\nclass Public(unittest.TestCase):\n def test_dedup(self): self.assertEqual(merge_pages([[{'id':1},{'id':1}],[{'id':2}]]),[{'id':1},{'id':2}])\n",
          "wh02":"from solution import summarize\nclass Public(unittest.TestCase):\n def test_counts(self): self.assertEqual(summarize(['{\"level\":\"info\",\"message\":\"ok\"}','bad'])['malformed'],1)\n",
          "wh03":"from solution import normalize_timestamp\nclass Public(unittest.TestCase):\n def test_utc(self): self.assertEqual(normalize_timestamp('2024-01-01T01:00:00+01:00'),'2024-01-01T00:00:00Z')\n",
          "wh04":"from solution import parse_bool\nclass Public(unittest.TestCase):\n def test_strict(self): self.assertFalse(parse_bool('maybe'))\n",
          "wh05":"from solution import join_rows\nclass Public(unittest.TestCase):\n def test_left_join(self): self.assertEqual(join_rows([{'sku':'a'}],[]),[{'sku':'a'}])\n",
          "wh06":"from solution import classify_response\nclass Public(unittest.TestCase):\n def test_only_server_errors_retry(self): self.assertFalse(classify_response(404,'temporary')['retry'])\n",
        }[_entry["id"]]
        _entry["files"]["test_public.py"] = "import unittest\n" + _public
    else:
        _entry["files"]["answer.json"] = "PENDING\n"
    _EXPECTED[_entry["id"]] = _entry.pop("_expected")
    NEGATIVE_ARTIFACTS[_entry["id"]] = _negative
    CASES.append(_entry)


def _inside(root, relative):
    p = Path(relative)
    if p.is_absolute() or ".." in p.parts:
        raise ValueError("unsafe relative path")
    target = (root / p).resolve()
    if not target.is_relative_to(root.resolve()):
        raise ValueError("path escapes workspace")
    return target


def _typed_equal(actual, expected):
    if type(actual) is not type(expected):
        return False
    if type(expected) is dict:
        return actual.keys() == expected.keys() and all(_typed_equal(actual[k], expected[k]) for k in expected)
    if type(expected) is list:
        return len(actual) == len(expected) and all(_typed_equal(a, e) for a, e in zip(actual, expected))
    return actual == expected


def _python_result(case, artifact):
    source = artifact.read_text(encoding="utf-8")
    probes = {
      "wh01": "assert merge_pages([[{'id':1},{'id':1}],[],[{'id':2}]]) == [{'id':1},{'id':2}]\nassert merge_pages([])==[]",
      "wh02": "r=summarize(['{\"level\":\"warn\",\"message\":\"retry a@b.com\"}','bad','{\"message\":\"host 10.2.3.4\"}','{\"level\":\"info\",\"message\":\"ok\"}']); assert r == " + repr(_EXPECTED["wh02"]),
      "wh03": "assert normalize_timestamp('2024-02-29T20:04:05+01:00') == '2024-02-29T19:04:05Z'; assert normalize_timestamp('2024-02-29T19:04:05.99Z') == '2024-02-29T19:04:05Z'; assert normalize_timestamp('2024-02-30T00:00:00Z') is None; assert normalize_timestamp('2024-01-01T00:00:00') is None",
      "wh04": "assert [parse_bool(x) for x in [' YES ','off','1','perhaps',None]] == [True,False,True,False,False]; assert parse_bool('perhaps',True) is True",
      "wh05": "l=[{'sku':'a','qty':2,'label':'L'},{'sku':'b','qty':1}]; r=join_rows(l,[{'sku':'a','price':3},{'sku':'a','price':8,'label':'R'},{'sku':[]}]); assert r == " + repr(_EXPECTED["wh05"]) + "; assert l[0]['label']=='L'",
      "wh06": "assert [classify_response(s,'temporary') for s in (429,404,503,'x')] == " + repr(_EXPECTED["wh06"]),
    }[case["id"]]
    harness = "import runpy\nns=runpy.run_path('candidate.py')\n" + probe + "\n"
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        (tmp / "candidate.py").write_text(source, encoding="utf-8")
        (tmp / "probe.py").write_text(harness, encoding="utf-8")
        p = subprocess.run([sys.executable, "-I", "-B", str(tmp / "probe.py")], cwd=tmp,
                           stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=10, env={"PATH": os.environ.get("PATH", "")})
        return p.returncode == 0, p.stderr.decode("utf-8", "replace")[-1200:]


def check(case_id: str, workspace: Path) -> list[dict]:
    case = next((c for c in CASES if c["id"] == case_id), None)
    if case is None:
        raise KeyError(case_id)
    try:
        artifact = _inside(Path(workspace), case["artifact"])
        if not artifact.is_file():
            return [{"name":"artifact_exists","passed":False,"error":"missing artifact"}]
        if case["kind"] == "python":
            try:
                ok, err = _python_result(case, artifact)
            except (SyntaxError, UnicodeError, subprocess.TimeoutExpired, OSError) as exc:
                ok, err = False, str(exc)
            return [{"name":"behavioral_contract","passed":ok,"error":err if not ok else ""}]
        try:
            value = json.loads(artifact.read_text(encoding="utf-8"))
            ok = _typed_equal(value, _EXPECTED[case_id])
            error = "wrong schema or unsupported/incorrect value" if not ok else ""
        except (json.JSONDecodeError, UnicodeError, OSError) as exc:
            ok, error = False, str(exc)
        return [{"name":"grounded_exact_contract","passed":ok,"error":error}]
    except (ValueError, OSError) as exc:
        return [{"name":"safe_artifact_path","passed":False,"error":str(exc)}]
