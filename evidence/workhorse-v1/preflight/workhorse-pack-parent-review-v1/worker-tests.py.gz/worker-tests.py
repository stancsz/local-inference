import unittest
import tempfile
from pathlib import Path

from workhorse.cases_v1 import CASES, NEGATIVE_ARTIFACTS, check


class CasesV1Test(unittest.TestCase):
    def test_schema_and_coverage(self):
        self.assertEqual(len(CASES), 12)
        self.assertEqual({case["id"] for case in CASES}, set(NEGATIVE_ARTIFACTS))
        self.assertEqual(len({case["id"] for case in CASES}), 12)
        self.assertEqual(sum(c["category"] == "development" for c in CASES), 6)
        self.assertEqual(sum(c["category"] != "development" for c in CASES), 6)
        self.assertEqual({c["difficulty"] for c in CASES}, {"routine", "moderate", "judgement"})
        for case in CASES:
            with self.subTest(case=case["id"]):
                self.assertEqual(set(case), {"id", "category", "difficulty", "files", "prompt", "artifact", "kind"})
                self.assertIn(case["kind"], {"python", "json"})
                self.assertNotIn("..", Path(case["artifact"]).parts)
                for name, text in case["files"].items():
                    self.assertFalse(Path(name).is_absolute())
                    self.assertNotIn("..", Path(name).parts)
                    self.assertIsInstance(text, str)

    def test_negative_controls(self):
        for case in CASES:
            with self.subTest(case=case["id"]), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                target = root / case["artifact"]
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(NEGATIVE_ARTIFACTS[case["id"]], encoding="utf-8")
                before = target.read_bytes()
                result = check(case["id"], root)
                self.assertTrue(result)
                self.assertTrue(all(not item["passed"] for item in result), result)
                self.assertEqual(target.read_bytes(), before)

    def test_json_malformed_output_rejected(self):
        for case in (c for c in CASES if c["kind"] == "json"):
            with self.subTest(case=case["id"]), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                (root / case["artifact"]).write_text("{\"unexpected\":true}", encoding="utf-8")
                self.assertFalse(any(x["passed"] for x in check(case["id"], root)))

    def test_python_public_tests_fail_initial_candidate(self):
        for case in (c for c in CASES if c["kind"] == "python"):
            with self.subTest(case=case["id"]), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                for name, text in case["files"].items():
                    (root / name).write_text(text, encoding="utf-8")
                import subprocess, sys
                result = subprocess.run([sys.executable, "-I", "-B", "-m", "unittest", "-q"],
                                        cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
                self.assertNotEqual(result.returncode, 0)

    def test_positive_controls(self):
        good_python = {
          "wh01":"def merge_pages(pages):\n out=[]; seen=set()\n for page in pages:\n  for row in page:\n   if row['id'] not in seen: seen.add(row['id']); out.append(row)\n return out\n",
          "wh02":"import json,re\ndef summarize(lines):\n n=bad=0; levels={}; msgs=[]\n for line in lines:\n  if not line.strip(): continue\n  try: x=json.loads(line)\n  except ValueError: bad+=1; continue\n  n+=1; level=x.get('level','unknown'); levels[level]=levels.get(level,0)+1; msg=x.get('message',''); msg=re.sub(r'\\b[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}\\b','[REDACTED]',msg); msg=re.sub(r'\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b','[REDACTED]',msg); msgs.append(msg)\n return {'valid':n,'malformed':bad,'by_level':levels,'messages':msgs}\n",
          "wh03":"from datetime import datetime,timezone\ndef normalize_timestamp(value):\n try:\n  if not isinstance(value,str): return None\n  if value.endswith('Z'): value=value[:-1]+'+00:00'\n  d=datetime.fromisoformat(value)\n  if d.tzinfo is None: return None\n  return d.astimezone(timezone.utc).replace(microsecond=0).strftime('%Y-%m-%dT%H:%M:%SZ')\n except (ValueError,TypeError): return None\n",
          "wh04":"def parse_bool(value,default=False):\n if type(value) is bool: return value\n if isinstance(value,str):\n  s=value.strip().lower()\n  if s in ('true','yes','1','on'): return True\n  if s in ('false','no','0','off'): return False\n return default\n",
          "wh05":"def join_rows(left,right):\n index={}\n for r in right:\n  try: index[r['sku']]=r\n  except (KeyError,TypeError): pass\n out=[]\n for l in left:\n  row=dict(l)\n  try: match=index.get(l['sku'])\n  except (KeyError,TypeError): match=None\n  if match:\n   for k,v in match.items():\n    if k not in row: row[k]=v\n  out.append(row)\n return out\n",
          "wh06":"def classify_response(status,body):\n try: s=int(status)\n except (ValueError,TypeError): s=0\n if s==429: return {'retry':True,'reason':'rate_limited'}\n if 500<=s<=599: return {'retry':True,'reason':'server_error'}\n return {'retry':False,'reason':'permanent'}\n",
        }
        for case in (c for c in CASES if c["kind"] == "python"):
            with self.subTest(case=case["id"]), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                candidate = root / case["artifact"]
                candidate.write_text(good_python[case["id"]], encoding="utf-8")
                before = candidate.read_bytes()
                result = check(case["id"], root)
                self.assertTrue(all(item["passed"] for item in result), result)
                self.assertEqual(candidate.read_bytes(), before)

    def test_json_exact_type_enforcement(self):
        case = next(c for c in CASES if c["id"] == "wh12")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            import json
            value = {"total_usd_cents":11030,"row_count":4,"discrepancy":True,
                     "conclusion":"Ledger total is USD 110.30 across 4 rows, USD 0.01 above the stated USD 110.29; the source does not explain the difference."}
            (root / case["artifact"]).write_text(json.dumps(value), encoding="utf-8")
            self.assertFalse(any(item["passed"] for item in check("wh12", root)))
