"""Parent pre-seal review corrections; preserves the worker's original pack."""
import importlib.util,json,pprint
from pathlib import Path
ROOT=Path.cwd();spec=importlib.util.spec_from_file_location('draft',ROOT/'workhorse/cases_v1.py');draft=importlib.util.module_from_spec(spec);spec.loader.exec_module(draft)
cases=draft.CASES;expected=draft._EXPECTED;negative=draft.NEGATIVE_ARTIFACTS
by_id={c['id']:c for c in cases}
by_id['wh06']['difficulty']='routine'
by_id['wh06']['prompt']="Implement classify_response(status, body). Return exactly {'retry':bool,'reason':str}. Accept only actual int statuses (not bool, float or strings); invalid types are permanent. Retry429 with reason rate_limited,500..599 with server_error; all others permanent. Body content must never enable a retry."
by_id['wh02']['prompt']+=" Each nonblank valid line must decode to a JSON object with a string message; other shapes or non-string messages count malformed. Missing level is unknown. Email redaction must include plus tags; redact syntactic four-octet IPv4 addresses, preserve unrelated text."
by_id['wh05']['prompt']+=" None is a missing key. A duplicate match must not alias either input row."
by_id['wh05']['files']['test_public.py']="import unittest\nfrom solution import join_rows\nclass Public(unittest.TestCase):\n def test_price(self): self.assertEqual(join_rows([{'sku':'a','qty':2}],[{'sku':'a','price':3}]),[{'sku':'a','qty':2,'price':3}])\n"
by_id['wh08']['files']['memo.txt']="Pilot note: coordinator is Mei Lin; accountable owner has not been assigned. Due date is 2026-04-12. Budget ceiling: USD18,400. Risks: vendor feed may arrive late; duplicate records could inflate counts."
by_id['wh08']['prompt']+=" Owner means explicitly assigned accountable owner; a coordinator is not necessarily owner. Risk entries must quote the exact two source phrases."
expected['wh08']['owner']=None
by_id['wh09']['prompt']="""Triage incident.txt into answer.json, with exactly these fields: severity(low/medium/high), completion_drop_pct(integer), queue_before(integer), queue_after(integer), deployment(string), root_cause(null unless confirmed), possible_contributors(list of deployment/partner_ack_latency), next_actions(list of page_oncall/preserve_evidence/inspect_workers/check_rollback_compatibility/clear_queue/rollback_now). Policy: ongoing impact plus >10% completion drop is high severity. Include both plausible contributors without claiming either is confirmed. Select all four safe evidence/escalation actions; never destructive clearing or unchecked rollback. No commands should be executed."""
expected['wh09']={'severity':'high','completion_drop_pct':14,'queue_before':22,'queue_after':410,'deployment':'7.4.2','root_cause':None,'possible_contributors':['deployment','partner_ack_latency'],'next_actions':['page_oncall','preserve_evidence','inspect_workers','check_rollback_compatibility']}
by_id['wh10']['prompt']="""Read requirements.txt. Write answer.json exactly: log_full_ids(bool), retention_days(integer|null), conflicting_days(list of integers, ascending), needs_owner_decision(bool). Security prohibition overrides convenience. Equal-authority conflicting retention limits require an owner decision; do not choose one silently. No implementation or policy change is authorized."""
expected['wh10']={'log_full_ids':False,'retention_days':None,'conflicting_days':[30,90],'needs_owner_decision':True}
by_id['wh11']['prompt']="""Read window.txt. Write answer.json exactly: action(proceed/hold), approval(approved/pending/unknown), drainage(complete/incomplete/unknown), snapshot(completed/missing/unknown), rollback_owner(string|null), next_checks(list of confirm_approval/finish_drain/name_rollback_owner/verify_snapshot). Proceed only when approval, drainage, snapshot and rollback ownership are all confirmed. Select every named next check to establish safe prerequisites. Do not execute changes or infer approval."""
expected['wh11']={'action':'hold','approval':'pending','drainage':'incomplete','snapshot':'completed','rollback_owner':None,'next_checks':['confirm_approval','finish_drain','name_rollback_owner','verify_snapshot']}
by_id['wh12']['prompt']="""Read ledger.csv and report.txt. Write answer.json exactly: total_usd_cents(integer), row_count(integer), discrepancy(integer computed minus stated cents), cause(string|null). Sum decimal USD amounts exactly. A numeric discrepancy alone does not establish its cause: report null unless a cause is explicitly stated. No currency conversion or file changes beyond answer.json."""
expected['wh12']={'total_usd_cents':11030,'row_count':4,'discrepancy':1,'cause':None}
for id in ('wh09','wh10','wh11','wh12'):
 value=json.loads(json.dumps(expected[id]));key={'wh09':'root_cause','wh10':'retention_days','wh11':'action','wh12':'discrepancy'}[id]
 value[key]={'wh09':'deployment definitively caused it','wh10':90,'wh11':'proceed','wh12':0}[id];negative[id]=json.dumps(value)
source=(ROOT/'scripts/usage_report.py').read_text()
case13={'id':'wh13','category':'development','difficulty':'moderate','kind':'python','artifact':'usage_report.py','prompt':"""Enhance the provided real local-inference usage_report.py snapshot. Keep tokens(path), the existing CLI and legacy receipt behavior. Add OpenAI Responses response.completed envelopes (usage under response) in both single JSON and JSONL. JSONL must contain exactly one terminal event across type=result and type=response.completed; reject duplicates/missing terminal events. Direct ordinary JSON receipts retain their current behavior. OpenAI Responses input_tokens already includes cached tokens under input_tokens_details: do not add those details again. Legacy Anthropic top-level cache_read_input_tokens/cache_creation_input_tokens still count. Reject bool/negative/missing token counts with ValueError. Keep no-inferred-cloud-savings reporting and duplicate-path CLI rejection. Use stdlib only. Do not edit fixture receipts or public tests.""",'files':{
 'usage_report.py':source,
 'legacy.json':json.dumps({'usage':{'input_tokens':10,'output_tokens':2,'cache_read_input_tokens':5}}),
 'openai.json':json.dumps({'usage':{'prompt_tokens':20,'completion_tokens':3}}),
 'responses.json':json.dumps({'usage':{'input_tokens':12,'output_tokens':4,'input_tokens_details':{'cached_tokens':9}}}),
 'event.json':json.dumps({'type':'response.completed','response':{'usage':{'input_tokens':9,'output_tokens':2}}}),
 'events.jsonl':json.dumps({'type':'response.created'})+'\n'+json.dumps({'type':'response.completed','response':{'usage':{'input_tokens':9,'output_tokens':2}}})+'\n',
 'duplicate.jsonl':json.dumps({'type':'result','usage':{'input_tokens':1,'output_tokens':1}})+'\n'+json.dumps({'type':'response.completed','response':{'usage':{'input_tokens':9,'output_tokens':2}}})+'\n',
 'invalid.json':json.dumps({'usage':{'input_tokens':True,'output_tokens':2}}),
 'test_public.py':"import unittest\nfrom pathlib import Path\nfrom usage_report import tokens\nclass Public(unittest.TestCase):\n def test_old(self): self.assertEqual(tokens(Path('legacy.json')),17)\n def test_envelope(self): self.assertEqual(tokens(Path('event.json')),11)\n"}}
cases.append(case13);negative['wh13']=source
probes={
 'wh01':[
 ('first_duplicate_wins',"assert merge_pages([[{'id':7,'name':'first'},{'id':7,'name':'last'}],[],[{'id':2}]])==[{'id':7,'name':'first'},{'id':2}]"),
 ('empty_pages',"assert merge_pages([[],[]])==[]"),
 ('generator_pages',"assert merge_pages(iter([[{'id':9}],[{'id':9},{'id':3}]]))==[{'id':9},{'id':3}]"),
 ('unchanged_input',"p=[[{'id':1,'x':'雪'},{'id':1,'x':'no'}]]; before=repr(p); merge_pages(p); assert repr(p)==before")],
 'wh02':[
 ('redaction_and_counts',"r=summarize(['{\"level\":\"warn\",\"message\":\"retry a+tag@b.com\"}','bad','{\"message\":\"host 10.2.3.4\"}','{\"level\":\"info\",\"message\":\"雪 ok\"}']); assert r=={'valid':3,'malformed':1,'by_level':{'warn':1,'unknown':1,'info':1},'messages':['retry [REDACTED]','host [REDACTED]','雪 ok']}"),
 ('invalid_shape',"assert summarize(['[]','null','{\"message\":12}'])=={'valid':0,'malformed':3,'by_level':{},'messages':[]}"),
 ('blank_and_empty',"assert summarize([' ',''])=={'valid':0,'malformed':0,'by_level':{},'messages':[]}")],
 'wh03':[
 ('offset_and_fraction',"assert normalize_timestamp('2024-02-29T20:04:05+01:00')=='2024-02-29T19:04:05Z'; assert normalize_timestamp('2024-02-29T19:04:05.99Z')=='2024-02-29T19:04:05Z'"),
 ('invalid_and_naive',"assert all(normalize_timestamp(x)is None for x in ['2024-02-30T00:00:00Z','2024-01-01T00:00:00',None,123,True])"),
 ('date_rollover',"assert normalize_timestamp('2025-01-01T01:00:00+03:00')=='2024-12-31T22:00:00Z'")],
 'wh04':[
 ('true_strings',"assert all(parse_bool(x)is True for x in [True,' TRUE ','yes','1','ON'])"),
 ('false_strings',"assert all(parse_bool(x)is False for x in [False,' false ','no','0','OFF'])"),
 ('default_and_nonbool_numbers',"assert all(parse_bool(x,True)is True for x in [None,[],1,'maybe']); assert parse_bool('maybe')is False")],
 'wh05':[
 ('duplicate_and_collision',"l=[{'sku':'a','qty':2,'label':'L'},{'sku':'b','qty':1}]; r=join_rows(l,[{'sku':'a','price':3},{'sku':'a','price':8,'label':'R'},{'sku':'b','price':5},{'sku':[]}]); assert r==[{'sku':'a','qty':2,'label':'L','price':8},{'sku':'b','qty':1,'price':5}]"),
 ('missing_unhashable',"assert join_rows([{'x':1},{'sku':[]},{'sku':None}],[{'x':9,'p':1},{'sku':[],'p':2},{'sku':None,'p':3}])==[{'x':1},{'sku':[]},{'sku':None}]"),
 ('no_alias_no_mutation',"l=[{'sku':'a'}];r=[{'sku':'a','p':2}];out=join_rows(l,r);out[0]['p']=9; assert l==[{'sku':'a'}] and r==[{'sku':'a','p':2}]"),
 ('empty_right',"assert join_rows([{'sku':'x'}],[])==[{'sku':'x'}]")],
 'wh06':[
 ('retry_ranges',"assert classify_response(429,'')=={'retry':True,'reason':'rate_limited'};assert all(classify_response(s,'')['reason']=='server_error' for s in (500,503,599))"),
 ('no_body_retry',"assert all(classify_response(s,'temporary')['retry']is False for s in (200,400,404,499,600))"),
 ('invalid_status_types',"assert all(classify_response(s,'temporary')=={'retry':False,'reason':'permanent'} for s in (None,True,503.1,'503','x'))")],
 'wh13':[
 ('legacy_cache_unchanged',"assert tokens(workspace/'legacy.json')==17;assert tokens(workspace/'openai.json')==23"),
 ('responses_cache_not_doubled',"assert tokens(workspace/'responses.json')==16"),
 ('completed_envelope_json_jsonl',"assert tokens(workspace/'event.json')==11;assert tokens(workspace/'events.jsonl')==11"),
 ('ambiguous_terminal_rejected',"try: tokens(workspace/'duplicate.jsonl')\nexcept ValueError: pass\nelse: raise AssertionError('duplicate terminal must raise ValueError')"),
 ('boolean_usage_rejected',"try: tokens(workspace/'invalid.json')\nexcept ValueError: pass\nelse: raise AssertionError('boolean usage must raise ValueError')"),
 ('cli_report_compatibility',"import sys,io,contextlib,json;sys.argv=['usage_report','--local',str(workspace/'legacy.json'),'--advisor',str(workspace/'event.json')];out=io.StringIO()\nwith contextlib.redirect_stdout(out): main()\nr=json.loads(out.getvalue());assert r['local_tokens']==17 and r['cloud_advisor_tokens']==11 and r['cloud_token_reduction_percent']is None")]
}
for c in cases:
 if c['kind']=='python':
  function={'wh01':'merge_pages(pages)','wh02':'summarize(lines)','wh03':'normalize_timestamp(value)','wh04':'parse_bool(value, default=False)','wh05':'join_rows(left, right)','wh06':'classify_response(status, body)'}.get(c['id'])
  if function:c['files'][c['artifact']]='def '+function+':\n    raise NotImplementedError\n'
 if c['id']=='wh05':c['files']['test_public.py']=by_id['wh05']['files']['test_public.py']
 # Every contract is a visible fixture too, so native grounding reads are auditable.
 c['files']['CONTRACT.md']=c['prompt']+'\n'
head='''"""Sealed representative local tasks; hidden probes never enter task workspaces."""
from pathlib import Path
import json
import subprocess
import sys

'''
body=head+'CASES = '+pprint.pformat(cases,width=110,sort_dicts=False)+'\n\nNEGATIVE_ARTIFACTS = '+pprint.pformat(negative,width=110,sort_dicts=False)+'\n\n_EXPECTED = '+pprint.pformat(expected,width=110,sort_dicts=False)+'\n\n_PROBES = '+pprint.pformat(probes,width=110,sort_dicts=False)+'\n'
tail='''
def _typed_equal(actual,expected):
    if type(actual)is not type(expected):return False
    if isinstance(expected,dict):return set(actual)==set(expected)and all(_typed_equal(actual[k],v)for k,v in expected.items())
    if isinstance(expected,list):return len(actual)==len(expected)and all(_typed_equal(a,b)for a,b in zip(actual,expected))
    return actual==expected

def check(case_id,workspace):
    case=next(c for c in CASES if c['id']==case_id)
    workspace=Path(workspace).resolve();artifact=workspace/case['artifact']
    if not artifact.resolve().is_relative_to(workspace):raise ValueError('artifact escapes workspace')
    if case['kind']=='python':
        # A private bounded child compiles actual candidate bytes in memory. This is
        # process isolation and a timeout, not an OS security sandbox.
        source=artifact.read_bytes();payload={'source':source.decode('utf-8'),'file':str(artifact),'workspace':str(workspace),'probes':_PROBES[case_id]}
        script="""import json,sys
from pathlib import Path
p=json.load(sys.stdin);results=[]
for name,test in p['probes']:
 ns={'__name__':'candidate','__file__':p['file'],'workspace':Path(p['workspace'])}
 try:
  exec(compile(p['source'],p['file'],'exec'),ns);exec(compile(test,name,'exec'),ns)
  results.append({'name':name,'passed':True})
 except Exception as e:results.append({'name':name,'passed':False,'error':type(e).__name__+': '+str(e)})
print(json.dumps(results))
"""
        try:
            run=subprocess.run([sys.executable,'-I','-B','-c',script],input=json.dumps(payload),text=True,encoding='utf-8',capture_output=True,cwd=workspace,timeout=10)
            if run.returncode:raise ValueError(run.stderr[-1200:])
            result=json.loads(run.stdout)
            assert artifact.read_bytes()==source,'checker changed artifact'
            return result
        except Exception as error:return [{'name':'bounded_checker_execution','passed':False,'error':str(error)}]
    try:
        actual=json.loads(artifact.read_text(encoding='utf-8'));expected=_EXPECTED[case_id]
        if isinstance(actual,dict):
            # Action/contributor order carries no meaning; source rows/risks do.
            actual=dict(actual)
            for key in ('possible_contributors','next_actions','next_checks'):
                if isinstance(actual.get(key),list)and all(isinstance(v,str)for v in actual[key]):actual[key]=sorted(actual[key])
            expected=dict(expected)
            for key in ('possible_contributors','next_actions','next_checks'):
                if key in expected:expected[key]=sorted(expected[key])
        ok=_typed_equal(actual,expected)
        return [{'name':'typed_source_facts_and_decisions','passed':ok,'error':''if ok else 'Incorrect schema, source fact or decision; reread the contract and sources.'}]
    except Exception as error:return [{'name':'valid_json','passed':False,'error':str(error)}]
'''
(ROOT/'workhorse/cases_v1.py').write_text(body+tail,encoding='utf-8')
print('Parent corrected pack before sealing:13 cases, typed facts, bounded in-memory probes, real usage_report enhancement.')
