import datetime,gzip,hashlib,json,os,subprocess,urllib.request
from pathlib import Path
from workhorse.cases_v1 import CASES
ROOT=Path.cwd();folder=ROOT/'evidence/workhorse-v1/preflight';folder.mkdir(parents=True,exist_ok=False)
def sha(raw):return hashlib.sha256(raw).hexdigest()
artifacts=[]
paths=list((ROOT/'tmp/stress').glob('workhorse-fixtures-worker-v1.*'))+list((ROOT/'tmp/workhorse-pack-parent-review-v1').glob('*'))+[ROOT/'tmp/stress/finish-workhorse-pack-v1.py',ROOT/'tmp/stress/finish-workhorse-tests-v1.py',Path(__file__).resolve()]
secrets=[v.encode()for k,v in os.environ.items()if len(v)>12 and any(s in k.upper()for s in ('KEY','TOKEN','SECRET'))]
for path in paths:
 raw=path.read_bytes();assert not any(s in raw for s in secrets),path
 relative=path.relative_to(ROOT/'tmp');target=folder/(relative.as_posix()+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 compressed=gzip.compress(raw,mtime=0);target.write_bytes(compressed)
 artifacts.append({'path':target.relative_to(ROOT).as_posix(),'raw_sha256':sha(raw),'compressed_sha256':sha(compressed)})
runtime=[]
for service in ('inference','gateway'):
 row=json.loads(subprocess.check_output(['docker','inspect',f'local-inference-{service}-1'],text=True))[0]
 assert row['State']['Running']
 allowed={'CONTEXT_SIZE','DRAFT_TOKENS','UBATCH_SIZE','SPEC_TYPE','MTP_MODEL_PATH','GPU_LAYERS','SIFT_TARGET','SIFT_MAX_RAW_TOKENS'}
 env={s.split('=',1)[0]:s.split('=',1)[1]for s in row['Config']['Env']if s.split('=',1)[0]in allowed}
 runtime.append({'service':service,'image':row['Image'],'environment':env})
with urllib.request.urlopen('http://127.0.0.1:8091/props',timeout=10)as response:props=json.load(response)
assert props['default_generation_settings']['n_ctx']==40960
source_names=['workhorse/cases_v1.py','workhorse/run_v1.py','tests/test_workhorse_cases_v1.py','tests/test_workhorse_runner_v1.py','scripts/daily_artifacts.py','scripts/usage_report.py','scripts/setup_env.py','app/gateway.py','app/budget.py','gateway.yaml','compose.yaml','docker/start-inference.sh']
plan={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'prospective practical workhorse usefulness evaluation','route':'http://127.0.0.1:8090','model':'qwen3.8-27b','case_ids':[c['id']for c in CASES],'limits':[180,1,10],
 'limit_meaning':['seconds per native CLI phase','same-session test-feedback repairs per case','native model turns per phase'],
 'source_sha256':{name:sha((ROOT/name).read_bytes())for name in source_names},'runtime':runtime,'native_context_window':40960,
 'cases':[{'id':c['id'],'category':c['category'],'difficulty':c['difficulty'],'kind':c['kind'],'artifact':c['artifact'],'prompt_sha256':sha(c['prompt'].encode()),'fixture_sha256':{name:sha(text.encode())for name,text in c['files'].items()}}for c in CASES],
 'acceptance':'native terminal success, actual successful edit reconstruction, source reads/immutability and all unchanged hidden checks. No outcome-selected rerolls. Timeouts/native scope failures stop the case; every listed case still runs once.',
 'accounting':'first-pass and after-one-feedback correctness, phase and total active wall time, returned CLI/provider usage only. No inferred financial savings or cloud superiority.',
 'scope':'12 representative synthetic task cases plus one actual repository-module snapshot enhancement, not live customer outcomes. Small samples do not establish domain-wide reliability. Existing long-context/session acceptance is separate; no new long-session qualification.',
 'cloud_decision':'Use observed local failure/feedback and verification/risk gates. No cloud comparison is sealed here, so cloud-model superiority will not be claimed.',
 'preflight':{'tests_passed':46,'negative_controls':13,'positive_controls':13,'parent_reproduced_worker_defects':3,'worker_claimed_test_success_disproved':'direct test-file command discovered no tests; parent pytest found NameError, wrong expected probes and passing starter public test','parent_corrections':'actual positive/negative tests; typed facts instead of exact prose; named edge probes; real module+CLI compatibility case','artifacts':artifacts}}
(ROOT/'evidence/workhorse-v1-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
print(json.dumps({'case_count':len(CASES),'preflight_tests':46,'preflight_files':len(artifacts),'context':40960}))
