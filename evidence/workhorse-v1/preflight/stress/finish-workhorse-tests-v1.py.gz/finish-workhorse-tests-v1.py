import ast,pprint
from pathlib import Path
ROOT=Path.cwd();tree=ast.parse((ROOT/'tmp/workhorse-pack-parent-review-v1/worker-tests.py').read_text())
assignment=next(n for n in ast.walk(tree)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='good_python'for t in n.targets))
positive=ast.literal_eval(assignment.value)
positive['wh02']=positive['wh02'].replace("n+=1; level=x.get('level','unknown');", "\n  if not isinstance(x,dict) or not isinstance(x.get('message'),str): bad+=1; continue\n  n+=1; level=x.get('level','unknown');")
positive['wh05']=positive['wh05'].replace("try: index[r['sku']]=r", "try:\n   if r['sku'] is not None: index[r['sku']]=r").replace("try: match=index.get(l['sku'])", "try: match=index.get(l['sku']) if l['sku'] is not None else None")
positive['wh06']="def classify_response(status,body):\n if type(status)is not int:return {'retry':False,'reason':'permanent'}\n if status==429:return {'retry':True,'reason':'rate_limited'}\n if 500<=status<=599:return {'retry':True,'reason':'server_error'}\n return {'retry':False,'reason':'permanent'}\n"
original=(ROOT/'scripts/usage_report.py').read_text()
wrapper='''
def tokens(path):
 text=path.read_text(encoding='utf-8-sig')
 try:document=json.loads(text)
 except json.JSONDecodeError:
  rows=[json.loads(line)for line in text.splitlines()if line.strip()]
  terminal=[r for r in rows if isinstance(r,dict)and r.get('type')in ('result','response.completed')]
  if len(terminal)!=1:raise ValueError('exactly one terminal required')
  document=terminal[0]
 if isinstance(document,dict)and document.get('type')=='response.completed':document=document.get('response')
 if not isinstance(document,dict)or not isinstance(document.get('usage'),dict):raise ValueError('usage required')
 usage=document['usage']
 fields=['prompt_tokens','completion_tokens']if 'prompt_tokens'in usage else ['input_tokens','output_tokens']+[k for k in ('cache_read_input_tokens','cache_creation_input_tokens')if k in usage]
 values=[usage.get(k)for k in fields]
 if any(type(v)is not int or v<0 for v in values):raise ValueError('invalid usage')
 return sum(values)
'''
positive['wh13']=original.replace("if __name__=='__main__':",wrapper+"\nif __name__=='__main__':")
tests='''"""Checker controls stay outside every model task workspace."""
import copy,json,subprocess,sys
from pathlib import Path
import pytest
from workhorse.cases_v1 import CASES,NEGATIVE_ARTIFACTS,check,_EXPECTED

'''+ 'POSITIVE_PYTHON = '+pprint.pformat(positive,width=110,sort_dicts=False)+'''

def prepare(case,root,candidate=None):
 for name,text in case['files'].items():
  path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(text.encode('utf-8'))
 if candidate is not None:(root/case['artifact']).write_bytes(candidate.encode('utf-8'))

def test_schema_and_coverage():
 assert len(CASES)==13 and len({c['id']for c in CASES})==13
 assert {c['id']for c in CASES}==set(NEGATIVE_ARTIFACTS)
 assert sum(c['kind']=='python'for c in CASES)==7
 for case in CASES:
  assert set(case)=={'id','category','difficulty','files','prompt','artifact','kind'}
  assert 'CONTRACT.md'in case['files'] and case['artifact']in case['files']
  for name in case['files']:assert not Path(name).is_absolute()and '..'not in Path(name).parts

@pytest.mark.parametrize('case',CASES,ids=lambda c:c['id'])
def test_positive_control_and_source_immutability(case,tmp_path):
 value=POSITIVE_PYTHON[case['id']]if case['kind']=='python'else json.dumps(_EXPECTED[case['id']])
 prepare(case,tmp_path,value)
 before={p.relative_to(tmp_path):p.read_bytes()for p in tmp_path.rglob('*')if p.is_file()}
 rows=check(case['id'],tmp_path);assert rows and all(r['passed']for r in rows),rows
 assert {p.relative_to(tmp_path):p.read_bytes()for p in tmp_path.rglob('*')if p.is_file()}==before

@pytest.mark.parametrize('case',CASES,ids=lambda c:c['id'])
def test_plausible_wrong_candidate_is_rejected(case,tmp_path):
 prepare(case,tmp_path,NEGATIVE_ARTIFACTS[case['id']])
 rows=check(case['id'],tmp_path);assert rows and not all(r['passed']for r in rows),rows

@pytest.mark.parametrize('case',[c for c in CASES if c['kind']=='python'],ids=lambda c:c['id'])
def test_public_tests_actually_run_and_fail_baseline(case,tmp_path):
 prepare(case,tmp_path)
 run=subprocess.run([sys.executable,'-B','-m','unittest','-q'],cwd=tmp_path,capture_output=True,text=True,timeout=15)
 assert run.returncode!=0 and 'Ran'in run.stderr and 'Ran 0 tests'not in run.stderr,(run.stdout,run.stderr)

@pytest.mark.parametrize('case',[c for c in CASES if c['kind']=='json'],ids=lambda c:c['id'])
def test_malformed_json_is_rejected(case,tmp_path):
 prepare(case,tmp_path,'not json')
 assert not all(r['passed']for r in check(case['id'],tmp_path))

def test_bool_is_not_an_integer_fact(tmp_path):
 case=next(c for c in CASES if c['id']=='wh12');value=copy.deepcopy(_EXPECTED['wh12']);value['discrepancy']=True
 prepare(case,tmp_path,json.dumps(value));assert not all(r['passed']for r in check('wh12',tmp_path))

def test_action_order_has_no_meaning(tmp_path):
 case=next(c for c in CASES if c['id']=='wh09');value=copy.deepcopy(_EXPECTED['wh09']);value['next_actions'].reverse()
 prepare(case,tmp_path,json.dumps(value));assert all(r['passed']for r in check('wh09',tmp_path))
'''
(ROOT/'tests/test_workhorse_cases_v1.py').write_text(tests,encoding='utf-8')
