import unittest
from solution import normalize_timestamp
class Public(unittest.TestCase):
 def test_utc(self): self.assertEqual(normalize_timestamp('2024-01-01T01:00:00+01:00'),'2024-01-01T00:00:00Z')
