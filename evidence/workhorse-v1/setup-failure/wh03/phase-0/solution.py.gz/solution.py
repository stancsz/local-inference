def normalize_timestamp(value):
    raise NotImplementedError
