def merge_pages(pages):
    raise NotImplementedError
