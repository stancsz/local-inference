def parse_bool(value, default=False):
    raise NotImplementedError
