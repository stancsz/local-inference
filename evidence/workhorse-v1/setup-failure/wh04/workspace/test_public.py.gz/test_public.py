import unittest
from solution import parse_bool
class Public(unittest.TestCase):
 def test_strict(self): self.assertFalse(parse_bool('maybe'))
