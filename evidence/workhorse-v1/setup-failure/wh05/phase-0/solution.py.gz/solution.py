def join_rows(left, right):
    raise NotImplementedError
