import unittest
from solution import join_rows
class Public(unittest.TestCase):
 def test_price(self): self.assertEqual(join_rows([{'sku':'a','qty':2}],[{'sku':'a','price':3}]),[{'sku':'a','qty':2,'price':3}])
