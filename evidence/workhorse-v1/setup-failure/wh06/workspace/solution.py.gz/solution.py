def classify_response(status, body):
    raise NotImplementedError
