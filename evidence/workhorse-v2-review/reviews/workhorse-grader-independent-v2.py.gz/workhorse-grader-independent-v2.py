import hashlib,json,os,subprocess,sys,urllib.request,uuid
from pathlib import Path
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT.parent/'sift/src')]
from stress.cli_acceptance import child_command,executable
BASE='http://127.0.0.1:4000';PREFIX=ROOT/'tmp/stress/workhorse-grader-independent-v2'
def request(path,body,key):
 req=urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=60)as response:return json.load(response)
master=os.environ['GATEWAY_MASTER_KEY'];alias='codex-vm-review-'+uuid.uuid4().hex[:10]
key=request('/key/generate',{'key_alias':alias,'models':['default'],'duration':'10m','max_budget':0.5},master)['key']
commands=['python tmp/stress/workhorse-grader-recheck-v2.py','python tmp/stress/workhorse-grader-recheck-v2.py unicode']
prompt='Targeted follow-up to YOUR same eligible nonauthor workhorse report review, which returned READY. There is one new evidenced grader fix and one display clarification. Run only the TWO exact read-only offline commands below with native exec_command max_output_tokens6000; finish yielded handles. Do not edit sources, access credentials/network, regenerate models or delegate. A subsequent standard three-task Claude smoke records2/3 passes, but its correct generated runbook fails the old exact-wording regex. New regression fails before repair, passes after, and16 focused positive/negative wording checks plus483 project tests pass. The first command shows old/current functions, exact actual runbook, unchanged original2/3 receipt, native Edit reconstruction and focused tests. Decide if narrowly accepting its explicit setting+pronoun wording corrects a false negative while preserving the invariant and negative tests. Any regrade is a NEW receipt, never mutation of the original failure or primary13-case metrics. Second command shows authoritative ASCII Unicode codepoints from actual frozen CSV: U+00C3 U+0178, not U+00DF. Your original review sentence displayed a sharp-s glyph; clarify using numeric codepoints to avoid stdout/rendering ambiguity. The source-based invalid-case diagnosis/exclusion remains supported, not a Sift failure or model promotion. Return JSON targeted_recheck READY/NOT_READY, concrete evidence, whether evaluation_report remains READY, corrected wording/Unicode statement, negative limits, and remaining_required_work. Do not re-evaluate unrelated accepted scope or infer cloud superiority.\n'+'\n'.join(json.dumps({'cmd':c,'max_output_tokens':6000})for c in commands)

try:
 home=ROOT/'tmp/stress/workhorse-review-client-v2';assert home.exists()
 command,env=child_command('codex',executable('codex'),home,BASE+'/v1','default',prompt,persist=True,session_id='01a1812c-f9f0-7f62-b859-3b4ed231eb49')
 command=[a.replace('workspace-write','read-only')if a=='workspace-write'or a.startswith('sandbox_mode=')else a for a in command]
 env['SIFT_LOCAL_KEY']=key
 env['PYTHONDONTWRITEBYTECODE']='1'
 env['PYTHONIOENCODING']='utf-8'
 env['PYTHONPATH']=';'.join([str(ROOT),str(ROOT/'scripts'),str(ROOT.parent/'sift/src'),str(ROOT/'app')])
 plan={'route':BASE+'/v1','model':'default','sandbox':'read-only','artifact_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'helper_sha256':hashlib.sha256((ROOT/'tmp/stress/workhorse-grader-recheck-v2.py').read_bytes()).hexdigest(),'commands':commands,'argv':command[:-1]+['[PROMPT IN SEPARATE CAPTURE]'],'timeout_seconds':300,'scope':'nonauthor workhorse evaluation/report review; not model readiness or a cloud baseline'}
 PREFIX.with_suffix('.plan.json').write_text(json.dumps(plan,indent=2));PREFIX.with_suffix('.prompt.txt').write_text(prompt,encoding='utf-8')
 with PREFIX.with_suffix('.jsonl').open('x',encoding='utf-8')as out,PREFIX.with_suffix('.stderr.log').open('x',encoding='utf-8')as err:
  process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=out,stderr=err)
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:
   subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);process.wait(timeout=20);raise
 PREFIX.with_suffix('.exit.json').write_text(json.dumps({'exit_code':code,'alias':alias}))
finally:
 request('/key/delete',{'key_aliases':[alias]},master);PREFIX.with_suffix('.revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
print('Workhorse evaluation review terminal; scoped key revoked',flush=True)
