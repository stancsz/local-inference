import hashlib,json,os,subprocess,sys,urllib.request,uuid
from pathlib import Path
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT.parent/'sift/src')]
from stress.cli_acceptance import child_command,executable
BASE='http://127.0.0.1:4000';PREFIX=ROOT/'tmp/stress/workhorse-independent-review-v2'
def request(path,body,key):
 req=urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=60)as response:return json.load(response)
master=os.environ['GATEWAY_MASTER_KEY'];alias='codex-vm-review-'+uuid.uuid4().hex[:10]
key=request('/key/generate',{'key_alias':alias,'models':['default'],'duration':'10m','max_budget':0.5},master)['key']
commands=['python tmp/stress/workhorse-review-pages-v2.py '+name for name in ('verifier','method','code1','code2','structured','publication')]
prompt='Independent NONAUTHOR review of a NEW workhorse-usefulness evaluation, not a request to certify model readiness. User asks more real acceptance tests for local development/general workhorse tasks and when to use cloud instead. Product inference is localQwen8090; you are supporting4000/default. Inspect all SIX exact command pages below with native exec_command max_output_tokens8000, finish any yielded command with write_stdin. You may run only those read-only offline pages; no edits, source/evidence changes, network, credentials, delegation or new inference. They show your verifier source, unchanged hidden probes, actual generated artifacts and every phase result, fresh final-artifact checks, source fixtures for structured tasks, preserved first failures, and immutable Git hashes. Evaluate whether documentation honestly answers usefulness from actual evidence: raw13cases8first-artifact/10final, strict0first/2final; one invalid CSV fixture/rubric is excluded, giving8/12first and10/12final valid artifacts. Do not promote frozen workflow failures. Check whether that exclusion and any other contract/fixture are justified; detect additional invalid tasks. Distinguish meaningful model contract/tool errors from redundant CONTRACT.md reads, exact-shell grammar and feedback-harness weaknesses. V1 zero-token13setup422s are preserved separately. Actual module enhancement is tested against legacy/Responses/CLI cases, not applied to production. No paired cloud baseline exists: conditional escalation advice must not imply measured cloud superiority, token/dollar savings, universal task reliability, security-grade redaction, Sift causal attribution or new long-context proof. Parent independently replays native edits/reads/continuity and every actual artifact;480 project tests passed. Assess this evaluation/report scope, not whether all local tasks succeeded. Return JSON with evaluation_report READY/NOT_READY/UNVERIFIED, substantive findings and evidence, any additional invalid cases/corrected denominators, actual checks, remaining required report work, local_unattended_workhorse verdict, cloud_superiority status and limits. No visual review is needed for CLI/code/JSON artifacts.\n'+'\n'.join(json.dumps({'cmd':c,'max_output_tokens':8000})for c in commands)

try:
 home=ROOT/'tmp/stress/workhorse-review-client-v2';assert not home.exists()
 command,env=child_command('codex',executable('codex'),home,BASE+'/v1','default',prompt,persist=False)
 command=[a.replace('workspace-write','read-only')if a=='workspace-write'or a.startswith('sandbox_mode=')else a for a in command]
 env['SIFT_LOCAL_KEY']=key
 env['PYTHONDONTWRITEBYTECODE']='1'
 env['PYTHONPATH']=';'.join([str(ROOT),str(ROOT/'scripts'),str(ROOT.parent/'sift/src'),str(ROOT/'app')])
 plan={'route':BASE+'/v1','model':'default','sandbox':'read-only','artifact_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'helper_sha256':hashlib.sha256((ROOT/'tmp/stress/workhorse-review-pages-v2.py').read_bytes()).hexdigest(),'commands':commands,'argv':command[:-1]+['[PROMPT IN SEPARATE CAPTURE]'],'timeout_seconds':300,'scope':'nonauthor workhorse evaluation/report review; not model readiness or a cloud baseline'}
 PREFIX.with_suffix('.plan.json').write_text(json.dumps(plan,indent=2));PREFIX.with_suffix('.prompt.txt').write_text(prompt,encoding='utf-8')
 with PREFIX.with_suffix('.jsonl').open('x',encoding='utf-8')as out,PREFIX.with_suffix('.stderr.log').open('x',encoding='utf-8')as err:
  process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=out,stderr=err)
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:
   subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);process.wait(timeout=20);raise
 PREFIX.with_suffix('.exit.json').write_text(json.dumps({'exit_code':code,'alias':alias}))
finally:
 request('/key/delete',{'key_aliases':[alias]},master);PREFIX.with_suffix('.revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
print('Workhorse evaluation review terminal; scoped key revoked',flush=True)
