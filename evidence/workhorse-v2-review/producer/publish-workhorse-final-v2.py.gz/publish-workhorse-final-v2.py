"""Publish both independent reviews and untouched supplemental smoke evidence."""
import datetime,gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();DEST=ROOT/'evidence/workhorse-v2-review';DEST.mkdir(exist_ok=False)
def read(path):return path.read_text(encoding='utf-8')
def sha(raw):return hashlib.sha256(raw).hexdigest()
secrets=[v.encode()for k,v in os.environ.items()if len(v)>12 and any(word in k.upper()for word in ('KEY','TOKEN','SECRET','PASSWORD'))]
for line in read(ROOT/'.env').splitlines():
 if line.startswith('LOCAL_GATEWAY_KEY='):secrets.append(line.split('=',1)[1].strip().encode())
artifacts=[]
def archive(path,relative):
 raw=path.read_bytes();assert not any(s and s in raw for s in secrets),path
 target=DEST/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 data=gzip.compress(raw,mtime=0);target.write_bytes(data)
 artifacts.append({'path':target.relative_to(ROOT).as_posix(),'raw_sha256':sha(raw),'compressed_sha256':sha(data)})
for prefix in ('workhorse-independent-review-v2','workhorse-grader-independent-v2'):
 for path in sorted((ROOT/'tmp/stress').glob(prefix+'.*')):archive(path,'reviews/'+path.name)
for name in ('workhorse-review-pages-v2.py','workhorse-grader-recheck-v2.py','operator-budget-reference-before.log','operator-budget-reference-after.log','operator-budget-parent-recheck-v2.log','workhorse-final-suite-v2.log','workhorse-final-local-smoke.json','workhorse-final-openai-smoke.json','workhorse-publication-v2.json'):
 archive(ROOT/'tmp/stress'/name,'checks/'+name)
for path in sorted((ROOT/'tmp/workhorse-post-smoke').rglob('*')):
 if path.is_file():archive(path,'supplemental-smoke/'+path.relative_to(ROOT/'tmp/workhorse-post-smoke').as_posix())
archive(Path(__file__).resolve(),'producer/publish-workhorse-final-v2.py')
archive(ROOT/'scripts/claude_acceptance.py','producer/claude_acceptance-after-grader-fix.py')
archive(ROOT/'tests/test_operator_budget_reference.py','producer/test_operator_budget_reference.py')
def verdict(prefix):
 events=[json.loads(line)for line in read(ROOT/'tmp/stress'/f'{prefix}.jsonl').splitlines()]
 text=[e['item']['text']for e in events if e.get('type')=='item.completed'and e.get('item',{}).get('type')=='agent_message'][-1]
 calls=[e['item']for e in events if e.get('type')=='item.completed'and e.get('item',{}).get('type')=='command_execution']
 assert calls and all(c['exit_code']==0 for c in calls)
 return json.loads(text),len(calls)
initial,commands=verdict('workhorse-independent-review-v2');followup,rechecks=verdict('workhorse-grader-independent-v2')
assert initial['evaluation_report']=='READY'and followup['targeted_recheck']=='READY'and followup['evaluation_report_remains']=='READY'
assert not initial['remaining_required_report_work']and not followup['remaining_required_work']
assert '483 passed'in read(ROOT/'tmp/stress/workhorse-final-suite-v2.log')
assert all(json.loads(read(ROOT/'tmp/stress'/f'workhorse-final-{name}-smoke.json'))['passed']for name in ('local','openai'))
smoke=json.loads(read(ROOT/'tmp/workhorse-post-smoke/claude-acceptance.json'));assert [r['passed']for r in smoke]==[True,True,False]
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT)]
import claude_acceptance as validation
from daily_artifacts import parse_events,final_result,reconstruct_revisions
supplement=[]
for row in smoke:
 artifact=ROOT/row['artifact'];events=parse_events(ROOT/'tmp/workhorse-post-smoke'/f"{row['task']}.jsonl")
 assert row['exit_code']==0 and not final_result(events)['is_error']
 rebuilt=reconstruct_revisions(events,artifact,'PENDING_LOCAL_ACCEPTANCE\n')[-1]
 assert rebuilt.replace('\r\n','\n')==read(artifact).replace('\r\n','\n')
 if row['task']=='operator-guide':assert validation.validate_operator_guide(read(artifact))
 else:assert row['passed']and row['arithmetic_valid']and sha(artifact.read_bytes())==row['artifact_sha256']
 supplement.append({'task':row['task'],'original_grade':row['passed'],'new_artifact_grade':True,'seconds':row['seconds'],'sha256':sha(artifact.read_bytes()),'native_edit_reconstruction':True})
report={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evaluation_report':'READY','scope':'Complete bounded local-workhorse usefulness evaluation and conditional cloud-escalation guide; not a model-readiness or cloud-ranking certificate',
 'review_route':'http://127.0.0.1:4000/v1','review_model':'default','review_session_id':'01a1812c-f9f0-7f62-b859-3b4ed231eb49','initial_review':initial,'targeted_grader_recheck':followup,
 'actual_read_only_page_commands':commands+rechecks,'credential_status':'Both scoped review keys revoked in successful finally paths; source worker key revoked separately. No global config changes or credential values published.',
 'project_tests':483,'fresh_api_smokes':{'local':True,'openai':True},'supplemental_native_smoke':{'original_cli_exit':1,'original_grades':[True,True,False],'new_artifact_grades':[True,True,True],'reason':'Separate correct-runbook regrade after demonstrated exact-phrase false-negative fix; original receipt untouched, no model rerun.','artifacts':supplement,'primary_13_case_metrics_changed':False},
 'valid_usefulness_cases':12,'first_artifact_pass':8,'final_artifact_pass':10,'invalid_cases':['wh07'],'sealed_cases':13,'first_strict_workflow_pass':0,'final_strict_workflow_pass':2,
 'local_unattended_workhorse':'NOT_SUPPORTED by this trial','cloud_superiority':'UNMEASURED; no paired task baseline','remaining_required_evaluation_work':[],
 'review_limits':['Pages reuse project checkers; nonauthor inspected their source and actual artifacts, not an independent checker reimplementation.','Initial reviewer glyph wording for wh07 is clarified by its own follow-up using ASCII numeric codepoints; raw initial text remains archived.','Short hand-authored tasks plus a frozen real-module enhancement, not general large-repository engineering, broad writing quality or a new compaction-retention proof.','All invalid, failed, redundant and pre-inference attempts remain published; artifact passes do not promote strict workflow failures.'],
 'artifacts':artifacts}
(ROOT/'evidence/workhorse-v2-independent-review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'evaluation_report':'READY','project_tests':483,'archived_files':len(artifacts),'supplemental_smoke_original':'2/3','new_artifact_grade':'3/3','primary_metrics_unchanged':True}))
