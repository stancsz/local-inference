"""Bounded read-only inspection of the actual new workhorse outputs."""
import gzip,hashlib,inspect,json,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'scripts')]
from workhorse.cases_v1 import CASES,check,_PROBES,_EXPECTED
section=sys.argv[1]
report=json.loads((ROOT/'evidence/workhorse-v2-parent-review.json').read_text())
if section=='method':
 print(inspect.getsource(check));print(json.dumps(_PROBES,indent=2))
 print(json.dumps(report['totals']));print(json.dumps(report['limits']))
 print((ROOT/'docs/WORKHORSE_USEFULNESS.md').read_text())
elif section=='verifier':
 print(Path(__file__).read_text())
 print('Parent replay source:',(ROOT/'workhorse/review_v2.py').read_text())
elif section=='publication':
 manifest=report['artifacts'];commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 # Independent immutable Git read, not comparison against mutable working files.
 data=subprocess.run(['git','cat-file','--batch'],input=''.join(commit+':'+r['path']+'\n'for r in manifest).encode(),capture_output=True,check=True).stdout
 import io
 stream=io.BytesIO(data)
 for row in manifest:
  header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob'
  compressed=stream.read(int(header[2]));assert stream.read(1)==b'\n'
  assert hashlib.sha256(compressed).hexdigest()==row['compressed_sha256']
  assert hashlib.sha256(gzip.decompress(compressed)).hexdigest()==row['raw_sha256']
 assert not stream.read()
 print({'artifact_commit':commit,'immutable_files_verified':len(manifest),'mismatches':0})
 for name in ('evidence/workhorse-v2-plan.json','evidence/workhorse-v1-setup-failure.json'):
  value=json.loads((ROOT/name).read_text());value.pop('artifacts',None)
  if 'preflight'in value:value['preflight'].pop('artifacts',None)
  if 'cases'in value:value['cases']=[{'id':r['id'],'kind':r['kind']}for r in value['cases']]
  print(name,json.dumps(value))
 print((ROOT/'tmp/stress/workhorse-full-suite-v2.log').read_text())
 print('Frozen v1 environment failure and corrected filter:')
 for name in ('tests/test_workhorse_config_v2.py','tests/test_workhorse_runner_v1.py'):print((ROOT/name).read_text())
else:
 identifiers={'code1':{'wh01','wh02','wh03','wh04'},'code2':{'wh05','wh06','wh13'},'structured':{'wh07','wh08','wh09','wh10','wh11','wh12'}}[section]
 for case in CASES:
  if case['id']not in identifiers:continue
  row=next(c for c in report['cases']if c['id']==case['id']);workspace=ROOT/'tmp/workhorse-v2-20261028'/case['id']/'workspace'
  result=check(case['id'],workspace);assert [(r['name'],r['passed'])for r in result]==[(r['name'],r['passed'])for r in row['phases'][-1]['checks']]
  print('TASK',case['id'],case['prompt'])
  if case['kind']=='json':
   print('ACTUAL SOURCES',json.dumps({name:text for name,text in case['files'].items()if name not in ('answer.json','CONTRACT.md')},ensure_ascii=False))
   print('EXPECTED TYPED FACTS',json.dumps(_EXPECTED[case['id']],ensure_ascii=False))
  print('ACTUAL ARTIFACT',(workspace/case['artifact']).read_text(encoding='utf-8'))
  brief={key:value for key,value in row.items()if key!='phases'}
  brief['phases']=[{key:value for key,value in phase.items()if key not in ('reported_model_usage','native_tools')}for phase in row['phases']]
  print('PARENT PHASE OUTCOMES',json.dumps(brief,ensure_ascii=False))
  if len(row['phases'])>1:
   print('PRESERVED FIRST ARTIFACT',(workspace.parent/'phase-0'/case['artifact']).read_text(encoding='utf-8'))
  print('FRESH FINAL HIDDEN CHECK REPLAY',json.dumps(result))
