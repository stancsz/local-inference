"""Read-only targeted recheck: generated wording and unambiguous codepoints."""
import ast,hashlib,inspect,json,re,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();sys.path[:0]=[str(ROOT/'scripts'),str(ROOT)]
if len(sys.argv)>1 and sys.argv[1]=='unicode':
 source=(ROOT/'tmp/workhorse-v2-20261028/wh07/workspace/source.csv').read_text(encoding='utf-8')
 import csv,io
 key=list(csv.DictReader(io.StringIO(source)))[3]['key']
 assert [ord(c)for c in key]==[0xC3,0x178]
 print(json.dumps({'actual_frozen_key_codepoints':['U+%04X'%ord(c)for c in key],
  'intended_sharp_s_codepoints':['U+00DF'],'actual_key_matches_ss':key.casefold()=='ss',
  'actual_source_sha256':hashlib.sha256(source.encode()).hexdigest(),
  'clarification':'Use codepoints, not a displayed glyph, in the prior review sentence. The frozen fixture is corrupted before model reading; no Sift causality.'}))
 print((ROOT/'evidence/workhorse-wh07-diagnostic-v2.json').read_text(encoding='utf-8').encode('ascii','backslashreplace').decode())
else:
 import claude_acceptance as current
 old_source=subprocess.check_output(['git','show','df2fd1e:scripts/claude_acceptance.py'],text=True,encoding='utf-8')
 tree=ast.parse(old_source);function=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='input_budget_invariant')
 scope={'re':re};exec(compile(ast.Module(body=[function],type_ignores=[]),'recorded-grader','exec'),scope)
 artifact=ROOT/'tmp/workhorse-post-smoke/OPERATIONS.md';text=artifact.read_text(encoding='utf-8')
 assert not scope['input_budget_invariant'](text)and current.validate_operator_guide(text)
 print('OLD FUNCTION',ast.get_source_segment(old_source,function))
 print('CURRENT FUNCTION',inspect.getsource(current.input_budget_invariant))
 print('FULL GENERATED ARTIFACT',text)
 print('NEW NEGATIVE/POSITIVE REGRESSIONS',(ROOT/'tests/test_operator_budget_reference.py').read_text())
 run=subprocess.run([sys.executable,'-m','pytest','-q','-p','no:cacheprovider','tests/test_operator_budget_reference.py','tests/test_acceptance_budget_wording.py'],capture_output=True,text=True,encoding='utf-8',timeout=60)
 assert run.returncode==0;print(run.stdout+run.stderr)
 from daily_artifacts import parse_events,reconstruct_revisions,final_result
 events=parse_events(ROOT/'tmp/workhorse-post-smoke/operator-guide.jsonl');terminal=final_result(events)
 assert not terminal['is_error']
 baseline='PENDING_LOCAL_ACCEPTANCE\n'
 rebuilt=reconstruct_revisions(events,artifact,baseline)[-1]
 assert rebuilt.replace('\r\n','\n')==text.replace('\r\n','\n')
 original=json.loads((ROOT/'tmp/workhorse-post-smoke/claude-acceptance.json').read_text())
 assert [r['passed']for r in original]==[True,True,False]
 print({'original_smoke_retained':[r['passed']for r in original],'native_success_and_artifact_reconstruction':True,'new_operator_grade':True,
   'artifact_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'primary_13_case_metrics_changed':False,'model_regenerations':0})
