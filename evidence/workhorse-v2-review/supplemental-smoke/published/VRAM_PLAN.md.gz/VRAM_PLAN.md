# VRAM Plan — Qwen3.8-27B UD IQ3_XXS workhorse

## Disk sizes (exact raw bytes, model-manifest.json)
- Raw model `Qwen3.8-27B-UD-IQ3_XXS.gguf`: 10934860704 bytes
- MTP `MTP/mtp-Qwen3.8-27B-Q4_0.gguf`: 1369590656 bytes
- Combined disk: 12304451360 bytes

These are on-disk GGUF sizes, not measured runtime VRAM.

## Measured runtime delta (runtime-vram.json)
- baseline_host_used_mib = 1509
- loaded_host_used_mib = 15252
- observed_inference_delta_mib = 13743 (14410579968 bytes)
- Caveat: host delta includes runtime caches/buffers and possible desktop drift; not per-allocation accounting.
- The 14410579968-byte delta exceeds the 12304451360-byte combined disk size, so disk size ≠ runtime delta.
- vmwp dedicated allocation counters overlap; not physical GPU totals or per-model accounting.
- Per-process DedicatedMemory breakdown for the inference process: unknown (Get-Process does not expose a DedicatedMemory GPU property).

## Host GPU snapshot (host-vram.json, older snapshot 2026-10-26T19:00:03Z, predates runtime-vram.json 2026-10-26T23:32:04Z)
gpu CSV order: name,total,used,free.

host_total_mib=16303
host_used_mib=2005
host_free_mib=13991

## Three largest measured process consumers (host-vram.json)
| Process | PID | Dedicated MiB |
|---------|-----|---------------|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

WDDM process counters may overlap; do not sum as physical GPU usage.

## Safe VRAM reclamation after saving work
- Close unused browser tabs or disable browser acceleration after saving work.
- Use a lower resolution or fewer active displays to reduce compositor surfaces.
- Inference can offload weights or KV cache to RAM, at a measurable throughput cost.
- Never terminate DWM.

## Read-only verification
nvidia-smi --query-gpu=memory.total,memory.used,memory.free --format=csv
