# Local LiteLLM Standalone Operations

## Start the stack

```powershell
docker compose up -d --build
```

## Check both ports

```powershell
curl.exe http://127.0.0.1:8090/health/readiness
curl.exe http://127.0.0.1:8091/health
```

## Run acceptance

```powershell
python scripts/claude_acceptance.py
```

## Inspect gateway Sift logs

```powershell
docker compose logs --no-color gateway > tmp/sift-runtime.log
```

## Stop only this project

```powershell
docker compose down
```

## Configured compaction limit and output reserve

Current daily defaults:

```text
context_window=40960
sift_target=32768
output_reserve=4096
draft_tokens=4
```

The policy is adaptive. `sift_target=32768` is the adaptive policy anchor, not a fixed forwarded budget; it is part of the input budget and never added to it. Requests at or below the anchor pass unchanged. Larger requests get `ceil(native_raw_tokens / 8)`, bounded to 24576..36608 when reserving all 4096 output tokens, and capped by `context_window - requested_output - 256`. The 256 tokens are held for decoder headroom. 36608 is a ceiling, not a required request size.

## Why health is not productivity evidence

A readiness response alone proves process readiness, not productive work. Use `scripts/claude_acceptance.py` for productivity evidence.
