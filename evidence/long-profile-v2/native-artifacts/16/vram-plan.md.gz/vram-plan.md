# VRAM Plan — long-profile-v2-16-claude

## Disk sizes (model-manifest.json) — raw bytes on disk
- Raw model `Qwen3.8-27B-UD-IQ3_XXS.gguf`: **10934860704 bytes**
- MTP `mtp-Qwen3.8-27B-Q4_0.gguf`: **1369590656 bytes**
- Combined (model + MTP): **12304451360 bytes**

These are disk byte counts, not VRAM.

## Measured runtime delta (runtime-vram.json) — VRAM, not disk
- `observed_inference_delta_mib`: 13743
- `observed_inference_delta_bytes`: **14410579968**
- Baseline host used 1509 MiB; loaded host used 15252 MiB.

The 14410579968-byte runtime delta is a measured GPU delta and is distinct from the 12304451360-byte disk total; it is not equal to the model file size. It includes runtime caches/buffers and possible unrelated desktop drift, so it is not per-allocation accounting.

## Host snapshot (host-vram.json) — older than runtime-vram.json
Order in host-vram.json is name,total,used,free:
- GPU: NVIDIA GeForce RTX 5070 Ti
- host_total_mib=16303
- host_used_mib=2005
- host_free_mib=13991

This host-vram.json snapshot predates runtime-vram.json and reflects the idle desktop, not the loaded inference run.

## Three largest measured process consumers (host-vram.json)
| Process | PID | Dedicated MiB |
|---|---|---|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

WDDM process counters may overlap; do not sum them as physical GPU usage.

## Safe VRAM reclamation (after saving work)
- Close unused browser tabs or disable browser acceleration after saving work.
- Use a lower resolution or fewer active displays to reduce compositor surfaces.
- Inference can offload weights or KV cache to RAM, at a measurable throughput cost.
- Never terminate DWM.

## Verification
```powershell
Get-Process -Id 195736,57080,311156 | Select-Object Id,ProcessName,@{n='DedicatedMiB';e={ [math]::Round($_.DedicatedMemory/1MB,1) }}
```

## Unknowns
- MTP runtime VRAM contribution: unknown (not separately measured).
- Per-allocation VRAM accounting: unknown.
