# OPERATIONS — daily default local LiteLLM stack

## Start
```powershell
docker compose up -d --build
```

## Check both ports
```powershell
curl.exe http://127.0.0.1:8090/health/readiness
curl.exe http://127.0.0.1:8091/health
```

## Run acceptance
```powershell
python scripts/claude_acceptance.py
```

## Inspect gateway Sift logs
```powershell
docker compose logs --no-color gateway > tmp/sift-runtime.log
```

## Stop only this project
```powershell
docker compose down
```

## Configuration (daily default)
```
context_window=40960
sift_target=32768
output_reserve=4096
draft_tokens=4
```

## Compaction limit and output reserve
Sift uses an **adaptive** per-request policy. `sift_target=32768` is the policy anchor, not a fixed forwarded budget; requests within it pass unchanged when they fit the native window. Larger histories get `ceil(native_raw_tokens / 8)`, bounded to `24576..36608` and `context_window - requested_output - 256`. The Sift target is part of the input budget, never added to it; a further 256 tokens are held for decoder headroom. Reserving all `output_reserve=4096` tokens gives the daily range **24576..36608**; 36608 is a ceiling, not a required request size.

## Health vs productivity
`/health/readiness` proves process readiness only. It is insufficient productivity evidence: it does not prove a completed task, correct output, or productive work.
