# VRAM Plan — long-profile-v2-32-claude

## Disk byte counts (model-manifest.json)
- Raw model `Qwen3.8-27B-UD-IQ3_XXS.gguf`: 10934860704 bytes
- MTP `MTP/mtp-Qwen3.8-27B-Q4_0.gguf`: 1369590656 bytes
- Combined: 12304451360 bytes

Disk size is static file size on disk, not measured GPU VRAM. The measured runtime delta (runtime-vram.json) is `observed_inference_delta_mib` = 13743 MiB (14410579968 bytes), captured at 2026-10-26T23:32:04Z. The host snapshot in host-vram.json was captured earlier at 2026-10-26T19:00:03Z and is a separate measurement.

## Measured host process consumers (host-vram.json, 2026-10-26T19:00:03Z)

| Process | PID | Dedicated MiB |
|---|---|---|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

WDDM process counters may overlap; do not sum as physical GPU usage.

## Safe VRAM reclamation after saving work
1. Close unused browser tabs (chrome, 283.3 MiB) or disable browser hardware acceleration.
2. Close ChatGPT desktop app (368.7 MiB) if not needed.
3. Lower display resolution or reduce active displays to shrink DWM compositor surfaces (1688.2 MiB).
4. Offload inference weights or KV cache to RAM, accepting a measurable throughput cost.

Never terminate DWM.

## Verification
```powershell
nvidia-smi --query-gpu=name,memory.total,memory.used,memory.free --format=csv,noheader,nounits
```

host_total_mib=16303
host_used_mib=2005
host_free_mib=13991

Runtime delta (runtime-vram.json): observed_inference_delta_mib=13743, under_14_decimal_GB_by_delta=false.
