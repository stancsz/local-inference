import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'scripts'))
import daily_artifacts as runner
import daily_acceptance as validator
from setup_env import gateway_key

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    for epoch in ('v1', 'v2'):
        assert (ROOT/('tmp/daily-feedback-'+epoch)/'run-summary.json').is_file(), epoch+' is not terminal'
    destination = ROOT/'evidence/daily-feedback-v2-artifacts'
    destination.mkdir(exist_ok=True)
    secrets = [gateway_key()] + [value for name,value in os.environ.items()
        if name.endswith(('_KEY', '_TOKEN')) and len(value)>12]
    rows, manifests = [], []
    sources = validator.load_sources(ROOT)
    for epoch in ('v1', 'v2'):
        origin = ROOT/('tmp/daily-feedback-'+epoch)
        summary = json.loads((origin/'run-summary.json').read_text(encoding='utf-8'))
        for task in summary['tasks']:
            previous = validator.BASELINE_CONTENT
            session = None
            for phase in task['phases']:
                directory = origin/task['task']/('phase-'+str(phase['phase']))
                events = runner.parse_events(directory/'stdout.jsonl')
                revision = (origin/phase['revision_file']).read_text(encoding='utf-8')
                replayed = runner.reconstruct_revisions(events, origin/task['artifact'], previous)[-1]
                result = runner.final_result(events)
                assert replayed.rstrip('\r\n') == revision.rstrip('\r\n')
                assert sha(revision.encode()) == phase['artifact_sha256']
                assert result['session_id'] == phase['session_id']
                if session:
                    assert session == result['session_id']
                session = result['session_id']
                rows.append({'epoch':epoch,'task':task['task'],'phase':phase['phase'],
                    'native_reconstruction':True,'session_continuity':True,
                    'recorded_accepted':not phase['errors'], 'recorded_errors':phase['errors'],
                    'artifact_errors_replayed':validator.validate_task_artifact(task['task'], revision, sources),
                    'sha256':phase['artifact_sha256'], 'seconds':phase['seconds']})
                previous = replayed
        for relative, digest in summary['source_hashes'].items():
            raw=(ROOT/relative).read_bytes()
            if sha(raw)!=digest:
                canonical=subprocess.check_output(['git','show','2b6eb2e:'+relative])
                candidates=(canonical,canonical.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'))
                raw=next((data for data in candidates if sha(data)==digest),None)
                assert raw is not None, relative
            target=destination/epoch/'source-snapshots'/Path(relative+'.gz')
            target.parent.mkdir(parents=True,exist_ok=True)
            compressed=gzip.compress(raw,mtime=0)
            target.write_bytes(compressed)
            manifests.append({'path':target.relative_to(ROOT).as_posix(),
                'raw_sha256':sha(raw),'compressed_sha256':sha(compressed)})
        for path in sorted(origin.rglob('*')):
            if not path.is_file():continue
            data = path.read_bytes()
            for secret in secrets:
                assert secret.encode() not in data, 'Credential found: '+str(path)
            relative = Path(epoch)/path.relative_to(origin)
            target = destination/relative.with_name(relative.name+'.gz')
            target.parent.mkdir(parents=True, exist_ok=True)
            compressed = gzip.compress(data, mtime=0)
            target.write_bytes(compressed)
            manifests.append({'path':target.relative_to(ROOT).as_posix(),
                'raw_sha256':sha(data),'compressed_sha256':sha(compressed)})
    for relative in ('scripts/daily_artifacts.py','scripts/daily_acceptance.py','scripts/claude_acceptance.py'):
        target=destination/'producer-v2'/relative
        data=target.read_bytes() if target.exists() else (ROOT/relative).read_bytes()
        plan=json.loads((ROOT/'tmp/daily-feedback-v2/plan.json').read_text())
        assert sha(data)==plan['harness_hashes'][relative], relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        manifests.append({'path':target.relative_to(ROOT).as_posix(),'raw_sha256':sha(data)})
    report={'producer_v2_commit':'2b6eb2e',
        'current_validator_sha256':sha((ROOT/'scripts/claude_acceptance.py').read_bytes()),
        'replay_note':'Original phase outcomes are unchanged. Current replay accepts equivalent Markdown sift_target wording; original v2 producer snapshots remain exact and pinned.',
        'qualification_increment':0,'prior_candidates':{'Claude':8,'OpenCode':9,'Codex':6},
        'full_goal':'NOT_READY','phases':rows,'artifacts':manifests,
        'provenance_limit':'v1 did not save producer hashes before execution; its exact prompts, native streams and revisions are retained. v2 saves its plan before inference.'}
    (ROOT/'evidence/daily-feedback-v2-parent-review.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'phases':len(rows),'published_files':len(manifests),'qualification_increment':0}))

if __name__=='__main__':main()
