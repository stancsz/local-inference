# VRAM Plan — daily-one-shot-v3

## Disk sizes (raw bytes, model-manifest.json)
- Raw model `Qwen3.8-27B-UD-IQ3_XXS.gguf`: 10934860704 bytes
- MTP `mtp-Qwen3.8-27B-Q4_0.gguf`: 1369590656 bytes
- Combined (model + MTP): 12304451360 bytes

These are on-disk GGUF file sizes, not measured runtime GPU usage.

## Measured runtime delta (runtime-vram.json)
- Baseline host used: 1509 MiB
- Loaded host used: 15252 MiB
- Observed inference delta: 13743 MiB (14410579968 bytes)
- `under_14_decimal_GB_by_delta`: false

The delta includes runtime caches/buffers and possible unrelated desktop drift; it is not per-allocation accounting. Disk size and measured delta are different quantities.

## Host GPU snapshot (host-vram.json, older snapshot 2026-10-26T19:00:03Z)
GPU: NVIDIA GeForce RTX 5070 Ti

host_total_mib=16303
host_used_mib=2005
host_free_mib=13991

## Top three measured process consumers (host-vram.json)
| Process | PID | Dedicated MiB |
|---|---|---|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

## Safe VRAM reclamation after saving work
- Close unused browser tabs or disable browser hardware acceleration.
- Lower display resolution or reduce active displays to shrink compositor surfaces.
- Allow inference to offload weights or KV cache to RAM (measurable throughput cost).
- Never terminate DWM.

## Verification (PowerShell)
```powershell
nvidia-smi --query-gpu=name,memory.total,memory.used,memory.free --format=csv,noheader,nounits
```
Cross-check host_used_mib against the CSV `used` column (order: name,total,used,free).

Unmeasured facts: per-allocation GPU accounting for the model and MTP at runtime — unknown.

VRAM_PLAN_DONE
