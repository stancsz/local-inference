# Daily one-shot v3 operations

## Start

```powershell
docker compose up -d
```

## Check both ports

```powershell
curl.exe http://127.0.0.1:8090/health/readiness
curl.exe http://127.0.0.1:8091/health
```

## Acceptance

```powershell
python scripts/claude_acceptance.py
```

## Sift logs

```powershell
docker compose logs --no-color gateway > tmp/sift-runtime.log
```

## Stop only this project

```powershell
docker compose down
```

## Compaction limit and output reserve

The daily default is `context_window=40960`, `sift_target=32768`, `output_reserve=4096`, `draft_tokens=4`. The Sift target is an adaptive policy anchor inside the input budget, never added to it; a further 256 tokens are held for decoder headroom. With all 4096 output tokens reserved, request-adaptive budgeting spans 24576..36608. Short requests pass unchanged; 36608 is a ceiling, not a required request size. A readiness response alone proves process readiness, not productive work.
