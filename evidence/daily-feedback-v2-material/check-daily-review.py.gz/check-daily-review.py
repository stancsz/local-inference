import gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import daily_artifacts as runner
import daily_acceptance as validator
report=json.loads((ROOT/'evidence/daily-feedback-v2-parent-review.json').read_text())
for item in report['artifacts']:
    data=(ROOT/item['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==item.get('compressed_sha256',item['raw_sha256'])
    if item['path'].endswith('.gz'):
        assert hashlib.sha256(gzip.decompress(data)).hexdigest()==item['raw_sha256']
results=[]
for epoch in ('v1','v2'):
    folder=ROOT/('tmp/daily-feedback-'+epoch)
    summary=json.loads((folder/'run-summary.json').read_text())
    for relative,digest in summary['source_hashes'].items():
        captured=ROOT/'evidence/daily-feedback-v2-artifacts'/epoch/'source-snapshots'/Path(relative+'.gz')
        assert hashlib.sha256(gzip.decompress(captured.read_bytes())).hexdigest()==digest
    for task in summary['tasks']:
        previous=validator.BASELINE_CONTENT
        session=None
        for phase in task['phases']:
            events=runner.parse_events(folder/task['task']/('phase-'+str(phase['phase']))/'stdout.jsonl')
            final=runner.final_result(events)
            assert not final.get('is_error') and final['session_id']==phase['session_id']
            if session:assert session==final['session_id']
            session=final['session_id']
            expected=runner.reconstruct_revisions(events,folder/task['artifact'],previous)[-1]
            actual=(folder/phase['revision_file']).read_text(encoding='utf-8')
            assert expected.rstrip('\r\n')==actual.rstrip('\r\n')
            assert hashlib.sha256(actual.encode()).hexdigest()==phase['artifact_sha256']
            previous=expected
        results.append({'epoch':epoch,'task':task['task'],'accepted':task['passed'],
            'final_artifact_errors':validator.validate_task_artifact(task['task'],actual,validator.load_sources())})
test=subprocess.run([sys.executable,'-m','pytest','tests/test_daily_acceptance.py','tests/test_daily_artifacts.py','tests/test_acceptance_budget_wording.py','-q'],capture_output=True,text=True)
print(json.dumps({'files_verified':len(report['artifacts']),'tasks':results,'tests_exit':test.returncode,'tests':test.stdout,'qualification_increment':0}))
for name in ('scripts/daily_artifacts.py','scripts/daily_acceptance.py','scripts/claude_acceptance.py',
             'tmp/daily-feedback-v2/vram-plan/vram-plan.md','tmp/daily-feedback-v2/model-audit/model-audit.json',
             'tmp/daily-feedback-v2/operator-guide/OPERATIONS.md',
             'tmp/daily-feedback-v1/vram-plan/phase-1/prompt.txt',
             'tmp/daily-feedback-v1/vram-plan/phase-1/phase.json',
             'tmp/daily-feedback-v2/operator-guide/phase-1/prompt.txt',
             'tmp/daily-feedback-v2/operator-guide/phase-1/phase.json'):
    print(json.dumps({'inspected_file':name,'actual_utf8_content':(ROOT/name).read_text(encoding='utf-8')}))
raise SystemExit(test.returncode)
