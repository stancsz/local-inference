"""A single read-only command, shared verbatim by prompt and client allowlist."""
import json,os,subprocess,tempfile,urllib.request,uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
BASE='http://127.0.0.1:4000'
COMMAND='python tmp/stress/check-daily-review.py'
PREFIX=ROOT/'tmp/stress/final-goal-review-v1'

def request(path,body,key):
    req=urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=60)as response:return json.load(response)

def main():
    master=os.environ['GATEWAY_MASTER_KEY']
    alias='local-shared-mtp-review-'+uuid.uuid4().hex[:12]
    key=request('/key/generate',{'key_alias':alias,'models':['default'],'duration':'15m','max_budget':5},master)['key']
    commands=['python tmp/stress/final-goal-review-pages-v1.py --section '+name for name in ('goal1','goal2','goal3','goal4','verifier','boundary','policy','checks','codex','daily','engineering','migration','expenses')]
    allowed=','.join('Bash('+command+')' for command in commands)
    prompt=('Fresh NONAUTHOR read-only full-goal acceptance, not an increment review. Execute all 13 exact Bash commands below. Read all four complete GOAL slices first, including the original Ask/Acceptance; earlier statuses are a preserved historical ledger. Inspect the verifier source, actual runtime/policy sources, positive and negative generated artifacts, source identity, published hashes, native/session/source-capture replays, task regressions and limits. Original owner asks: a separate minimal Docker local Qwen27B3/4bit+MTP gateway, mandatory Sift dynamic24k..64k budgeting for256k..1M histories, below14GB model/MTP VRAM, prefer64k input+4k output or a productive smaller profile, measured speed, three real native Claude tasks, preserve caller approvals/settings, improve both repos and commit/push. The adopted campaign also requires21 qualifying sessions and seven per CLI with final independent review. Current candidate24 spans explicitly separate epochs; old failures must remain failures. Product inference stays8090, no cloud fallback/Subroute runtime dependency; this supporting review uses4000/default. Distinguish actual user criteria from optional marketing targets. Do not infer universal output correctness, semantic retention or isolated residency from bounded evidence. Start with ways to disprove readiness, then inspect every supplied page personally. Return one JSON object with verdict READY/NOT_READY/UNVERIFIED for the FULL GOAL, criterion-by-criterion evidence/status, remaining work, attribution of software vs model/hardware limits and review limits. A supplied helper is not an independent verifier implementation; inspect its logic and name that limit. No product, evidence, acceptance or artifact edits. Tools are scoped to these exact read-only pages; tests/temp fixtures are permitted. No delegation, network/provider calls or additional commands.\n'+'\n'.join(json.dumps({'command':c})for c in commands)+'\n')
    assert [json.loads(line)['command'] for line in prompt.splitlines()[1:]]==commands
    PREFIX.with_suffix('.plan.json').write_text(json.dumps({'artifact_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'helper_sha256':__import__('hashlib').sha256((ROOT/'tmp/stress/final-goal-review-pages-v1.py').read_bytes()).hexdigest(),'route':BASE,'model':'default','commands':commands,'allowlist':allowed,'max_turns':18,'timeout_seconds':480,'scope':'read-only independent FULL GOAL acceptance'},indent=2))
    try:
        with tempfile.TemporaryDirectory(prefix='daily-review-exact-')as config:
            env={k:v for k,v in os.environ.items()if not k.endswith(('_KEY','_TOKEN','_KEY_ID'))}
            env.pop('CLAUDECODE',None)
            env.update(ANTHROPIC_API_KEY=key,ANTHROPIC_BASE_URL=BASE,ANTHROPIC_MODEL='default',
                ANTHROPIC_DEFAULT_OPUS_MODEL='default',ANTHROPIC_DEFAULT_SONNET_MODEL='default',ANTHROPIC_DEFAULT_HAIKU_MODEL='default',
                CLAUDE_CONFIG_DIR=config,CLAUDE_CODE_DISABLE_1M_CONTEXT='1',CLAUDE_CODE_MAX_CONTEXT_TOKENS='256000',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC='1',API_TIMEOUT_MS='100000',
                PYTHONPATH=str(ROOT.parent/'sift/src')+';'+str(ROOT)+';'+str(ROOT/'app')+';'+str(ROOT/'scripts'))
            args=['claude.cmd','--bare','-p','--model','default','--output-format','stream-json','--verbose',
                  '--max-turns','18','--permission-mode','acceptEdits','--tools','Bash','--allowedTools',allowed]
            with PREFIX.with_suffix('.jsonl').open('w',encoding='utf-8')as out,PREFIX.with_suffix('.stderr.log').open('w',encoding='utf-8')as err:
                process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=out,stderr=err,text=True,encoding="utf-8",env=env,cwd=ROOT)
                try:process.communicate(prompt,timeout=480)
                except subprocess.TimeoutExpired:
                    subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
                    process.communicate(timeout=15)
                    raise
            PREFIX.with_suffix('.exit.json').write_text(json.dumps({'exit_code':process.returncode,'alias':alias}))
    finally:
        request('/key/delete',{'key_aliases':[alias]},master)
        PREFIX.with_suffix('.revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
    print('Review terminal; task key revoked',flush=True)

if __name__=='__main__':main()
