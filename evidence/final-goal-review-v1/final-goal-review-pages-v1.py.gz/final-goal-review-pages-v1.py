"""Bounded read-only full-goal inspection pages; no inference or evidence writes."""
import argparse,gzip,hashlib,importlib,inspect,json,os,subprocess,sys,tempfile,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts'),str(ROOT.parent/'sift/src'),str(ROOT/'app')]
from stress.campaign_v3 import parse_events,session_id
from stress.native_v3 import native_evidence
from stress.portable_tasks_v2 import stage
from stress.balanced_review_v2 import inspect_capture,solution_reference_access
SECTIONS=['goal1','goal2','goal3','goal4','boundary','policy','checks','codex','daily','engineering','migration','expenses','verifier']
parser=argparse.ArgumentParser();parser.add_argument('--section',choices=SECTIONS,required=True);section=parser.parse_args().section
out=[]
def source(name):out.extend([name,(ROOT/name).read_text(encoding='utf-8')])
def archive_json(relative):return json.loads(gzip.decompress((ROOT/relative).read_bytes()))
if section=='verifier':
 source('tmp/stress/final-goal-review-pages-v1.py')
elif section.startswith('goal'):
 text=(ROOT/'GOAL.md').read_text(encoding='utf-8');assert len(text)<=56000
 number=int(section[-1])-1;start=number*14000
 out.extend([f'Full GOAL.md slice {start}:{min(start+14000,len(text))} of {len(text)} characters. Read all four slices; the historical ledger retains earlier statuses.',text[start:start+14000]])
elif section=='boundary':
 for name in ('app/gateway.py','app/budget.py','scripts/claude_local.py','gateway.yaml'):source(name)
elif section=='policy':
 from sift.core import _stable_anchors,_bounded_anchors
 source('../sift/src/sift/dynamic.py')
 out.extend([inspect.getsource(_stable_anchors),inspect.getsource(_bounded_anchors)])
 for name in ('docker/start-inference.sh','compose.yaml','compose.long.yaml','tests/test_inference_launcher.py'):source(name)
elif section=='checks':
 check=subprocess.run([sys.executable,'evidence/profile-publication-tools/check-profile-publication.py','--commit','HEAD'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=60)
 out.append(check.stdout+check.stderr);assert check.returncode==0
 test=subprocess.run([sys.executable,'-m','pytest','-q'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=180)
 out.append(test.stdout+test.stderr);assert test.returncode==0
 for name in ('final-acceptance-runtime.json','final-acceptance-catalog.json','shared-mtp-pair-v1-parent-review.json'):
  d=json.loads((ROOT/'evidence'/name).read_text());d.pop('artifacts',None);out.extend([name,json.dumps(d)])
 memory=json.loads((ROOT/'evidence/long-profile-v5/parent-review.json').read_text())['cases'][0]
 out.append(json.dumps({k:memory[k]for k in ('memory','capacity','passed_task_count','all_native_tasks_passed','all_artifacts_pass_current_parent_checks')}))
 context=json.loads((ROOT/'evidence/long-profile-v5/32-context.json').read_text())
 out.append(json.dumps([{'raw':r['raw_native_tokens'],'policy_target':r['audit']['target_tokens'],'forwarded':r['audit']['native_input_tokens'],'answer':r['answer'],'passed':r['passed']}for r in context]))
 with urllib.request.urlopen('http://127.0.0.1:8091/props',timeout=10)as response:p=json.load(response)
 assert p['default_generation_settings']['n_ctx']==40960
 actual=subprocess.check_output(['docker','exec','local-inference-inference-1','cat','/start-inference.sh'])
 assert actual==(ROOT/'docker/start-inference.sh').read_bytes()
 out.append('Live default40960 and mounted startup bytes rechecked by this invocation. Runtime/model files were not changed.')
elif section=='codex':
 folder=ROOT/'evidence/codex-shared-mtp-v1'
 receipt=archive_json('evidence/codex-shared-mtp-v1/result.json.gz')
 plan=json.loads((ROOT/'evidence/codex-shared-mtp-v1-plan.json').read_text())
 original_workspace=ROOT/plan['output_dir']/'workspace'
 assert receipt['accepted']and len(receipt['turns'])==9 and receipt['active_client_seconds']>185
 assert receipt['source_sha256']==plan['source_sha256']
 ids=set();count=0
 for index,turn in enumerate(receipt['turns']):
  events=parse_events(gzip.decompress((folder/f'turn-{index:02}.jsonl.gz').read_bytes()).decode('utf-8'))
  native=native_evidence('codex',events,original_workspace)
  assert native==turn['native']and turn['accepted']and not turn['timed_out']and turn['duration_seconds']<240
  assert not any(solution_reference_access(e)for e in events)
  ids.add(session_id('codex',events))
  for label in ('native','hidden'):
   snap=folder/'snapshots'/f'turn-{index:02}-{label}'
   manifest=json.loads(gzip.decompress((snap/'hashes.json.gz').read_bytes()))
   for name,digest in manifest['sha256'].items():
    if digest is not None:assert hashlib.sha256(gzip.decompress((snap/(name+'.gz')).read_bytes())).hexdigest()==digest
   expected=stage('incident_log',index,plan['case']['seed']+index)['tests'].encode().replace(b'\n',os.linesep.encode())
   assert hashlib.sha256(expected).hexdigest()==manifest['sha256']['test_task.py']==turn['public_tests_sha256']
   with tempfile.TemporaryDirectory(prefix='goal-qa-',dir=ROOT/'tmp')as temp:
    work=Path(temp);assert work.resolve().parent==(ROOT/'tmp').resolve()
    for name in ('task.py','evidence.json'):(work/name).write_bytes(gzip.decompress((snap/(name+'.gz')).read_bytes()))
    for offset in (0,100003,200003):
     tests=stage('incident_log',index,plan['case']['seed']+index+offset)['tests']
     prefix="import sys;sys.path.insert(0,sys.argv[1]);sys.argv=['independent-qa'];"
     run=subprocess.run([sys.executable,'-I','-B','-c',prefix+tests,str(work)],cwd=work,capture_output=True,timeout=20)
     assert run.returncode==0,(index,label,offset,run.stdout,run.stderr)
     count+=1
 assert ids=={receipt['session_id']}
 for index,audit in enumerate(receipt['audits']):
  raw=gzip.decompress((folder/'requests'/audit['excerpt_capture']).read_bytes())
  errors,row=inspect_capture(raw,index,audit);assert not errors and row['original_fact_observed_in_source0']
  assert audit['upstream_status']==200
 for audit in receipt['native_gateway_audits']:assert audit['native_input_tokens']+audit['output_reserve']+audit['decoder_headroom']<=audit['context_window']
 prior=json.loads((ROOT/'evidence/balanced-v2-parent-review.json').read_text())
 assert prior['candidate_aggregate_qualifying']==23 and prior['aggregate_clients']=={'claude':8,'opencode':9,'codex':6}
 out.append(json.dumps({'native_turns_replayed':9,'snapshots':18,'behavior_checks_executed':count,'source0_captures_checked':len(receipt['audits']),'native_context_checks':len(receipt['native_gateway_audits']),'session_id':receipt['session_id'],'active_seconds':receipt['active_client_seconds'],'candidate_counts':{'claude':8,'opencode':9,'codex':7},'candidate_total':24,'scope':'Original19 + prior supplement1 + balanced3 + new repaired-source Codex1. First-stage excerpts only; no claim of full wire payload capture or retroactive repair of failed artifacts.'}))
 out.append(gzip.decompress((folder/'workspace/task.py.gz').read_bytes()).decode('utf-8'))
 out.append('Preserved capture-proxy stderr, including the connection-close callback traceback:')
 out.append(gzip.decompress((folder/'controller/codex-shared-mtp-v1.stderr.log.gz').read_bytes()).decode('utf-8'))
elif section=='daily':
 for path in sorted((ROOT/'evidence/long-profile-v5/native-artifacts/32').rglob('*.gz')):
  if path.name in ('OPERATIONS.md.gz','vram-plan.md.gz','model-audit.json.gz'):out.extend([str(path.relative_to(ROOT)),gzip.decompress(path.read_bytes()).decode('utf-8')])
 path=ROOT/'evidence/shared-mtp-launcher-v1/native-one-shot/OPERATIONS.md.gz'
 out.extend(['Preserved rejected default one-shot runbook',gzip.decompress(path.read_bytes()).decode('utf-8')])
 report=json.loads((ROOT/'evidence/shared-mtp-launcher-v1/parent-review.json').read_text())
 out.append(json.dumps({'one_shot_results':report['one_shot_native'],'bounded_feedback':[{'task':t['task'],'passed':t['passed'],'repairs':t['repairs_used'],'final_errors':t['final_errors']}for t in report['bounded_feedback']['tasks']]}))
 out.append('Read current README independently of this helper:')
 text=(ROOT/'README.md').read_text(encoding='utf-8');out.append(text[:text.index('## Reproducible acceptance')])
else:
 task=section
 candidate=ROOT/'evidence/feedback-recovery-v2'/task/'task.py'if task!='expenses'else ROOT/'evidence/expense-feedback-v3/experiment/task.py'
 out.extend([str(candidate.relative_to(ROOT)),candidate.read_text(encoding='utf-8')])
 if task!='expenses':
  report=json.loads((ROOT/'evidence/feedback-recovery-v2.json').read_text())
  entry=next(row for row in report['parent_artifact_review']if row['task']==task)
  assert hashlib.sha256(candidate.read_bytes()).hexdigest()==entry['turns'][-1]['generated_sha256']
 else:
  report=json.loads((ROOT/'evidence/expense-feedback-v3-parent-review.json').read_text())
  assert hashlib.sha256(candidate.read_bytes()).hexdigest()==report['final_sha256']
 from recovery.check_fixture import check_fixture
 checked=check_fixture(task,candidate);assert checked['passed']
 out.append(json.dumps(checked))
 testfile=ROOT/'tests'/('test_'+{'engineering':'engineering','migration':'migration','expenses':'expense'}[task]+'_recovery.py')
 code="import sys,importlib.util;from pathlib import Path;import pytest;p=Path(sys.argv[1]);s=importlib.util.spec_from_file_location(p.stem,p);m=importlib.util.module_from_spec(s);sys.modules[p.stem]=m;s.loader.exec_module(m);m.CANDIDATE_PATH=Path(sys.argv[2]);raise SystemExit(pytest.main(['-q','-p','no:cacheprovider',str(p),'--import-mode=prepend']))"
 run=subprocess.run([sys.executable,'-c',code,str(testfile),str(candidate)],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=60)
 out.append(run.stdout+run.stderr);assert run.returncode==0
 if task=='expenses':
  from recovery.expense_feedback_v3 import additional_checks
  extra=additional_checks(candidate);assert len(extra)==6 and all(r['passed']for r in extra)
  out.append(json.dumps({'six_additional_expense_checks':extra,'preserved_baseline_failures':report['baseline_additional']}))
 out.append('Generated recovery artifacts only; original campaign defects and failed attempts are not changed or promoted.')
payload='\n'.join(out)
assert len(payload)<18000,(section,len(payload))
print(payload)
