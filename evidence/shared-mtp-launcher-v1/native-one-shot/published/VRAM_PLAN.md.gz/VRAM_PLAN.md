# Shared-MTP Default v1 — VRAM Plan

## Disk sizes (model-manifest.json, exact raw bytes)
- Raw model `Qwen3.8-27B-UD-IQ3_XXS.gguf`: 10934860704 bytes
- MTP `MTP/mtp-Qwen3.8-27B-Q4_0.gguf`: 1369590656 bytes
- Combined: 12304451360 bytes

These are disk file sizes, not measured GPU runtime.

## Measured runtime delta (runtime-vram.json)
- Baseline host used: 1509 MiB; loaded host used: 15252 MiB
- Observed inference delta: 13743 MiB = 14410579968 bytes
- vmwp dedicated allocation counters: 13803126784 + 24059904 + 0 = 13827186688 bytes (may overlap; not physical totals)

The runtime delta is measured host GPU usage (weights + KV cache + buffers + possible desktop drift), distinct from the 12304451360-byte disk total. Unmeasured per-allocation breakdown: unknown.

## Host snapshot (host-vram.json, older than runtime-vram.json)
- GPU: NVIDIA GeForce RTX 5070 Ti
- host_total_mib=16303
- host_used_mib=2005
- host_free_mib=13991

### Three largest measured process consumers
| Process | PID | Dedicated MiB |
|---|---|---|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

Note: WDDM process counters may overlap; do not sum as physical GPU usage.

## Safe VRAM reclamation after saving work
- Close unused browser tabs or disable browser acceleration (chrome, ChatGPT).
- Lower resolution or reduce active displays to shrink compositor surfaces.
- Offload weights or KV cache to RAM at a measurable throughput cost.
- Never terminate DWM.

## Verification (read-only)
PowerShell:
nvidia-smi --query-gpu=memory.total,memory.used,memory.free --format=csv

Note: Get-Process does not expose a DedicatedMemory GPU property.
