# Shared-MTP Default v1 — Claude Operations

## Start the standalone stack

```powershell
docker compose up -d
```

## Check both ports

```powershell
curl.exe http://127.0.0.1:8090/health/readiness
curl.exe http://127.0.0.1:8091/health
```

## Run acceptance

```powershell
python scripts/claude_acceptance.py
```

## Inspect gateway Sift logs

```powershell
docker compose logs --no-color gateway > tmp/sift-runtime.log
```

## Stop only this compose project

```powershell
docker compose down
```

## Configured compaction limit and 4096-token output reserve

The daily default uses `context_window=40960`, `sift_target=32768`, `output_reserve=4096`, `draft_tokens=4`. The Sift target is part of the input budget, never added to it; a further 256 tokens are held for decoder headroom. The adaptive policy selects a request-dependent budget, bounded to 24,576–36,608 when all 4,096 output tokens are reserved. Short requests pass unchanged; 36,608 is a ceiling, not a required request size.

## Why health is insufficient productivity evidence

A readiness response alone proves process readiness, not productive work.
