import unittest
from solution import summarize
class Public(unittest.TestCase):
 def test_counts(self): self.assertEqual(summarize(['{"level":"info","message":"ok"}','bad'])['malformed'],1)
