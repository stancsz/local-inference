import json
import re

_EMAIL_RE = re.compile(
    r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"
)
_IPV4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")


def _redact(text):
    text = _EMAIL_RE.sub("[REDACTED]", text)
    text = _IPV4_RE.sub("[REDACTED]", text)
    return text


def summarize(lines):
    valid = 0
    malformed = 0
    by_level = {}
    messages = []
    for line in lines:
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except ValueError:
            malformed += 1
            continue
        if not isinstance(obj, dict) or not isinstance(obj.get("message"), str):
            malformed += 1
            continue
        valid += 1
        level = obj.get("level")
        if not isinstance(level, str):
            level = "unknown"
        by_level[level] = by_level.get(level, 0) + 1
        messages.append(_redact(obj["message"]))
    return {
        "valid": valid,
        "malformed": malformed,
        "by_level": by_level,
        "messages": messages,
    }
