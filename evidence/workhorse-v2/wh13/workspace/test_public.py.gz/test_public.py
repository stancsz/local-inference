import unittest
from pathlib import Path
from usage_report import tokens
class Public(unittest.TestCase):
 def test_old(self): self.assertEqual(tokens(Path('legacy.json')),17)
 def test_envelope(self): self.assertEqual(tokens(Path('event.json')),11)
