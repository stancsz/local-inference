Implement merge_pages(pages): flatten pages of records in order, deduplicate by integer id keeping the first occurrence, and return a list. Input records may have extra fields. Empty pages return [].
