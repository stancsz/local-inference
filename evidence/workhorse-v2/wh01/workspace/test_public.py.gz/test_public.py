import unittest
from solution import merge_pages
class Public(unittest.TestCase):
 def test_dedup(self): self.assertEqual(merge_pages([[{'id':1},{'id':1}],[{'id':2}]]),[{'id':1},{'id':2}])
