def merge_pages(pages):
    seen = set()
    result = []
    for page in pages:
        for record in page:
            rid = record.get('id')
            if rid in seen:
                continue
            seen.add(rid)
            result.append(record)
    return result
