import unittest
from solution import classify_response
class Public(unittest.TestCase):
 def test_only_server_errors_retry(self): self.assertFalse(classify_response(404,'temporary')['retry'])
