def classify_response(status, body):
    if isinstance(status, bool) or not isinstance(status, int):
        return {'retry': False, 'reason': 'invalid_status'}
    if status == 429:
        return {'retry': True, 'reason': 'rate_limited'}
    if 500 <= status <= 599:
        return {'retry': True, 'reason': 'server_error'}
    return {'retry': False, 'reason': 'permanent'}
