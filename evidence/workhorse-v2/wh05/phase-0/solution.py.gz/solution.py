def join_rows(left, right):
    lookup = {}
    for row in right:
        try:
            key = row['sku']
        except (KeyError, TypeError):
            continue
        if key is None:
            continue
        try:
            hash(key)
        except TypeError:
            continue
        lookup[key] = row
    result = []
    for row in left:
        try:
            key = row['sku']
        except (KeyError, TypeError):
            merged = dict(row)
        else:
            merged = dict(row)
            if key is not None:
                try:
                    match = lookup.get(key)
                except TypeError:
                    match = None
                if match is not None:
                    for k, v in match.items():
                        if k not in merged:
                            merged[k] = v
        result.append(merged)
    return result
