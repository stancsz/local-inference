"""Read-only verification and one authorized local metadata marker challenge."""
import importlib,json,hashlib,subprocess,sys
from pathlib import Path
root=Path.cwd()
publication=json.loads(subprocess.check_output([sys.executable,'tmp/stress/check-repair-publication.py'],text=True))
tests=subprocess.run([sys.executable,'-m','pytest','tests','-q'],capture_output=True,text=True,timeout=90)
assert tests.returncode==0,tests.stdout+tests.stderr
boundary=json.loads(subprocess.check_output([sys.executable,'tmp/stress/probe-catalog-live.py'],text=True,timeout=300))
assert boundary['assistant_nonce_matched'] and boundary['unsupported_approval_state']['status']==422
code="import json,hashlib;from pathlib import Path;print(json.dumps({n:hashlib.sha256(Path('/app/'+n+'.py').read_bytes()).hexdigest() for n in ('budget','gateway')}))"
actual=json.loads(subprocess.check_output(['docker','exec','local-inference-gateway-1','python','-c',code],text=True))
expected={n:hashlib.sha256((root/'app'/f'{n}.py').read_bytes()).hexdigest() for n in actual}
assert actual==expected
summary=json.loads((root/'evidence/repair-v3-summary.json').read_text())
print(json.dumps({'publication':publication,'tests':tests.stdout.splitlines()[-1],
    'deployed_app_source_matches':True,'catalog_nonce_roundtrip':True,'unsupported_approval_http_status':422,
    'full_goal_complete':False,'candidate_sessions':summary['aggregate_unchanged'],'clients':summary['clients_unchanged'],
    'final_short_artifacts':summary['final_short_artifacts'],'scope':'Actual checks executed by this process, not a parent verdict'},indent=2))
