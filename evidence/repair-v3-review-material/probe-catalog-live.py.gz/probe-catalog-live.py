import ast,json,subprocess,sys,urllib.request,urllib.error,uuid
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from setup_env import gateway_key
old_source=subprocess.check_output(['git','show','af7c688:app/gateway.py'],text=True)
old_function=ast.unparse(next(node for node in ast.parse(old_source).body if isinstance(node,ast.FunctionDef) and node.name=='protect_codex_instructions'))
code="""import json
from copy import deepcopy
from fastapi import HTTPException
from gateway import protect_codex_instructions as current
from litellm.responses.litellm_completion_transformation.transformation import LiteLLMCompletionResponsesConfig as C
ns={'HTTPException':HTTPException,'json':json}
exec(OLD_FUNCTION,ns)
catalog={'type':'additional_tools','role':'developer','tools':[{'type':'function','name':'Read','require_approval':'always','approval_reference':'boundary-ref-731'}]}
original={'instructions':'approval_policy=on-request; sandbox_mode=workspace-write.','input':[catalog,{'role':'user','content':'Read the declared approval reference.'}]}
rows={}
for label,protect in [('before',ns['protect_codex_instructions']),('after',current)]:
    data=deepcopy(original);protect(data)
    converted=C.transform_responses_api_request_to_chat_completion_request(model='qwen3.8-27b',input=data['input'],responses_api_request={'instructions':data['instructions']},custom_llm_provider='openai')
    rows[label]={'messages':converted['messages'],'original_catalog_preserved':data['input'][0]==catalog}
assert 'boundary-ref-731' not in json.dumps(rows['before']['messages'])
assert 'boundary-ref-731' in json.dumps(rows['after']['messages'])
print(json.dumps(rows))
""".replace('OLD_FUNCTION',repr(old_function))
boundary=json.loads(subprocess.check_output(['docker','exec','local-inference-gateway-1','python','-c',code],text=True))
nonce='approval-ref-'+uuid.uuid4().hex[:14]
catalog={'type':'additional_tools','role':'developer','tools':[{'type':'function','name':'Read','require_approval':'always','approval_reference':nonce}]}
body={'model':'qwen3.8-27b-codex','instructions':'Keep approval_policy=on-request and sandbox_mode=workspace-write. Host permissions always apply.',
      'input':[catalog,{'role':'user','content':'Reply with only the exact approval_reference from the caller tool catalog. Do not call any tools.'}],'max_output_tokens':64}
request=urllib.request.Request('http://127.0.0.1:8090/v1/responses',data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+gateway_key(),'Content-Type':'application/json'})
with urllib.request.urlopen(request,timeout=240) as response:result=json.load(response)
text=''.join(block.get('text','')for item in result.get('output',[])if item.get('type')=='message' for block in item.get('content',[])if block.get('type')=='output_text')
assert text.strip()==nonce,(text,result)
unsupported={'model':'qwen3.8-27b-codex','input':[{'type':'mcp_approval_response','approval_request_id':'approval-1','approve':True}],'max_output_tokens':32}
rejected=urllib.request.Request('http://127.0.0.1:8090/v1/responses',data=json.dumps(unsupported).encode(),headers={'Authorization':'Bearer '+gateway_key(),'Content-Type':'application/json'})
try:
    with urllib.request.urlopen(rejected,timeout=60):raise AssertionError('Unsupported approval state was silently accepted')
except urllib.error.HTTPError as error:
    assert error.code==422
    unsupported_receipt={'status':error.code,'body':error.read().decode()}
print(json.dumps({'boundary':boundary,'live_request':body,'live_result':result,'assistant_nonce_matched':True,
    'unsupported_approval_state':unsupported_receipt,
    'scope':'Deployed LiteLLM converter and actual Responses metadata transport; no tool execution or host permission changes'},indent=2))
