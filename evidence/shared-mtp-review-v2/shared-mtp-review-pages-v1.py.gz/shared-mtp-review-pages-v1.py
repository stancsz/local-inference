"""Bounded read-only pages for actual shared-MTP independent review."""
import argparse,gzip,hashlib,json,subprocess,sys,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from profile_memory import summarize_memory
p=argparse.ArgumentParser();p.add_argument('--section',choices=('implementation','checks','artifacts'),required=True)
section=p.parse_args().section
output=[]
if section=='implementation':
 for name in ('docker/start-inference.sh','compose.yaml','compose.long.yaml','scripts/claude_local.py','tests/test_inference_launcher.py'):
  output += [name,(ROOT/name).read_text(encoding='utf-8')]
 output += ['pinned backend source excerpt',(ROOT/'evidence/long-profile-v5/producer/shared-mtp-source.json').read_text()]
elif section=='checks':
 for name in ('evidence/long-profile-v5/parent-review.json','evidence/shared-mtp-launcher-v1/parent-review.json'):
  report=json.loads((ROOT/name).read_text());verified=0
  for row in report['artifacts']:
   data=(ROOT/row['path']).read_bytes()
   assert hashlib.sha256(data).hexdigest()==row.get('compressed_sha256',row.get('sha256'))
   if 'raw_sha256'in row:assert hashlib.sha256(gzip.decompress(data)).hexdigest()==row['raw_sha256']
   verified+=1
  output.append(json.dumps({'report':name,'hashes_checked':verified,'qualification_increment':report['qualification_increment']}))
 long=json.loads((ROOT/'evidence/long-profile-v5/parent-review.json').read_text())
 output.append(json.dumps(long['cases']))
 rows=[json.loads(line)for line in (ROOT/'evidence/long-profile-v5/gpu-samples.jsonl').read_text().splitlines()]
 output.append(json.dumps(summarize_memory(rows,32)))
 default=json.loads((ROOT/'evidence/shared-mtp-launcher-v1/parent-review.json').read_text())
 output.append(json.dumps({'one_shot_native':default['one_shot_native'],'bounded_feedback':[{k:t[k]for k in ('task','passed','repairs_used','final_errors')}for t in default['bounded_feedback']['tasks']]}))
 for name in ('runtime.json','local.json','openai.json'):
  output.extend([name,(ROOT/'evidence/shared-mtp-launcher-v1'/name).read_text()])
 test=subprocess.run([sys.executable,'-m','pytest','-q','tests/test_inference_launcher.py','tests/test_claude_settings_compat.py','tests/test_repair_compatibility.py','tests/test_profile_memory.py'],capture_output=True,text=True,encoding='utf-8',timeout=90)
 output.append(test.stdout+test.stderr);assert test.returncode==0
 with urllib.request.urlopen('http://127.0.0.1:8091/props',timeout=10)as response:props=json.load(response)
 assert props['default_generation_settings']['n_ctx']==40960
 actual=subprocess.check_output(['docker','exec','local-inference-inference-1','cat','/start-inference.sh'])
 assert actual==(ROOT/'docker/start-inference.sh').read_bytes()
 output.append('Live default context40960 and mounted startup bytes independently rechecked.')
else:
 for report_name,prefix in (('evidence/long-profile-v5/parent-review.json','evidence/long-profile-v5/native-artifacts/32'),('evidence/shared-mtp-launcher-v1/parent-review.json','evidence/shared-mtp-launcher-v1/native-one-shot')):
  report=json.loads((ROOT/report_name).read_text())
  for row in report['artifacts']:
   name=row['path']
   if name.startswith(prefix)and name.endswith(('/OPERATIONS.md.gz','/vram-plan.md.gz','/model-audit.json.gz')):
    output.extend([name,gzip.decompress((ROOT/name).read_bytes()).decode('utf-8')])
 output += ['Current documentation excerpt']
 readme=(ROOT/'README.md').read_text(encoding='utf-8')
 output.append(readme[:readme.index('## Lower cloud')])
payload='\n'.join(output)
assert len(payload)<18000,(section,len(payload))
print(payload)
