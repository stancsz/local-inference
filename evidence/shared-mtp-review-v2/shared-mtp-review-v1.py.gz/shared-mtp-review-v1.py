"""A single read-only command, shared verbatim by prompt and client allowlist."""
import json,os,subprocess,tempfile,urllib.request,uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
BASE='http://127.0.0.1:4000'
COMMAND='python tmp/stress/check-daily-review.py'
PREFIX=ROOT/'tmp/stress/shared-mtp-review-v1'

def request(path,body,key):
    req=urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=60)as response:return json.load(response)

def main():
    master=os.environ['GATEWAY_MASTER_KEY']
    alias='local-shared-mtp-review-'+uuid.uuid4().hex[:12]
    key=request('/key/generate',{'key_alias':alias,'models':['default'],'duration':'10m','max_budget':5},master)['key']
    commands=['python tmp/stress/shared-mtp-review-pages-v1.py --section '+name for name in ('implementation','checks','artifacts')]
    allowed=','.join('Bash('+command+')' for command in commands)
    prompt=('Read-only independent shared-MTP startup/profile review. You are not an implementation author. Inspect the startup change and explicit separate-draft compatibility, pinned source excerpt, actual archived generated artifacts and failed default runbook, memory scope and source identity. Judge this increment only; remaining Codex and full-goal gates remain open. Do not infer universal model correctness from task passes. Call all THREE exact Bash input objects below; no extra arguments or other commands. Pages are bounded below 18000 characters to avoid native output truncation. Personally inspect actual sources and all returned positive and negative generated artifacts. Distinguish the new bounded operator case from the preserved failed one-shot; it does not repair the old artifact. Return JSON verdict READY/NOT_READY/UNVERIFIED for this increment, actual inspected scope, checks, findings and limits. Full goal remains NOT_READY; qualification increment0. No product/evidence/artifact edits.'+'\n'+'\n'.join(json.dumps({'command':c})for c in commands)+'\n')
    assert [json.loads(line)['command'] for line in prompt.splitlines()[1:]]==commands
    PREFIX.with_suffix('.plan.json').write_text(json.dumps({'route':BASE,'model':'default','commands':commands,'allowlist':allowed,'max_turns':8,'timeout_seconds':240,'scope':'read-only independent shared MTP startup/profile review'},indent=2))
    try:
        with tempfile.TemporaryDirectory(prefix='daily-review-exact-')as config:
            env={k:v for k,v in os.environ.items()if not k.endswith(('_KEY','_TOKEN','_KEY_ID'))}
            env.pop('CLAUDECODE',None)
            env.update(ANTHROPIC_API_KEY=key,ANTHROPIC_BASE_URL=BASE,ANTHROPIC_MODEL='default',
                ANTHROPIC_DEFAULT_OPUS_MODEL='default',ANTHROPIC_DEFAULT_SONNET_MODEL='default',ANTHROPIC_DEFAULT_HAIKU_MODEL='default',
                CLAUDE_CONFIG_DIR=config,CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC='1',API_TIMEOUT_MS='100000',
                PYTHONPATH=str(ROOT.parent/'sift/src')+';'+str(ROOT)+';'+str(ROOT/'app')+';'+str(ROOT/'scripts'))
            args=['claude.cmd','--bare','-p','--model','default','--output-format','stream-json','--verbose',
                  '--max-turns','8','--permission-mode','acceptEdits','--tools','Bash','--allowedTools',allowed]
            with PREFIX.with_suffix('.jsonl').open('w',encoding='utf-8')as out,PREFIX.with_suffix('.stderr.log').open('w',encoding='utf-8')as err:
                process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=out,stderr=err,text=True,encoding="utf-8",env=env,cwd=ROOT)
                try:process.communicate(prompt,timeout=240)
                except subprocess.TimeoutExpired:
                    subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
                    process.communicate(timeout=15)
                    raise
            PREFIX.with_suffix('.exit.json').write_text(json.dumps({'exit_code':process.returncode,'alias':alias}))
    finally:
        request('/key/delete',{'key_aliases':[alias]},master)
        PREFIX.with_suffix('.revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
    print('Review terminal; task key revoked',flush=True)

if __name__=='__main__':main()
