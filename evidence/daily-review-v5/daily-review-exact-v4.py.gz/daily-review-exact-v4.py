"""A single read-only command, shared verbatim by prompt and client allowlist."""
import json,os,subprocess,tempfile,urllib.request,uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
BASE='http://127.0.0.1:4000'
COMMAND='python tmp/stress/check-daily-review.py'
PREFIX=ROOT/'tmp/stress/daily-review-exact-v4'

def request(path,body,key):
    req=urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=60)as response:return json.load(response)

def main():
    master=os.environ['GATEWAY_MASTER_KEY']
    alias='local-daily-review-'+uuid.uuid4().hex[:12]
    key=request('/key/generate',{'key_alias':alias,'models':['default'],'duration':'10m','max_budget':2},master)['key']
    allowed='Bash('+COMMAND+')'
    prompt=('Read-only independent acceptance. Your sole permitted tool invocation is the Bash input JSON below. '
        'Use it exactly, without extra arguments. It independently verifies 127 published archive/source hashes, '
        'native edits/session continuity and runs the focused tests, then emits actual source files and all three v2 generated artifacts. '
        'Personally inspect those emitted sources/artifacts. Return a JSON verdict READY/NOT_READY/UNVERIFIED for the bounded daily harness increment, '
        'actual checks, findings and limits. Earlier failures stay unchanged; zero long-session qualification increment. '
        'Full goal remains NOT_READY (nine-turn Codex, broad quality, memory/context). No other commands, edits, network or inference.\n'
        +json.dumps({'command':COMMAND})+'\n')
    assert json.loads(prompt.splitlines()[-1])['command']==COMMAND
    (PREFIX.with_suffix('.plan.json')).write_text(json.dumps({'route':BASE,'model':'default','command':COMMAND,'allowlist':allowed,'max_turns':4,'timeout_seconds':240,'scope':'read-only independent daily harness review'},indent=2))
    try:
        with tempfile.TemporaryDirectory(prefix='daily-review-exact-')as config:
            env={k:v for k,v in os.environ.items()if not k.endswith(('_KEY','_TOKEN','_KEY_ID'))}
            env.pop('CLAUDECODE',None)
            env.update(ANTHROPIC_API_KEY=key,ANTHROPIC_BASE_URL=BASE,ANTHROPIC_MODEL='default',
                ANTHROPIC_DEFAULT_OPUS_MODEL='default',ANTHROPIC_DEFAULT_SONNET_MODEL='default',ANTHROPIC_DEFAULT_HAIKU_MODEL='default',
                CLAUDE_CONFIG_DIR=config,CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC='1',API_TIMEOUT_MS='100000',
                PYTHONPATH=str(ROOT.parent/'sift/src')+';'+str(ROOT)+';'+str(ROOT/'app')+';'+str(ROOT/'scripts'))
            args=['claude.cmd','--bare','-p','--model','default','--output-format','stream-json','--verbose',
                  '--max-turns','4','--permission-mode','acceptEdits','--tools','Bash','--allowedTools',allowed]
            with PREFIX.with_suffix('.jsonl').open('w',encoding='utf-8')as out,PREFIX.with_suffix('.stderr.log').open('w',encoding='utf-8')as err:
                process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=out,stderr=err,text=True,env=env,cwd=ROOT)
                try:process.communicate(prompt,timeout=240)
                except subprocess.TimeoutExpired:
                    subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
                    process.communicate(timeout=15)
                    raise
            PREFIX.with_suffix('.exit.json').write_text(json.dumps({'exit_code':process.returncode,'alias':alias}))
    finally:
        request('/key/delete',{'key_aliases':[alias]},master)
        PREFIX.with_suffix('.revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
    print('Review terminal; task key revoked',flush=True)

if __name__=='__main__':main()
