"""Small read-only inspection pages, below the native CLI output truncation limit."""
import argparse,gzip,hashlib,inspect,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import daily_artifacts as runner
import daily_acceptance as validator
import claude_acceptance as legacy
parser=argparse.ArgumentParser()
parser.add_argument('--section',choices=('checks','runner','validators'),required=True)
section=parser.parse_args().section
output=[]
if section=='checks':
    total=0
    for report in ('daily-feedback-v2-parent-review.json','daily-feedback-v2-independent-attempt.json'):
        for row in json.loads((ROOT/'evidence'/report).read_text())['artifacts']:
            data=(ROOT/row['path']).read_bytes()
            assert hashlib.sha256(data).hexdigest()==row.get('compressed_sha256',row['raw_sha256'])
            if row['path'].endswith('.gz'):assert hashlib.sha256(gzip.decompress(data)).hexdigest()==row['raw_sha256']
            total+=1
    assert total==127
    test=subprocess.run([sys.executable,'-m','pytest','tests/test_daily_acceptance.py','tests/test_daily_artifacts.py','tests/test_acceptance_budget_wording.py','-q'],capture_output=True,text=True)
    assert test.returncode==0,test.stdout
    for epoch in ('v1','v2'):
        folder=ROOT/('tmp/daily-feedback-'+epoch)
        summary=json.loads((folder/'run-summary.json').read_text())
        for task in summary['tasks']:
            previous=validator.BASELINE_CONTENT
            session=None
            for phase in task['phases']:
                events=runner.parse_events(folder/task['task']/('phase-'+str(phase['phase']))/'stdout.jsonl')
                native=runner.final_result(events)
                assert native['session_id']==phase['session_id']
                if session:assert native['session_id']==session
                session=native['session_id']
                revision=(folder/phase['revision_file']).read_text(encoding='utf-8')
                assert hashlib.sha256(revision.encode()).hexdigest()==phase['artifact_sha256']
                previous=runner.reconstruct_revisions(events,folder/task['artifact'],previous)[-1]
                assert previous.rstrip('\r\n')==revision.rstrip('\r\n')
            output.append(json.dumps({'epoch':epoch,'task':task['task'],'recorded_accepted':task['passed'],'errors':task['final_errors']}))
    output.append(json.dumps({'files_verified':total,'native_phases_replayed':9,'tests':test.stdout,'qualification_increment':0}))
    for task,name in validator.ARTIFACT_NAMES.items():
        text=(ROOT/'tmp/daily-feedback-v2'/task/name).read_text(encoding='utf-8')
        assert not validator.validate_task_artifact(task,text,validator.load_sources())
        output.extend([name,text])
    output.extend(['normal_client_launcher',(ROOT/'scripts/claude_local.py').read_text()])
elif section=='runner':
    for function in (runner.build_args,runner.build_env,runner.invoke_cli,runner.kill_process_tree,
                     runner.reconstruct_revisions,runner.collect_source_reads,runner.run_task):
        output.append(inspect.getsource(function))
else:
    for function in (validator.feedback_prompt,validator.validate_task_artifact,
                     validator.validate_model_audit_report,validator.validate_vram_plan_report,
                     validator.validate_operator_guide_report,legacy.input_budget_invariant):
        output.append(inspect.getsource(function))
    output.append('original_v1_failed_feedback')
    output.append((ROOT/'tmp/daily-feedback-v1/vram-plan/phase-1/prompt.txt').read_text())
payload='\n'.join(output)
assert len(payload)<18000,('Page would truncate',section,len(payload))
print(payload)
