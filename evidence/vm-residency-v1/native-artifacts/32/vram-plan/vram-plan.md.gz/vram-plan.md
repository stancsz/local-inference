# VRAM Plan (vm-residency-v1-32-claude)

## Disk sizes (model-manifest.json)
- Raw model `Qwen3.8-27B-UD-IQ3_XXS.gguf`: 10934860704 bytes
- MTP `MTP/mtp-Qwen3.8-27B-Q4_0.gguf`: 1369590656 bytes
- Combined disk bytes: 12304451360 bytes

These are on-disk file sizes, not runtime memory. Do not infer runtime VRAM from them.

## Measured runtime delta (runtime-vram.json)
- Baseline host used: 1509 MiB
- Loaded host used: 15252 MiB
- Observed inference delta: 13743 MiB (14410579968 bytes)
- vmwp dedicated allocation counters: 13803126784 + 24059904 + 0 bytes (may overlap; not physical totals)

The delta is a host-level before/after measurement including runtime caches/buffers and possible unrelated desktop drift; it is not per-allocation accounting. `under_14_decimal_GB_by_delta` is false.

## Host snapshot (host-vram.json, older snapshot, captured 2026-10-26T19:00:03Z)
GPU CSV order is name,total,used,free:
host_total_mib=16303
host_used_mib=2005
host_free_mib=13991

## Three largest measured process consumers (host-vram.json)
| Process | PID | Dedicated MiB |
|---|---|---|
| dwm | 195736 | 1688.2 |
| ChatGPT | 57080 | 368.7 |
| chrome | 311156 | 283.3 |

Get-Process does not expose a DedicatedMemory GPU property; these values came from a GPU-aware query. WDDM process counters may overlap and must not be summed as physical GPU usage.

## Safe VRAM reclamation after saving work
- Close unused browser tabs or disable browser acceleration after saving work.
- Use a lower resolution or fewer active displays to reduce compositor surfaces.
- Inference can offload weights or KV cache to RAM, at a measurable throughput cost.
- Never terminate DWM.

## Verification (read-only)
nvidia-smi --query-gpu=memory.total,memory.used,memory.free --format=csv

Unmeasured facts (unknown): per-model VRAM breakdown, exact vmwp process GPU total, whether the runtime delta maps one-to-one to the model.

VRAM_PLAN_DONE
