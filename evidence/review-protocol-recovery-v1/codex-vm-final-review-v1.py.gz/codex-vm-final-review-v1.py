import hashlib,json,os,subprocess,sys,urllib.request,uuid
from pathlib import Path
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT.parent/'sift/src')]
from stress.cli_acceptance import child_command,executable
BASE='http://127.0.0.1:4000';PREFIX=ROOT/'tmp/stress/codex-vm-final-review-v1'
def request(path,body,key):
 req=urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=60)as response:return json.load(response)
master=os.environ['GATEWAY_MASTER_KEY'];alias='codex-vm-review-'+uuid.uuid4().hex[:10]
key=request('/key/generate',{'key_alias':alias,'models':['default'],'duration':'10m','max_budget':5},master)['key']
commands=['python tmp/stress/codex-vm-review-pages-v1.py --section '+name for name in ('prior','verifier','method','data','checks')]
prompt='Fresh NONAUTHOR FULL-GOAL follow-up. You are the independent reviewer, not an implementation author. The permitted route4000/default has passed a forced function-argument/continuation probe and actual Codex0.154 read-only native marker smoke; do not repeat routing setup. Read all FIVE exact page commands below with native exec_command (max_output_tokens6000); finish a yielded command with write_stdin if necessary. Do not run other commands, write/edit sources/evidence, delegate, use network or read credentials. Native sandbox is read-only; tests and their cache warnings are within the read-only test scope. Prior full-goal review inspected all50k GOAL chars and accepted other criteria within bounds, but rejected host-delta-only proof of model+MTP under14GB. A separately sealed run now supplies direct all-VM Windows dedicated counters, stopped/load/unload controls,435case samples/no errors, exact64k+4k,256k/1Mretention and three native tasks. Judge whether a containing-VM upper bound below14,000,000,000bytes establishes the original model/MTP limit under the observed workloads; it is not an exact isolated-model or continuous-time value. Validate membership, counters, overcount/other limitations, all-instance summation, source/byte identity and actual artifacts. Do not change acceptance or promote old failures. Original goal also requires local DockerQwen27B3/4bit+MTP, mandatory adaptiveSift24k..64k for256k..1M history, productive settings/speed, three realClaude tasks, preserved approvals/settings, commits/push in bothrepos, adopted21sessions/seven perCLI and final independent acceptance. Reuse unchanged prior accepted scope explicitly; do not claim this read-only follow-up freshly queried live Docker/network. Return one JSON object with verdict READY/NOT_READY/UNVERIFIED for the FULL GOAL, criterion evidence/status, remaining work and measurement/review limits.\n'+'\n'.join(json.dumps({'cmd':c,'max_output_tokens':6000})for c in commands)
try:
 home=ROOT/'tmp/stress/codex-vm-review-client-v1';home.mkdir(exist_ok=False)
 command,env=child_command('codex',executable('codex'),home,BASE+'/v1','default',prompt,persist=False)
 command=[a.replace('workspace-write','read-only')if a=='workspace-write'or a.startswith('sandbox_mode=')else a for a in command]
 env['SIFT_LOCAL_KEY']=key
 env['PYTHONPATH']=';'.join([str(ROOT),str(ROOT/'scripts'),str(ROOT.parent/'sift/src'),str(ROOT/'app')])
 plan={'route':BASE+'/v1','model':'default','sandbox':'read-only','artifact_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'helper_sha256':hashlib.sha256((ROOT/'tmp/stress/codex-vm-review-pages-v1.py').read_bytes()).hexdigest(),'commands':commands,'argv':command[:-1]+['[PROMPT IN SEPARATE CAPTURE]'],'timeout_seconds':300,'scope':'fresh nonauthor full-goal follow-up of memory bound; unchanged prior accepted checks reused'}
 PREFIX.with_suffix('.plan.json').write_text(json.dumps(plan,indent=2));PREFIX.with_suffix('.prompt.txt').write_text(prompt,encoding='utf-8')
 with PREFIX.with_suffix('.jsonl').open('x',encoding='utf-8')as out,PREFIX.with_suffix('.stderr.log').open('x',encoding='utf-8')as err:
  process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=out,stderr=err)
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:
   subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);process.wait(timeout=20);raise
 PREFIX.with_suffix('.exit.json').write_text(json.dumps({'exit_code':code,'alias':alias}))
finally:
 request('/key/delete',{'key_aliases':[alias]},master);PREFIX.with_suffix('.revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
print('Codex full-goal review terminal; scoped key revoked',flush=True)
