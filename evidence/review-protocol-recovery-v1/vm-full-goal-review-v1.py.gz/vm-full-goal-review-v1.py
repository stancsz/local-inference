"""A single read-only command, shared verbatim by prompt and client allowlist."""
import json,os,subprocess,tempfile,urllib.request,uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
BASE='http://127.0.0.1:4000'
COMMAND='python tmp/stress/check-daily-review.py'
PREFIX=ROOT/'tmp/stress/vm-full-goal-review-v1'

def request(path,body,key):
    req=urllib.request.Request(BASE+path,data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=60)as response:return json.load(response)

def main():
    master=os.environ['GATEWAY_MASTER_KEY']
    alias='local-shared-mtp-review-'+uuid.uuid4().hex[:12]
    key=request('/key/generate',{'key_alias':alias,'models':['default'],'duration':'10m','max_budget':5},master)['key']
    commands=['python tmp/stress/vm-full-goal-review-pages-v1.py --section '+name for name in ('prior','verifier','method','data','checks')]
    allowed=','.join('Bash('+command+')' for command in commands)
    prompt=('Fresh NONAUTHOR FULL-GOAL follow-up of the preserved NOT_READY review. Execute all FIVE exact Bash input objects below, with a nonempty command string. Read the prior full-goal verdict, then inspect the actual verifier/method sources, direct Windows counter samples, native artifacts and fresh checks. Reuse valid prior bounded acceptance only where source/environment/claims remain unchanged; do not waive original criteria or promote failed historical artifacts. Original goal: independent local Docker Qwen27B3/4bit+MTP, mandatory request-adaptive Sift24k..64k for256k..1M histories, model+MTP GPU usage below14 decimal GB, prefer64k input+4k output or productive smaller profile, measured speed, three real native Claude tasks, unchanged caller approvals/settings, scoped commits/push in both repos, adopted21-session/seven-per-CLI gate and final nonauthor acceptance. Prior full-goal review inspected every GOAL slice and accepted other criteria within bounds, but rejected host-delta-only memory proof. New proposed evidence is direct summed dedicated usage of the containing VM, plus committed/shared counters, stopped/load/unload controls,435 case samples and the same productive long profile. No desktop subtraction or alias deduplication. Judge whether the containing-VM upper-bound inference actually establishes the user memory limit, or remains unsupported; it is not an exact isolated-model or continuous-time measurement. Inspect counter identity/membership, primary-source definitions and caveats, all-instance summation, baseline mapping, gaps/errors, actual native reconstructions and restoration. Do not infer universal model correctness or lossless semantic retention. Return one JSON object with verdict READY/NOT_READY/UNVERIFIED for the FULL GOAL, criterion statuses/evidence, remaining work and explicit review/measurement limits. No product/evidence/artifact edits, delegation or additional commands/provider calls. Read-only tests and temporary fixtures are permitted.\n'+'\n'.join(json.dumps({'command':c})for c in commands)+'\n')
    assert [json.loads(line)['command'] for line in prompt.splitlines()[1:]]==commands
    PREFIX.with_suffix('.plan.json').write_text(json.dumps({'artifact_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'helper_sha256':__import__('hashlib').sha256((ROOT/'tmp/stress/vm-full-goal-review-pages-v1.py').read_bytes()).hexdigest(),'route':BASE,'model':'default','commands':commands,'allowlist':allowed,'max_turns':10,'timeout_seconds':240,'scope':'read-only independent FULL GOAL follow-up of direct VM memory bound'},indent=2))
    try:
        with tempfile.TemporaryDirectory(prefix='daily-review-exact-')as config:
            env={k:v for k,v in os.environ.items()if not k.endswith(('_KEY','_TOKEN','_KEY_ID'))}
            env.pop('CLAUDECODE',None)
            env.update(ANTHROPIC_API_KEY=key,ANTHROPIC_BASE_URL=BASE,ANTHROPIC_MODEL='default',
                ANTHROPIC_DEFAULT_OPUS_MODEL='default',ANTHROPIC_DEFAULT_SONNET_MODEL='default',ANTHROPIC_DEFAULT_HAIKU_MODEL='default',
                CLAUDE_CONFIG_DIR=config,CLAUDE_CODE_DISABLE_1M_CONTEXT='1',CLAUDE_CODE_MAX_CONTEXT_TOKENS='256000',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC='1',API_TIMEOUT_MS='100000',
                PYTHONPATH=str(ROOT.parent/'sift/src')+';'+str(ROOT)+';'+str(ROOT/'app')+';'+str(ROOT/'scripts'))
            args=['claude.cmd','--bare','-p','--model','default','--output-format','stream-json','--verbose',
                  '--max-turns','10','--permission-mode','acceptEdits','--tools','Bash','--allowedTools',allowed]
            with PREFIX.with_suffix('.jsonl').open('w',encoding='utf-8')as out,PREFIX.with_suffix('.stderr.log').open('w',encoding='utf-8')as err:
                process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=out,stderr=err,text=True,encoding="utf-8",env=env,cwd=ROOT)
                try:process.communicate(prompt,timeout=240)
                except subprocess.TimeoutExpired:
                    subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
                    process.communicate(timeout=15)
                    raise
            PREFIX.with_suffix('.exit.json').write_text(json.dumps({'exit_code':process.returncode,'alias':alias}))
    finally:
        request('/key/delete',{'key_aliases':[alias]},master)
        PREFIX.with_suffix('.revocation.json').write_text(json.dumps({'alias':alias,'revoked':True}))
    print('Review terminal; task key revoked',flush=True)

if __name__=='__main__':main()
