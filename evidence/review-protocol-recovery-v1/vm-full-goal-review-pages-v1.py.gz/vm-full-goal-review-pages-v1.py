"""Read-only follow-up pages for the remaining memory criterion and full goal."""
import argparse,gzip,hashlib,inspect,json,subprocess,sys,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'scripts'),str(ROOT.parent/'sift/src'),str(ROOT/'app')]
import daily_artifacts as native
import daily_acceptance as validator
from profile_memory import summarize_vm_memory
p=argparse.ArgumentParser();p.add_argument('--section',choices=('prior','method','data','checks','verifier'),required=True);section=p.parse_args().section
out=[]
def source(name):out.extend([name,(ROOT/name).read_text(encoding='utf-8')])
if section=='prior':
 review=json.loads((ROOT/'evidence/final-goal-review-v1.json').read_text())
 out.append(json.dumps(review['verdict']))
 out.append(json.dumps(review['review_cli_limits']))
 text=(ROOT/'GOAL.md').read_text(encoding='utf-8');out.append(text[:text.index('## Historical stress and repair ledger')])
elif section=='method':
 out.append(inspect.getsource(summarize_vm_memory))
 for name in ('scripts/windows_vm_gpu.ps1','tests/test_vm_memory.py','docs/WINDOWS_GPU_ACCOUNTING.md'):source(name)
elif section=='verifier':source('tmp/stress/vm-full-goal-review-pages-v1.py')
elif section=='data':
 folder=ROOT/'evidence/vm-residency-v1';state=json.loads((folder/'state.json').read_text());assert state['status']=='terminal'and state['restored']and state['vm_sampler_exit']==0
 assert all(value==0 for value in state['cases'][0]['checks'].values())and len(state['cases'][0]['checks'])==6
 rows=[json.loads(line)for line in (folder/'vm-counters.jsonl').read_text().splitlines()]
 result=summarize_vm_memory(rows,32);assert result==state['vm_counter_result']
 assert not any('sampling_error'in row for row in rows)
 assert result['stopped_vm_dedicated_range_bytes']==[24059904,24059904]
 actual_stages={row['stage']for row in rows}
 for name in ('benchmark','capacity','local','openai','context','claude-feedback'):assert 'tests-32-'+name in actual_stages
 result['overall_dedicated_peak_all_stages']=max(sum(c['dedicated_bytes']for c in row['counters'])for row in rows)
 result['overall_gpu_committed_peak_all_stages']=max(sum(c['committed_bytes']for c in row['counters'])for row in rows)
 out.append(json.dumps({'direct_vm_result':result,'all_rows':len(rows),'measurement_plan':json.loads((ROOT/'evidence/vm-residency-v1-plan.json').read_text())}))
 capacity=json.loads((folder/'32-capacity.json').read_text());assert capacity['passed']and capacity['input_token_ids']==65536 and capacity['tokens_predicted']==4096 and not capacity['truncated']
 out.append(json.dumps({'capacity':capacity}))
 contexts=json.loads((folder/'32-context.json').read_text());assert all(row['passed']for row in contexts)
 assert contexts[0]['audit']['target_tokens']!=contexts[1]['audit']['target_tokens']
 out.append(json.dumps([{'raw_native':row['raw_native_tokens'],'target':row['audit']['target_tokens'],'forwarded':row['audit']['native_input_tokens'],'answer':row['answer']}for row in contexts]))
 base=folder/'native-artifacts/32'
 def read(relative):return gzip.decompress((base/(str(relative)+'.gz')).read_bytes()).decode('utf-8').replace('\r\n','\n').replace('\r','\n')
 summary=json.loads(read('run-summary.json'));assert not summary['sources_changed_during_run']and len(summary['tasks'])==3
 checked=[]
 for task in summary['tasks']:
  name=task['task'];previous=validator.BASELINE_CONTENT;sid=None
  artifact=ROOT/'tmp/vm-residency-v1-32-claude'/task['artifact']
  for phase in task['phases']:
   events=[json.loads(line)for line in read(name+'/phase-'+str(phase['phase'])+'/stdout.jsonl').splitlines()if line.startswith('{')]
   terminal=native.final_result(events);assert not terminal.get('is_error')
   if sid:assert terminal['session_id']==sid
   sid=terminal['session_id']
   previous=native.reconstruct_revisions(events,artifact,previous)[-1]
   revision=read(phase['revision_file'])
   assert previous.rstrip('\r\n')==revision.rstrip('\r\n')
   assert hashlib.sha256(revision.encode()).hexdigest()==phase['artifact_sha256']
  final=read(task['artifact']);assert previous.rstrip('\r\n')==final.rstrip('\r\n')
  errors=validator.validate_task_artifact(name,final,validator.load_sources());assert not errors and task['passed']
  checked.append({'task':name,'native_phase_count':len(task['phases']),'repairs':task['repairs_used'],'native_reconstruction':True,'final_errors':errors})
  out.extend([task['artifact'],final])
 out.append(json.dumps({'actual_native_artifacts_replayed':checked,'session_qualification_increment':0,'existing_candidate_totals':{'claude':8,'opencode':9,'codex':7}}))
 for stage in ('baseline-start','loading-32','tests-32-capacity','tests-32-claude-feedback','baseline-end'):
  matches=[row for row in rows if row['stage']==stage];out.append(json.dumps({'representative_raw_stage':stage,'first':matches[0],'last':matches[-1]}))
else:
 proof=subprocess.run([sys.executable,'evidence/profile-publication-tools/check-profile-publication.py','--commit','HEAD'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=60)
 assert proof.returncode==0;out.append(proof.stdout)
 run=subprocess.run([sys.executable,'-m','pytest','-q','tests/test_profile_memory.py','tests/test_vm_memory.py','tests/test_claude_settings_compat.py','tests/test_repair_compatibility.py'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=90)
 out.append(run.stdout+run.stderr);assert run.returncode==0
 out.extend(['Most recent full project suite',(ROOT/'evidence/vm-residency-v1/project-tests.log').read_text()])
 with urllib.request.urlopen('http://127.0.0.1:8091/props',timeout=10)as response:props=json.load(response)
 assert props['default_generation_settings']['n_ctx']==40960
 actual=subprocess.check_output(['docker','exec','local-inference-inference-1','cat','/start-inference.sh']);assert actual==(ROOT/'docker/start-inference.sh').read_bytes()
 code="import json,hashlib,pathlib;print(json.dumps({n:hashlib.sha256(pathlib.Path('/app/'+n).read_bytes()).hexdigest()for n in ['budget.py','gateway.py','gateway.yaml']}))"
 actual_app=json.loads(subprocess.check_output(['docker','exec','local-inference-gateway-1','python','-c',code],text=True))
 for name,digest in actual_app.items():
  path=ROOT/name if name=='gateway.yaml'else ROOT/'app'/name
  assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
 out.append(json.dumps({'live_default_context':40960,'mounted_startup_matches':True,'gateway_source_hashes_match':True,'runtime_build':props['build_info']}))
 for name in ('restored-local.json','restored-openai.json'):
  out.extend([name,(ROOT/'evidence/vm-residency-v1'/name).read_text()])
payload='\n'.join(out)
assert len(payload)<18000,(section,len(payload))
print(payload)
